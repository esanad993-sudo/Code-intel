#!/bin/bash
# Mini-service runner for code-intel Python sidecar.
# Restart-on-crash wrapper.
cd "$(dirname "$0")"
LOG=/tmp/code-intel.log
while true; do
  echo "[$(date '+%H:%M:%S')] starting uvicorn on port 3030" >> $LOG
  python3 -m uvicorn index:app --host 127.0.0.1 --port 3030 --log-level warning >> $LOG 2>&1
  EXIT=$?
  echo "[$(date '+%H:%M:%S')] uvicorn exited with $EXIT, restarting in 2s" >> $LOG
  sleep 2
done
