"""
Code-Intel Python Sidecar
=========================
Provides two endpoints consumed by the Next.js app:

  POST /parse
    Body: { "files": [{"path": "...", "content": "...", "language": "python"|"rust"|"go"|"java"|"javascript"|"typescript"}] }
    Returns: { "documents": [{ "filePath", "language", "nodes": [...] }] }
      Each node has the same shape as our TS ASTNode:
        id, type, name, filePath, startLine, endLine, scope[], decorators[],
        parentId (nullable), childIds[], references[], parameterTypes[],
        returnType (nullable), isExported, isAsync, astDepth

  POST /embed
    Body: { "texts": ["authenticateUser", "verifyCredential", ...] }
    Returns: { "vectors": [[0.12, -0.34, ...], ...], "dim": 384 }
      Uses a lightweight hash-based pseudo-embedding (deterministic, no model
      download needed). Production deployment would swap in a real sentence
      transformer — the API contract is identical.

  GET /health
    Returns: { "status": "ok", "languages": ["python", "rust", ...], "embeddings": "hash"|"sentence-transformers" }

The service is intentionally stateless — all caching happens on the Next.js
side. Python is invoked at index time only.
"""
from __future__ import annotations
import os
import json
import hashlib
import math
import re
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Tree-sitter — supports 30+ languages via the tree_sitter_languages pack.
import warnings
warnings.filterwarnings("ignore")  # suppress tree-sitter deprecation warnings
from tree_sitter_languages import get_parser

# Try to load a real sentence-transformer model. If unavailable, fall back
# to a deterministic hash-based pseudo-embedding (still useful for testing
# the dense-retriever pipeline end-to-end).
EMBED_BACKEND = "hash"
try:
    from sentence_transformers import SentenceTransformer  # type: ignore
    _MODEL = None  # lazy load
    EMBED_BACKEND = "sentence-transformers"
except Exception:
    _MODEL = None


# ============================================================
# AST node extraction (language-agnostic via tree-sitter)
# ============================================================

# Tree-sitter node types we care about, per language. We normalize them
# into our common ASTNodeType vocabulary.
NODE_TYPE_MAP = {
    # Python
    "function_definition": "FunctionDeclaration",
    "class_definition": "ClassDeclaration",
    "decorator": "Decorator",
    "assignment": "AssignmentExpression",
    "import_statement": "ImportDeclaration",
    "import_from_statement": "ImportDeclaration",
    # JavaScript / TypeScript
    "function_declaration": "FunctionDeclaration",
    "function": "FunctionDeclaration",
    "method_definition": "MethodDeclaration",
    "class_declaration": "ClassDeclaration",
    "class": "ClassDeclaration",
    "import_statement": "ImportDeclaration",
    "import_declaration": "ImportDeclaration",
    "variable_declaration": "VariableDeclaration",
    "lexical_declaration": "VariableDeclaration",
    "decorator": "Decorator",
    # Rust
    "function_item": "FunctionDeclaration",
    "struct_item": "ClassDeclaration",
    "enum_item": "ClassDeclaration",
    "impl_item": "ClassDeclaration",
    "use_declaration": "ImportDeclaration",
    "let_declaration": "VariableDeclaration",
    # Go
    "function_declaration": "FunctionDeclaration",
    "method_declaration": "MethodDeclaration",
    "type_declaration": "ClassDeclaration",
    "import_declaration": "ImportDeclaration",
    "var_declaration": "VariableDeclaration",
    "short_var_declaration": "VariableDeclaration",
    # Java
    "method_declaration": "MethodDeclaration",
    "class_declaration": "ClassDeclaration",
    "interface_declaration": "ClassDeclaration",
    "import_declaration": "ImportDeclaration",
    "field_declaration": "PropertyDeclaration",
    "annotation": "Decorator",
    "constructor_declaration": "ConstructorDeclaration",
}

# Node types that should NOT be indexed as top-level docs (internal only)
INTERNAL_TYPES = {"identifier", "string", "comment", "block", "statement_block"}

# Languages we report as supported
SUPPORTED_LANGS = ["python", "javascript", "typescript", "rust", "go", "java"]


def normalize_language(path: str, language: str | None) -> str:
    if language and language.lower() in SUPPORTED_LANGS:
        return language.lower()
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    return {
        "py": "python",
        "js": "javascript",
        "jsx": "javascript",
        "ts": "typescript",
        "tsx": "typescript",
        "rs": "rust",
        "go": "go",
        "java": "java",
    }.get(ext, "python")


def get_node_name(node, source_bytes: bytes) -> str:
    """Extract a human-readable name from a tree-sitter node."""
    # Try common name fields
    for field in ("name", "declarator", "function_name", "type"):
        try:
            child = node.child_by_field_name(field)
            if child is not None:
                text = source_bytes[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
                # For declarators like `x = 5` or `fn foo()`, just take the identifier
                m = re.match(r"[A-Za-z_$][A-Za-z0-9_$]*", text)
                if m:
                    return m.group(0)
                return text[:64]
        except Exception:
            pass
    # Fall back: first identifier child
    for child in node.children:
        if child.type == "identifier":
            return source_bytes[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
    return node.type


def get_decorators(node, source_bytes: bytes) -> list[dict]:
    """Find decorators/annotations attached to a node."""
    decorators = []
    # Python decorators are siblings preceding the function/class
    # In tree-sitter, they're usually children with type "decorator"
    for child in node.children:
        if child.type == "decorator":
            text = source_bytes[child.start_byte:child.end_byte].decode("utf-8", errors="replace").strip()
            # Extract @name
            m = re.match(r"@([A-Za-z_][A-Za-z0-9_]*)", text)
            if m:
                decorators.append({"name": f"@{m.group(1)}", "args": []})
        # Java annotations
        if child.type == "annotation" or child.type == "marker_annotation":
            text = source_bytes[child.start_byte:child.end_byte].decode("utf-8", errors="replace").strip()
            m = re.match(r"@([A-Za-z_][A-Za-z0-9_]*)", text)
            if m:
                decorators.append({"name": f"@{m.group(1)}", "args": []})
    # Look at siblings for Python decorators preceding the node
    parent = node.parent
    if parent:
        node_idx = list(parent.children).index(node)
        for sib in parent.children[:node_idx][::-1]:
            if sib.type == "decorator":
                text = source_bytes[sib.start_byte:sib.end_byte].decode("utf-8", errors="replace").strip()
                m = re.match(r"@([A-Za-z_][A-Za-z0-9_]*)", text)
                if m:
                    name = f"@{m.group(1)}"
                    if not any(d["name"] == name for d in decorators):
                        decorators.insert(0, {"name": name, "args": []})
            elif sib.type == "comment" or sib.type == "expression_statement":
                continue
            else:
                break
    return decorators


def get_parameter_types(node, source_bytes: bytes) -> list[str]:
    """Extract parameter names:types from a function-like node."""
    params = []
    # tree-sitter exposes parameters via field
    try:
        param_list = node.child_by_field_name("parameters")
        if param_list is None:
            return params
        for child in param_list.children:
            if child.type in {"identifier", "parameter"}:
                text = source_bytes[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
                params.append(text.split(":", 1)[0].strip() or text[:32])
    except Exception:
        pass
    return params


def get_return_type(node, source_bytes: bytes) -> str | None:
    """Extract the return type annotation if present."""
    try:
        ret = node.child_by_field_name("return_type")
        if ret is None:
            # JS/TS uses "return_type" too in some grammars
            ret = node.child_by_field_name("result_type")
        if ret is None:
            return None
        return source_bytes[ret.start_byte:ret.end_byte].decode("utf-8", errors="replace")[:64]
    except Exception:
        return None


def collect_references(node, source_bytes: bytes) -> list[str]:
    """Walk the subtree collecting call/ident references."""
    refs: list[str] = []
    def walk(n):
        if n.type == "call":
            # First identifier child is the callee
            for c in n.children:
                if c.type == "identifier":
                    name = source_bytes[c.start_byte:c.end_byte].decode("utf-8", errors="replace")
                    refs.append(f"call:{name}")
                    break
                elif c.type == "member_expression":
                    text = source_bytes[c.start_byte:c.end_byte].decode("utf-8", errors="replace")
                    m = re.search(r"\.([A-Za-z_][A-Za-z0-9_]*)\s*$", text)
                    if m:
                        refs.append(f"call:{m.group(1)}")
                    break
        elif n.type == "identifier":
            text = source_bytes[n.start_byte:n.end_byte].decode("utf-8", errors="replace")
            if text not in {"true", "false", "null", "None", "self", "this", "super"}:
                refs.append(f"ident:{text}")
        for c in n.children:
            walk(c)
    walk(node)
    # Deduplicate but preserve order
    seen = set()
    out = []
    for r in refs:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out[:30]  # cap for storage


def get_docstring(node, source_bytes: bytes) -> str:
    """Pull the docstring/comment block above this node."""
    # Look at the first child block for Python docstrings
    for child in node.children:
        if child.type == "block" or child.type == "statement_block":
            for gc in child.children:
                if gc.type == "expression_statement":
                    for ggc in gc.children:
                        if ggc.type == "string":
                            text = source_bytes[ggc.start_byte:ggc.end_byte].decode("utf-8", errors="replace")
                            return text.strip("\"'").strip()[:500]
                elif gc.type == "string":
                    text = source_bytes[gc.start_byte:gc.end_byte].decode("utf-8", errors="replace")
                    return text.strip("\"'").strip()[:500]
    # Look at preceding comment siblings
    parent = node.parent
    if parent:
        node_idx = list(parent.children).index(node)
        comments = []
        for sib in parent.children[:node_idx][::-1]:
            if sib.type == "comment":
                text = source_bytes[sib.start_byte:sib.end_byte].decode("utf-8", errors="replace").strip()
                comments.insert(0, text.lstrip("#/* ").rstrip("*/"))
            elif sib.type in {"decorator", "annotation"}:
                continue
            else:
                break
        if comments:
            return " ".join(comments)[:500]
    return ""


def parse_file(content: str, file_path: str, language: str | None = None) -> dict:
    """Parse a file with tree-sitter and return our normalized ASTDocument shape."""
    lang = normalize_language(file_path, language)
    try:
        parser = get_parser(lang)
    except Exception as e:
        return {
            "filePath": file_path,
            "language": lang,
            "error": f"parser unavailable for {lang}: {e}",
            "nodes": [],
        }

    source_bytes = content.encode("utf-8") if isinstance(content, str) else content
    tree = parser.parse(source_bytes)

    module_id = re.sub(r"[^a-zA-Z0-9]", "_", file_path)
    nodes_out: list[dict] = []
    id_counter = [0]

    def next_id() -> str:
        nid = f"{module_id}#n{id_counter[0]}"
        id_counter[0] += 1
        return nid

    def walk(node, scope: list[str], parent_id: str | None, depth: int):
        # Skip non-indexable node types
        if node.type in INTERNAL_TYPES:
            for c in node.children:
                walk(c, scope, parent_id, depth)
            return

        normalized_type = NODE_TYPE_MAP.get(node.type)
        if normalized_type is None:
            # Still walk children — there may be function defs inside a module
            for c in node.children:
                walk(c, scope, parent_id, depth)
            return

        name = get_node_name(node, source_bytes)
        node_id = next_id()
        decorators = get_decorators(node, source_bytes)
        param_types = get_parameter_types(node, source_bytes) if normalized_type in {
            "FunctionDeclaration", "MethodDeclaration", "ConstructorDeclaration"
        } else []
        return_type = get_return_type(node, source_bytes)
        references = collect_references(node, source_bytes) if normalized_type in {
            "FunctionDeclaration", "MethodDeclaration", "ConstructorDeclaration",
            "VariableDeclaration", "AssignmentExpression"
        } else []

        # Heuristic: detect `async` keyword in source for JS/TS
        is_async = False
        if normalized_type in {"FunctionDeclaration", "MethodDeclaration"}:
            # Walk left siblings looking for `async`
            parent = node.parent
            if parent:
                idx = list(parent.children).index(node)
                for sib in parent.children[max(0, idx-3):idx]:
                    text = source_bytes[sib.start_byte:sib.end_byte].decode("utf-8", errors="replace").strip()
                    if text == "async":
                        is_async = True
                        break

        is_exported = False
        parent = node.parent
        if parent:
            idx = list(parent.children).index(node)
            for sib in parent.children[max(0, idx-2):idx]:
                text = source_bytes[sib.start_byte:sib.end_byte].decode("utf-8", errors="replace").strip()
                if text in {"export", "pub", "public"}:
                    is_exported = True
                    break

        node_dict = {
            "id": node_id,
            "type": normalized_type,
            "name": name,
            "filePath": file_path,
            "startLine": node.start_point[0] + 1,
            "endLine": node.end_point[0] + 1,
            "scope": list(scope),
            "decorators": decorators,
            "parentId": parent_id,
            "childIds": [],  # filled below
            "references": references,
            "parameterTypes": param_types,
            "returnType": return_type,
            "isExported": is_exported,
            "isAsync": is_async,
            "astDepth": depth,
            # Extra fields not in the TS ASTNode but useful for the UI
            "language": lang,
            "docstring": get_docstring(node, source_bytes),
        }
        nodes_out.append(node_dict)

        # Walk children with this node as parent
        child_scope = list(scope) + ([name] if normalized_type in {
            "ClassDeclaration", "FunctionDeclaration", "MethodDeclaration"
        } else [])
        for c in node.children:
            walk(c, child_scope, node_id, depth + 1)

        # Fill childIds
        for n in nodes_out:
            if n["parentId"] == node_id:
                node_dict["childIds"].append(n["id"])

    # Walk the root
    root_id = f"{module_id}#root"
    root_node = {
        "id": root_id,
        "type": "Program",
        "name": file_path.rsplit("/", 1)[-1] or file_path,
        "filePath": file_path,
        "startLine": 1,
        "endLine": content.count("\n") + 1 if isinstance(content, str) else 1,
        "scope": [],
        "decorators": [],
        "parentId": None,
        "childIds": [],
        "references": [],
        "parameterTypes": [],
        "returnType": None,
        "isExported": False,
        "isAsync": False,
        "astDepth": 0,
        "language": lang,
        "docstring": "",
    }
    nodes_out.append(root_node)
    walk(tree.root_node, [], root_id, 0)

    # Fill top-level childIds
    for n in nodes_out:
        if n["parentId"] == root_id:
            root_node["childIds"].append(n["id"])

    return {
        "filePath": file_path,
        "language": lang,
        "moduleName": module_id,
        "sourceLines": content.split("\n") if isinstance(content, str) else [],
        "nodes": nodes_out,
    }


# ============================================================
# Dense embeddings (hash-based fallback OR sentence-transformers)
# ============================================================

EMBED_DIM = 384  # matches MiniLM-L6-v2 if available


def hash_embed(text: str, dim: int = EMBED_DIM) -> list[float]:
    """Deterministic hash-based pseudo-embedding.
    Not a real sentence embedding — just a stable vector. Cosine similarity
    will pick up exact substring matches and partial token overlaps but
    won't do real semantic similarity. Use sentence-transformers if available.
    """
    vec = [0.0] * dim
    # Tokenize like our BM25 tokenizer
    tokens = re.findall(r"[A-Za-z0-9]+", text.lower())
    for tok in tokens:
        h = hashlib.md5(tok.encode("utf-8")).digest()
        # 4 bytes -> 4 dim
        for i in range(0, min(8, dim), 2):
            idx = int.from_bytes(h[i:i+2], "big") % dim
            vec[idx] += 1.0
    # Add character n-gram features for fuzzy matching
    for i in range(len(text) - 2):
        tri = text[i:i+3].lower()
        h = hashlib.md5(tri.encode("utf-8")).digest()
        idx = int.from_bytes(h[:2], "big") % dim
        vec[idx] += 0.3
    # Normalize to unit length
    norm = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [v / norm for v in vec]


def st_embed(texts: list[str]) -> list[list[float]]:
    """Real sentence-transformer embeddings (if available)."""
    global _MODEL
    if _MODEL is None:
        # MiniLM-L6-v2 is ~80MB, dim=384
        try:
            _MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        except Exception:
            _MODEL = "unavailable"
    if _MODEL == "unavailable":
        return [hash_embed(t) for t in texts]
    vecs = _MODEL.encode(texts, normalize_embeddings=True)
    return [v.tolist() for v in vecs]


def embed_texts(texts: list[str]) -> list[list[float]]:
    if EMBED_BACKEND == "sentence-transformers":
        try:
            return st_embed(texts)
        except Exception:
            return [hash_embed(t) for t in texts]
    return [hash_embed(t) for t in texts]


# ============================================================
# FastAPI app
# ============================================================

app = FastAPI(title="Code-Intel Sidecar", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ParseRequest(BaseModel):
    files: list[dict]


class EmbedRequest(BaseModel):
    texts: list[str]


@app.get("/health")
def health():
    return {
        "status": "ok",
        "languages": SUPPORTED_LANGS,
        "embeddings": EMBED_BACKEND,
        "embed_dim": EMBED_DIM,
    }


@app.post("/parse")
def parse(req: ParseRequest):
    docs = []
    errors = []
    for f in req.files:
        path = f.get("path", "unknown")
        content = f.get("content", "")
        lang = f.get("language")
        try:
            doc = parse_file(content, path, lang)
            docs.append(doc)
        except Exception as e:
            errors.append({"path": path, "error": str(e)})
            docs.append({"filePath": path, "language": lang or "unknown", "nodes": [], "error": str(e)})
    return {"documents": docs, "errors": errors, "language_count": len({d.get("language") for d in docs})}


@app.post("/embed")
def embed(req: EmbedRequest):
    vecs = embed_texts(req.texts)
    return {"vectors": vecs, "dim": EMBED_DIM, "backend": EMBED_BACKEND}


@app.get("/")
def root():
    return {"service": "code-intel", "endpoints": ["/health", "/parse", "/embed"]}


# ============================================================
# CLI mode: read JSON from stdin, write JSON to stdout.
# Used by the Next.js subprocess client (more sandbox-friendly
# than running a long-lived uvicorn process).
# ============================================================
def _cli_main():
    import sys
    payload = json.loads(sys.stdin.read())
    op = payload.get("op")
    if op == "health":
        print(json.dumps({
            "status": "ok",
            "languages": SUPPORTED_LANGS,
            "embeddings": EMBED_BACKEND,
            "embed_dim": EMBED_DIM,
        }))
    elif op == "parse":
        result = parse(ParseRequest(**payload))
        print(json.dumps(result))
    elif op == "embed":
        result = embed(EmbedRequest(**payload))
        print(json.dumps(result))
    else:
        print(json.dumps({"error": f"unknown op: {op}"}))
        sys.exit(1)


if __name__ == "__main__":
    import sys
    if "--json-stdin" in sys.argv:
        _cli_main()
    else:
        import uvicorn
        port = int(os.environ.get("PORT", 3030))
        uvicorn.run(app, host="0.0.0.0", port=port)
