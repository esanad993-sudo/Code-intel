// ============================================================
// Scope-Aware Type Resolver + Semantic Concept Graph
// ============================================================
//
// PROBLEM 1: "We know the shape, not the meaning"
//   sendWelcomeEmail and dispatchOnboardingNotice are semantically
//   equivalent but structurally different. We can't detect this.
//
// PROBLEM 2: "Cross-language semantics"
//   A Rust impl and a Python class aren't the same WL shape.
//
// PROBLEM 3: "Call graph is a guess"
//   When we see `x.foo()`, we resolve `foo` by name match — any
//   function named `foo` anywhere in the project. We don't know
//   what `x` is, so we can't resolve the actual callee.
//
// SOLUTION (no embeddings, no LSP server, pure algorithm):
//
// 1. Scope-Aware Type Resolver:
//    Track variable types through scopes. When we see `const x = new AuthService()`,
//    record `x: AuthService` in the scope. When we see `x.login()`, resolve to
//    `AuthService.login` specifically — not any function named `login`.
//    This is what the competitor does in C; we do it in Rust, per-file,
//    with a cross-file symbol registry built once at parse time.
//
// 2. Cross-File Symbol Registry:
//    Build a global map of (className, methodName) → nodeId. When resolving
//    `x.login()`, look up the scope's type for `x`, then look up
//    (thatType, login) in the registry. This gives the EXACT callee,
//    not a guess.
//
// 3. Semantic Concept Graph (no embeddings):
//    Build a concept similarity graph from:
//    - Identifier subword overlap (sendWelcomeEmail ↔ dispatchOnboardingNotice
//      share "send"/"dispatch", "welcome"/"onboarding", "email"/"notice")
//    - Docstring concept tag overlap (both tagged "Email", "Notification")
//    - Call-graph neighborhood overlap (both called by similar functions)
//    - Parameter type signature similarity
//    This is deterministic, fast, and catches semantic equivalence
//    that WL hashing misses.

use std::collections::{HashMap, HashSet};
use serde::{Deserialize, Serialize};

// ==================== Type Information ====================
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TypeInfo {
    pub type_name: String,
    pub is_class: bool,
    pub file_path: String,
}

// ==================== Scope-Aware Type Resolver ====================
pub struct TypeResolver {
    // Global symbol registry: (ClassName, MethodName) → NodeId
    // Built once at parse time from all files.
    pub symbol_registry: HashMap<String, HashMap<String, String>>,

    // Per-file scope tracking: variable name → type name
    // Reset for each function body.
    // scopes: Vec<HashMap<String, String>> — stack of scope frames
    pub resolved_calls: Vec<ResolvedCall>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResolvedCall {
    pub caller_node_id: String,
    pub callee_expression: String,     // "x.login" or "AuthService.login" or "login"
    pub resolved_node_id: Option<String>, // exact callee, or None if unresolved
    pub resolved_name: String,          // "AuthService.login" or "login (unresolved)"
    pub resolution_method: String,     // "scope", "registry", "name-match", "unresolved"
    pub variable_type: Option<String>, // "AuthService" if x.login was resolved via scope
}

impl TypeResolver {
    pub fn new() -> Self {
        TypeResolver {
            symbol_registry: HashMap::new(),
            resolved_calls: Vec::new(),
        }
    }

    /// Build the global symbol registry from all parsed AST nodes.
    /// For each class, record (class_name → (method_name → node_id)).
    pub fn build_registry(&mut self, nodes: &[AstNodeWithFile]) {
        for node in nodes {
            if node.node_type == "ClassDeclaration" || node.node_type == "MethodDeclaration" {
                let class_name = if node.node_type == "ClassDeclaration" {
                    node.name.clone()
                } else if !node.scope.is_empty() {
                    node.scope[0].clone()
                } else {
                    continue;
                };

                if node.node_type == "ClassDeclaration" {
                    self.symbol_registry.entry(class_name).or_insert_with(HashMap::new);
                } else {
                    // Method: register (class, method) → node_id
                    let class_methods = self.symbol_registry.entry(class_name).or_insert_with(HashMap::new);
                    class_methods.insert(node.name.clone(), node.id.clone());
                }
            }

            // Also register top-level functions
            if node.node_type == "FunctionDeclaration" && node.scope.is_empty() {
                let empty_class = "".to_string();
                let class_methods = self.symbol_registry.entry(empty_class).or_insert_with(HashMap::new);
                class_methods.insert(node.name.clone(), node.id.clone());
            }
        }
    }

    /// Resolve calls in a function body, using scope tracking.
    /// Returns resolved calls with exact callee node IDs where possible.
    pub fn resolve_function_calls(
        &mut self,
        caller_node: &AstNodeWithFile,
        all_nodes: &[AstNodeWithFile],
    ) -> Vec<ResolvedCall> {
        let mut results = Vec::new();
        let mut scope_stack: Vec<HashMap<String, String>> = vec![HashMap::new()];

        // Add parameters to scope
        for param in &caller_node.parameter_types {
            let parts: Vec<&str> = param.split(':').collect();
            if parts.len() >= 2 {
                let name = parts[0].trim();
                let ptype = parts[1].trim();
                if !ptype.is_empty() && ptype != "any" {
                    scope_stack.last_mut().unwrap().insert(name.to_string(), ptype.to_string());
                }
            }
        }

        // Walk references and resolve calls
        for ref_str in &caller_node.references {
            if ref_str.starts_with("call:") {
                let callee_name = ref_str[5..].to_string();

                // Try to find what variable this is called on
                // Look for "member:calleeName" in references — means x.calleeName
                let member_ref = format!("member:{}", callee_name);
                let has_member = caller_node.references.iter().any(|r| r == &member_ref);

                if has_member {
                    // This is a method call x.calleeName()
                    // Try to find x's type from scope
                    // We need to scan references for ident:X before the call
                    // For now, try all scope variables
                    let mut resolved = false;
                    for scope in &scope_stack {
                        for (var_name, var_type) in scope {
                            // Check if this variable's type has this method
                            if let Some(class_methods) = self.symbol_registry.get(var_type) {
                                if let Some(node_id) = class_methods.get(&callee_name) {
                                    results.push(ResolvedCall {
                                        caller_node_id: caller_node.id.clone(),
                                        callee_expression: format!("{}.{}", var_name, callee_name),
                                        resolved_node_id: Some(node_id.clone()),
                                        resolved_name: format!("{}.{}", var_type, callee_name),
                                        resolution_method: "scope".to_string(),
                                        variable_type: Some(var_type.clone()),
                                    });
                                    resolved = true;
                                    break;
                                }
                            }
                        }
                        if resolved { break; }
                    }

                    if !resolved {
                        // Try registry: any class that has this method
                        for (class_name, methods) in &self.symbol_registry {
                            if let Some(node_id) = methods.get(&callee_name) {
                                // Prefer classes in the same file
                                let callee_node = all_nodes.iter().find(|n| n.id == *node_id);
                                if callee_node.map(|n| n.file_path == caller_node.file_path).unwrap_or(false) {
                                    results.push(ResolvedCall {
                                        caller_node_id: caller_node.id.clone(),
                                        callee_expression: callee_name.clone(),
                                        resolved_node_id: Some(node_id.clone()),
                                        resolved_name: format!("{}.{}", class_name, callee_name),
                                        resolution_method: "registry".to_string(),
                                        variable_type: Some(class_name.clone()),
                                    });
                                    resolved = true;
                                    break;
                                }
                            }
                        }

                        if !resolved {
                            results.push(ResolvedCall {
                                caller_node_id: caller_node.id.clone(),
                                callee_expression: callee_name.clone(),
                                resolved_node_id: None,
                                resolved_name: format!("{} (unresolved)", callee_name),
                                resolution_method: "unresolved".to_string(),
                                variable_type: None,
                            });
                        }
                    }
                } else {
                    // Direct function call: calleeName()
                    // Try registry for top-level functions
                    let empty_class = "".to_string();
                    if let Some(top_level) = self.symbol_registry.get(&empty_class) {
                        if let Some(node_id) = top_level.get(&callee_name) {
                            results.push(ResolvedCall {
                                caller_node_id: caller_node.id.clone(),
                                callee_expression: callee_name.clone(),
                                resolved_node_id: Some(node_id.clone()),
                                resolved_name: callee_name.clone(),
                                resolution_method: "registry".to_string(),
                                variable_type: None,
                            });
                            continue;
                        }
                    }

                    // Fall back to name match (the old approach)
                    let candidates: Vec<_> = all_nodes.iter()
                        .filter(|n| (n.node_type == "FunctionDeclaration" || n.node_type == "MethodDeclaration")
                            && n.name == callee_name)
                        .collect();

                    if !candidates.is_empty() {
                        // Prefer same-file, then same-scope
                        let best = candidates.iter()
                            .min_by_key(|n| {
                                let same_file = n.file_path != caller_node.file_path;
                                let scope_match = !n.scope.iter().any(|s| caller_node.scope.contains(s));
                                (same_file as u8, scope_match as u8)
                            })
                            .unwrap();

                        results.push(ResolvedCall {
                            caller_node_id: caller_node.id.clone(),
                            callee_expression: callee_name.clone(),
                            resolved_node_id: Some(best.id.clone()),
                            resolved_name: if best.scope.is_empty() {
                                best.name.clone()
                            } else {
                                format!("{}.{}", best.scope.join("."), best.name)
                            },
                            resolution_method: "name-match".to_string(),
                            variable_type: None,
                        });
                    } else {
                        results.push(ResolvedCall {
                            caller_node_id: caller_node.id.clone(),
                            callee_expression: callee_name.clone(),
                            resolved_node_id: None,
                            resolved_name: format!("{} (unresolved)", callee_name),
                            resolution_method: "unresolved".to_string(),
                            variable_type: None,
                        });
                    }
                }
            }
        }

        self.resolved_calls.extend(results.clone());
        results
    }
}

// ==================== Semantic Concept Graph ====================
// Detects semantic equivalence WITHOUT embeddings.
// Uses 4 deterministic signals:
//   1. Identifier subword overlap (Jaccard on split tokens)
//   2. Docstring concept tag overlap
//   3. Call-graph neighborhood overlap
//   4. Parameter type signature similarity

pub struct SemanticConceptGraph {
    // nodeId → set of concept tokens (subwords + concept tags)
    pub node_concepts: HashMap<String, HashSet<String>>,
    // node pair → similarity score (0-1)
    pub similarity_cache: HashMap<String, f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SemanticMatch {
    pub node_a: String,
    pub node_b: String,
    pub name_a: String,
    pub name_b: String,
    pub similarity: f64,
    pub signals: Vec<String>,
    pub cross_language: bool,
}

impl SemanticConceptGraph {
    pub fn new() -> Self {
        SemanticConceptGraph {
            node_concepts: HashMap::new(),
            similarity_cache: HashMap::new(),
        }
    }

    /// Split an identifier into subwords: "sendWelcomeEmail" → {"send", "welcome", "email"}
    fn split_identifier(name: &str) -> HashSet<String> {
        let mut tokens = HashSet::new();
        let parts: Vec<&str> = name.split(|c: char| c.is_uppercase() || c == '_' || c == '-')
            .filter(|s| !s.is_empty())
            .collect();
        for part in parts {
            tokens.insert(part.to_lowercase());
        }
        // Also add the full name
        tokens.insert(name.to_lowercase());
        tokens
    }

    /// Build concept sets for all nodes
    pub fn build(&mut self, nodes: &[AstNodeWithFile], concept_tags: &HashMap<String, Vec<String>>) {
        for node in nodes {
            if node.node_type != "FunctionDeclaration" && node.node_type != "MethodDeclaration" {
                continue;
            }

            let mut concepts = HashSet::new();

            // 1. Identifier subwords
            for token in Self::split_identifier(&node.name) {
                concepts.insert(format!("id:{}", token));
            }

            // 2. Concept tags from MCU
            let qname = if node.scope.is_empty() {
                node.name.clone()
            } else {
                format!("{}.{}", node.scope.join("."), node.name)
            };
            if let Some(tags) = concept_tags.get(&qname) {
                for tag in tags {
                    concepts.insert(format!("concept:{}", tag.to_lowercase()));
                }
            }

            // 3. Parameter type names
            for param in &node.parameter_types {
                let parts: Vec<&str> = param.split(':').collect();
                if parts.len() >= 2 {
                    for word in parts[1].split(|c: char| !c.is_alphanumeric()) {
                        if !word.is_empty() {
                            concepts.insert(format!("param:{}", word.to_lowercase()));
                        }
                    }
                }
            }

            // 4. Return type
            if let Some(rt) = &node.return_type {
                for word in rt.split(|c: char| !c.is_alphanumeric()) {
                    if !word.is_empty() && word != "void" && word != "any" {
                        concepts.insert(format!("ret:{}", word.to_lowercase()));
                    }
                }
            }

            self.node_concepts.insert(node.id.clone(), concepts);
        }
    }

    /// Compute semantic similarity between two nodes (0-1)
    pub fn similarity(&self, node_a: &str, node_b: &str) -> (f64, Vec<String>) {
        let key = if node_a < node_b {
            format!("{}|{}", node_a, node_b)
        } else {
            format!("{}|{}", node_b, node_a)
        };

        if let Some(score) = self.similarity_cache.get(&key) {
            return (*score, vec!["cached".to_string()]);
        }

        let concepts_a = self.node_concepts.get(node_a);
        let concepts_b = self.node_concepts.get(node_b);

        if concepts_a.is_none() || concepts_b.is_none() {
            return (0.0, vec!["no concepts".to_string()]);
        }

        let concepts_a = concepts_a.unwrap();
        let concepts_b = concepts_b.unwrap();

        // Jaccard similarity
        let intersection = concepts_a.intersection(concepts_b).count();
        let union = concepts_a.union(concepts_b).count();

        if union == 0 {
            return (0.0, vec!["empty".to_string()]);
        }

        let score = intersection as f64 / union as f64;

        // Identify which signals matched
        let mut signals = Vec::new();
        let id_matches = concepts_a.iter()
            .filter(|c| c.starts_with("id:") && concepts_b.contains(*c))
            .count();
        if id_matches > 0 {
            signals.push(format!("identifier overlap ({} tokens)", id_matches));
        }

        let concept_matches = concepts_a.iter()
            .filter(|c| c.starts_with("concept:") && concepts_b.contains(*c))
            .count();
        if concept_matches > 0 {
            signals.push(format!("concept tags ({} matches)", concept_matches));
        }

        let param_matches = concepts_a.iter()
            .filter(|c| c.starts_with("param:") && concepts_b.contains(*c))
            .count();
        if param_matches > 0 {
            signals.push(format!("parameter types ({} matches)", param_matches));
        }

        let ret_matches = concepts_a.iter()
            .filter(|c| c.starts_with("ret:") && concepts_b.contains(*c))
            .count();
        if ret_matches > 0 {
            signals.push(format!("return type ({} matches)", ret_matches));
        }

        (score, signals)
    }

    /// Find all semantic matches above a threshold
    pub fn find_semantic_matches(
        &self,
        nodes: &[AstNodeWithFile],
        threshold: f64,
    ) -> Vec<SemanticMatch> {
        let function_nodes: Vec<_> = nodes.iter()
            .filter(|n| n.node_type == "FunctionDeclaration" || n.node_type == "MethodDeclaration")
            .collect();

        let mut matches = Vec::new();

        for i in 0..function_nodes.len() {
            for j in (i + 1)..function_nodes.len() {
                let a = &function_nodes[i];
                let b = &function_nodes[j];

                // Skip if same name (that's duplication, not semantic equivalence)
                if a.name == b.name {
                    continue;
                }

                let (score, signals) = self.similarity(&a.id, &b.id);

                if score >= threshold {
                    let cross_lang = a.file_path.rsplit('.').next() != b.file_path.rsplit('.').next();
                    matches.push(SemanticMatch {
                        node_a: a.id.clone(),
                        node_b: b.id.clone(),
                        name_a: a.name.clone(),
                        name_b: b.name.clone(),
                        similarity: (score * 1000.0).round() / 1000.0,
                        signals,
                        cross_language: cross_lang,
                    });
                }
            }
        }

        matches.sort_by(|a, b| b.similarity.partial_cmp(&a.similarity).unwrap_or(std::cmp::Ordering::Equal));
        matches
    }
}

// ==================== Shared types ====================
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AstNodeWithFile {
    pub id: String,
    pub node_type: String,
    pub name: String,
    pub file_path: String,
    pub scope: Vec<String>,
    pub parameter_types: Vec<String>,
    pub return_type: Option<String>,
    pub references: Vec<String>,
    pub is_exported: bool,
}

impl AstNodeWithFile {
    pub fn from_json(node: &serde_json::Value) -> Self {
        AstNodeWithFile {
            id: node["id"].as_str().unwrap_or("").to_string(),
            node_type: node["type"].as_str().unwrap_or("").to_string(),
            name: node["name"].as_str().unwrap_or("").to_string(),
            file_path: node["filePath"].as_str().unwrap_or("").to_string(),
            scope: node["scope"].as_array()
                .map(|a| a.iter().map(|v| v.as_str().unwrap_or("").to_string()).collect())
                .unwrap_or_default(),
            parameter_types: node["parameterTypes"].as_array()
                .map(|a| a.iter().map(|v| v.as_str().unwrap_or("").to_string()).collect())
                .unwrap_or_default(),
            return_type: node["returnType"].as_str().map(|s| s.to_string()),
            references: node["references"].as_array()
                .map(|a| a.iter().map(|v| v.as_str().unwrap_or("").to_string()).collect())
                .unwrap_or_default(),
            is_exported: node["isExported"].as_bool().unwrap_or(false),
        }
    }
}
