// Persistence layer for the Code-Native Engine.
// Serializes the engine state to disk so subsequent server starts skip the
// index-time work. The serialized state includes:
//   - Inverted index (postings, docs, df, avgFieldLength, N)
//   - PDG/HNSW (features, wl vocab, hnsw graph)
//   - ASG (nodes, edges)
//   - Leiden communities
//   - LPA labels
//   - Telemetry
//   - PPR graph
//   - MCU lattice
//   - Blast radius scores
//
// All structures are JSON-serializable. Maps are converted to arrays of pairs.

import { writeFileSync, readFileSync, existsSync, mkdirSync, unlinkSync, statSync } from "fs";
import { join } from "path";
import { Engine } from "./engine";

const CACHE_DIR = "/home/z/my-project/.engine-cache";
const CACHE_FILE = join(CACHE_DIR, "engine.json");

// Helper: recursively convert Maps to {__map: true, entries: [...]} for JSON.
function serializeValue(v: any): any {
  if (v instanceof Map) {
    return {
      __map: true,
      entries: Array.from(v.entries()).map(([k, val]) => [k, serializeValue(val)]),
    };
  }
  if (v instanceof Set) {
    return { __set: true, values: Array.from(v).map(serializeValue) };
  }
  if (Array.isArray(v)) {
    return v.map(serializeValue);
  }
  if (v && typeof v === "object" && v.constructor === Object) {
    const out: any = {};
    for (const [k, val] of Object.entries(v)) {
      out[k] = serializeValue(val);
    }
    return out;
  }
  return v;
}

function deserializeValue(v: any): any {
  if (v && typeof v === "object") {
    if (v.__map) {
      const m = new Map();
      for (const [k, val] of v.entries) {
        m.set(k, deserializeValue(val));
      }
      return m;
    }
    if (v.__set) {
      return new Set(v.values.map(deserializeValue));
    }
    if (Array.isArray(v)) {
      return v.map(deserializeValue);
    }
    const out: any = {};
    for (const [k, val] of Object.entries(v)) {
      out[k] = deserializeValue(val);
    }
    return out;
  }
  return v;
}

export function saveEngine(engine: Engine): void {
  if (!existsSync(CACHE_DIR)) {
    mkdirSync(CACHE_DIR, { recursive: true });
  }
  const serialized = serializeValue({
    version: 2,
    savedAt: new Date().toISOString(),
    bm25Index: engine.bm25Index,
    pdgHnsw: engine.pdgHnsw,
    asg: engine.asg,
    leiden: engine.leiden,
    lpa: engine.lpa,
    telemetry: engine.telemetry,
    pprGraph: engine.pprGraph,
    mcu: engine.mcu,
    blastRadiusScores: engine.blastRadiusScores,
    kcore: engine.kcore,
    ktruss: engine.ktruss,
    otelIngestion: engine.otelIngestion,
    telemetrySource: engine.telemetrySource,
    // Also save the project so we don't re-parse on load
    project: {
      documents: engine.project.documents,
      allNodes: engine.project.allNodes,
      callGraph: engine.project.callGraph,
      dataFlowGraph: engine.project.dataFlowGraph,
      decoratorIndex: engine.project.decoratorIndex,
      // nodesById is reconstructed from allNodes
    },
  });
  const json = JSON.stringify(serialized);
  writeFileSync(CACHE_FILE, json);
  console.log(`[engine] saved ${Math.round(json.length / 1024)}KB to ${CACHE_FILE}`);
}

export function loadEngine(): Engine | null {
  if (!existsSync(CACHE_FILE)) {
    return null;
  }
  try {
    const json = readFileSync(CACHE_FILE, "utf-8");
    const raw = JSON.parse(json);
    const deserialized = deserializeValue(raw);
    if (!deserialized || (deserialized.version !== 1 && deserialized.version !== 2)) {
      console.warn("[engine] cache version mismatch, rebuilding");
      return null;
    }
    // Reconstruct nodesById from allNodes
    const nodesById = new Map<string, any>();
    for (const node of deserialized.project.allNodes) {
      nodesById.set(node.id, node);
    }
    const project = {
      documents: deserialized.project.documents,
      allNodes: deserialized.project.allNodes,
      nodesById,
      callGraph: deserialized.project.callGraph,
      dataFlowGraph: deserialized.project.dataFlowGraph,
      decoratorIndex: deserialized.project.decoratorIndex,
    };
    return {
      project,
      bm25Index: deserialized.bm25Index,
      pdgHnsw: deserialized.pdgHnsw,
      asg: deserialized.asg,
      leiden: deserialized.leiden,
      lpa: deserialized.lpa,
      telemetry: deserialized.telemetry,
      pprGraph: deserialized.pprGraph,
      mcu: deserialized.mcu,
      blastRadiusScores: deserialized.blastRadiusScores,
      kcore: deserialized.kcore,
      ktruss: deserialized.ktruss,
      otelIngestion: deserialized.otelIngestion,
      builtAt: new Date().toISOString(),
      loadedFromCache: true,
      telemetrySource: deserialized.telemetrySource || "structural",
    };
  } catch (e: any) {
    console.warn(`[engine] failed to load cache: ${e.message}, rebuilding`);
    return null;
  }
}

export function hasCachedEngine(): boolean {
  return existsSync(CACHE_FILE);
}

export function clearCache(): void {
  if (existsSync(CACHE_FILE)) {
    try {
      unlinkSync(CACHE_FILE);
      console.log(`[engine] cleared cache at ${CACHE_FILE}`);
    } catch (e: any) {
      console.warn(`[engine] failed to clear cache: ${e.message}`);
    }
  }
}

export function getCacheInfo(): {
  exists: boolean;
  sizeKB: number;
  savedAt: string | null;
  path: string;
} {
  if (!existsSync(CACHE_FILE)) {
    return { exists: false, sizeKB: 0, savedAt: null, path: CACHE_FILE };
  }
  const stat = statSync(CACHE_FILE);
  let savedAt: string | null = null;
  try {
    const json = readFileSync(CACHE_FILE, "utf-8");
    const raw = JSON.parse(json);
    savedAt = raw.savedAt || null;
  } catch {
    // ignore
  }
  return {
    exists: true,
    sizeKB: Math.round(stat.size / 1024),
    savedAt,
    path: CACHE_FILE,
  };
}
