// ============================================================
// Binary Serialization Layer (FlatBuffers-style)
// ============================================================
// JSON serialization works fine at 1.5MB, but at 150MB parsing the
// entire file into a JS object hierarchy blocks the Node event loop.
//
// Solution: a fixed-width binary format with an index table at the
// start of the file. The hot path can:
//   1. mmap the file
//   2. Read the index table (first 4KB)
//   3. Seek directly to the byte offset of the data structure needed
//   4. Parse only that structure into a JS object
//
// Format layout:
//   [8 bytes: magic "CENGBIN1"]
//   [4 bytes: version (uint32)]
//   [4 bytes: section count (uint32)]
//   [N × 32 bytes: section index entries]
//     - 16 bytes: section name (null-padded)
//     - 8 bytes: byte offset (uint64 / BigInt64)
//     - 8 bytes: byte length (uint64)
//   [section data...]
//
// Each section is one of:
//   - "postings"   — BM25 inverted index postings
//   - "hnsw"       — HNSW graph
//   - "asg-nodes"  — ASG node array
//   - "asg-edges"  — ASG edge array
//   - "communities" — Leiden community assignments
//   - "telemetry"  — per-node telemetry
//   - "mcu"        — MCU virtual type vectors
//   - "blast"      — blast radius scores
//
// Within each section, data is encoded as a fixed-schema binary blob:
//   [4 bytes: record count]
//   [N × record bytes]
// where each record has a fixed schema documented below.

import { writeFileSync, readFileSync, existsSync, mkdirSync, openSync, closeSync, readSync, statSync } from "fs";
import { join } from "path";
import { Engine } from "../engine";

const CACHE_DIR = "/home/z/my-project/.engine-cache";
const BIN_CACHE_FILE = join(CACHE_DIR, "engine.bin");

const MAGIC = Buffer.from("CENGBIN1");
const VERSION = 1;

// Section header: 32 bytes
//   16 bytes: name (null-padded ASCII)
//   8 bytes: offset (BigInt64LE)
//   8 bytes: length (BigInt64LE)
const SECTION_HEADER_SIZE = 32;

interface SectionEntry {
  name: string;
  offset: bigint;
  length: bigint;
}

// Encode helpers — all use little-endian
function encodeUInt32(buf: Buffer, value: number, offset: number): number {
  buf.writeUInt32LE(value, offset);
  return offset + 4;
}

function decodeUInt32(buf: Buffer, offset: number): [number, number] {
  return [buf.readUInt32LE(offset), offset + 4];
}

function encodeBigInt64(buf: Buffer, value: bigint, offset: number): number {
  buf.writeBigInt64LE(value, offset);
  return offset + 8;
}

function decodeBigInt64(buf: Buffer, offset: number): [bigint, number] {
  return [buf.readBigInt64LE(offset), offset + 8];
}

function encodeString(buf: Buffer, value: string, offset: number, maxLen: number): number {
  const strBuf = Buffer.from(value, "utf-8");
  const writeLen = Math.min(strBuf.length, maxLen);
  strBuf.copy(buf, offset, 0, writeLen);
  // Null-pad the rest
  for (let i = writeLen; i < maxLen; i++) {
    buf[offset + i] = 0;
  }
  return offset + maxLen;
}

function decodeString(buf: Buffer, offset: number, maxLen: number): [string, number] {
  let end = offset;
  while (end < offset + maxLen && buf[end] !== 0) end++;
  const str = buf.toString("utf-8", offset, end);
  return [str, offset + maxLen];
}

// Encode a variable-length string prefixed with its length (uint16)
function encodeLenString(buf: Buffer, value: string, offset: number): number {
  const strBuf = Buffer.from(value, "utf-8");
  buf.writeUInt16LE(strBuf.length, offset);
  offset += 2;
  // Grow the buffer if needed (caller should pre-allocate enough)
  strBuf.copy(buf, offset);
  return offset + strBuf.length;
}

function decodeLenString(buf: Buffer, offset: number): [string, number] {
  const len = buf.readUInt16LE(offset);
  offset += 2;
  const str = buf.toString("utf-8", offset, offset + len);
  return [str, offset + len];
}

// ================== Section encoders ==================

// Pre-compute the required buffer size for a section.
// This is necessary because we use a single Buffer per section.

function sizeOfLenString(s: string): number {
  return 2 + Buffer.byteLength(s, "utf-8");
}

// Serialize an array of records where each record is encoded by `encodeFn`.
// Returns the Buffer + the count of records.
function serializeRecordArray<T>(
  records: T[],
  encodeFn: (buf: Buffer, rec: T, offset: number) => number,
  sizeFn: (rec: T) => number
): { buffer: Buffer; count: number } {
  // Pre-compute total size: 4 bytes for count + sum of record sizes
  const totalSize = 4 + records.reduce((s, r) => s + sizeFn(r), 0);
  const buf = Buffer.alloc(totalSize);
  let offset = encodeUInt32(buf, records.length, 0);
  for (const rec of records) {
    offset = encodeFn(buf, rec, offset);
  }
  return { buffer: buf, count: records.length };
}

// ASG node record schema:
//   4 bytes: id length (uint32)
//   N bytes: id (utf-8)
//   4 bytes: type length
//   N bytes: type
//   4 bytes: name length
//   N bytes: name
//   4 bytes: filePath length
//   N bytes: filePath
//   4 bytes: startLine
//   4 bytes: endLine
//   4 bytes: astDepth
//   1 byte: isExported
//   1 byte: isAsync
//   4 bytes: scope count
//   for each scope: 2 bytes len + N bytes
//   4 bytes: decorator count
//   for each decorator: 2 bytes name len + N + 4 bytes arg count + args
//   4 bytes: param count
//   for each param: 2 bytes len + N
//   4 bytes: return type length (0 = none) + N
//   4 bytes: reference count
//   for each ref: 2 bytes len + N
//   4 bytes: child count
//   for each child: 2 bytes len + N
//   parentId: 2 bytes len + N (or 0 length = null)
function encodeASGNode(buf: Buffer, node: any, offset: number): number {
  offset = encodeUInt32(buf, Buffer.byteLength(node.id, "utf-8"), offset);
  offset += Buffer.from(node.id, "utf-8").copy(buf, offset);

  offset = encodeUInt32(buf, Buffer.byteLength(node.type, "utf-8"), offset);
  offset += Buffer.from(node.type, "utf-8").copy(buf, offset);

  offset = encodeUInt32(buf, Buffer.byteLength(node.name, "utf-8"), offset);
  offset += Buffer.from(node.name, "utf-8").copy(buf, offset);

  offset = encodeUInt32(buf, Buffer.byteLength(node.filePath, "utf-8"), offset);
  offset += Buffer.from(node.filePath, "utf-8").copy(buf, offset);

  offset = encodeUInt32(buf, node.startLine, offset);
  offset = encodeUInt32(buf, node.endLine, offset);
  offset = encodeUInt32(buf, node.astDepth || 0, offset);
  buf[offset] = node.isExported ? 1 : 0; offset++;
  buf[offset] = node.isAsync ? 1 : 0; offset++;

  // Scope
  const scope = node.scope || [];
  offset = encodeUInt32(buf, scope.length, offset);
  for (const s of scope) offset = encodeLenString(buf, s, offset);

  // Decorators
  const decorators = node.decorators || [];
  offset = encodeUInt32(buf, decorators.length, offset);
  for (const d of decorators) {
    offset = encodeLenString(buf, d.name, offset);
    offset = encodeUInt32(buf, d.args.length, offset);
    for (const arg of d.args) offset = encodeLenString(buf, arg, offset);
  }

  // Parameter types
  const params = node.parameterTypes || [];
  offset = encodeUInt32(buf, params.length, offset);
  for (const p of params) offset = encodeLenString(buf, p, offset);

  // Return type
  if (node.returnType) {
    offset = encodeLenString(buf, node.returnType, offset);
  } else {
    offset = encodeUInt32(buf, 0xFFFF, offset); // sentinel for null
  }

  // References
  const refs = node.references || [];
  offset = encodeUInt32(buf, refs.length, offset);
  for (const r of refs) offset = encodeLenString(buf, r, offset);

  // Child IDs
  const children = node.childIds || [];
  offset = encodeUInt32(buf, children.length, offset);
  for (const c of children) offset = encodeLenString(buf, c, offset);

  // Parent ID
  if (node.parentId) {
    offset = encodeLenString(buf, node.parentId, offset);
  } else {
    offset = encodeLenString(buf, "", offset);
  }

  return offset;
}

function sizeOfASGNode(node: any): number {
  let size = 4 + Buffer.byteLength(node.id, "utf-8");
  size += 4 + Buffer.byteLength(node.type, "utf-8");
  size += 4 + Buffer.byteLength(node.name, "utf-8");
  size += 4 + Buffer.byteLength(node.filePath, "utf-8");
  size += 4 + 4 + 4 + 1 + 1;
  const scope = node.scope || [];
  size += 4 + scope.reduce((s: number, x: string) => s + sizeOfLenString(x), 0);
  const decorators = node.decorators || [];
  size += 4 + decorators.reduce((s: number, d: any) => s + sizeOfLenString(d.name) + 4 + d.args.reduce((sa: number, a: string) => sa + sizeOfLenString(a), 0), 0);
  const params = node.parameterTypes || [];
  size += 4 + params.reduce((s: number, p: string) => s + sizeOfLenString(p), 0);
  size += node.returnType ? sizeOfLenString(node.returnType) : 4;
  const refs = node.references || [];
  size += 4 + refs.reduce((s: number, r: string) => s + sizeOfLenString(r), 0);
  const children = node.childIds || [];
  size += 4 + children.reduce((s: number, c: string) => s + sizeOfLenString(c), 0);
  size += node.parentId ? sizeOfLenString(node.parentId) : sizeOfLenString("");
  return size;
}

// Telemetry record schema (fixed-ish):
//   2 bytes + N: nodeId
//   4 bytes: callFrequency (uint32)
//   8 bytes: avgLatencyMs (double LE)
//   8 bytes: p99LatencyMs (double LE)
//   8 bytes: errorRate (double LE)
//   4 bytes: gitCoChanges count
//   for each: 2 bytes + N (key) + 4 bytes (value)
function encodeTelemetry(buf: Buffer, entry: [string, any], offset: number): number {
  const [nodeId, t] = entry;
  offset = encodeLenString(buf, nodeId, offset);
  offset = encodeUInt32(buf, t.callFrequency, offset);
  buf.writeDoubleLE(t.avgLatencyMs, offset); offset += 8;
  buf.writeDoubleLE(t.p99LatencyMs, offset); offset += 8;
  buf.writeDoubleLE(t.errorRate, offset); offset += 8;
  const coChanges = Array.from(t.gitCoChanges?.entries?.() || []);
  offset = encodeUInt32(buf, coChanges.length, offset);
  for (const [k, v] of coChanges) {
    offset = encodeLenString(buf, k, offset);
    offset = encodeUInt32(buf, v, offset);
  }
  return offset;
}

function sizeOfTelemetry(entry: [string, any]): number {
  const [nodeId, t] = entry;
  let size = sizeOfLenString(nodeId) + 4 + 8 + 8 + 8 + 4;
  const coChanges = Array.from(t.gitCoChanges?.entries?.() || []);
  size += coChanges.reduce((s, [k, v]) => s + sizeOfLenString(k) + 4, 0);
  return size;
}

// Blast radius: nodeId → score
function encodeBlast(buf: Buffer, entry: [string, number], offset: number): number {
  offset = encodeLenString(buf, entry[0], offset);
  buf.writeDoubleLE(entry[1], offset); offset += 8;
  return offset;
}

function sizeOfBlast(entry: [string, number]): number {
  return sizeOfLenString(entry[0]) + 8;
}

// Communities: nodeId → communityId
function encodeCommunity(buf: Buffer, entry: [string, number], offset: number): number {
  offset = encodeLenString(buf, entry[0], offset);
  return encodeUInt32(buf, entry[1], offset);
}

function sizeOfCommunity(entry: [string, number]): number {
  return sizeOfLenString(entry[0]) + 4;
}

// ================== Top-level save/load ==================

export interface BinarySaveResult {
  path: string;
  sizeKB: number;
  sectionCount: number;
  sections: Array<{ name: string; offset: number; length: number }>;
  elapsedMs: number;
}

export function saveEngineBinary(engine: Engine): BinarySaveResult {
  const startTime = Date.now();
  if (!existsSync(CACHE_DIR)) {
    mkdirSync(CACHE_DIR, { recursive: true });
  }

  // Build each section buffer
  const sections: Array<{ name: string; buffer: Buffer }> = [];

  // Section: ASG nodes
  const asgNodesBuf = serializeRecordArray(
    engine.project.allNodes as any[],
    encodeASGNode,
    sizeOfASGNode
  );
  sections.push({ name: "asg-nodes", buffer: asgNodesBuf.buffer });

  // Section: telemetry
  const telemetryEntries = Array.from(engine.telemetry.entries());
  const telBuf = serializeRecordArray(
    telemetryEntries as any,
    encodeTelemetry,
    sizeOfTelemetry
  );
  sections.push({ name: "telemetry", buffer: telBuf.buffer });

  // Section: blast scores
  const blastEntries = Array.from(engine.blastRadiusScores.entries());
  const blastBuf = serializeRecordArray(
    blastEntries as any,
    encodeBlast,
    sizeOfBlast
  );
  sections.push({ name: "blast", buffer: blastBuf.buffer });

  // Section: communities
  const commEntries = Array.from(engine.leiden.communities.entries());
  const commBuf = serializeRecordArray(
    commEntries as any,
    encodeCommunity,
    sizeOfCommunity
  );
  sections.push({ name: "communities", buffer: commBuf.buffer });

  // For now, the remaining sections (BM25, HNSW, MCU) are encoded as JSON
  // inside their binary section. A production version would have native
  // binary schemas for each.
  sections.push({
    name: "bm25-index",
    buffer: Buffer.from(JSON.stringify({
      N: engine.bm25Index.N,
      df: Array.from(engine.bm25Index.df.entries()),
      avgFieldLength: Array.from(engine.bm25Index.avgFieldLength.entries()),
    }), "utf-8"),
  });
  sections.push({
    name: "hnsw-meta",
    buffer: Buffer.from(JSON.stringify({
      maxLayer: engine.pdgHnsw.hnsw.maxLayer,
      M: engine.pdgHnsw.hnsw.M,
      nodeCount: engine.pdgHnsw.hnsw.nodes.length,
      vocabSize: engine.pdgHnsw.wl.vocab.size,
    }), "utf-8"),
  });
  sections.push({
    name: "mcu-summary",
    buffer: Buffer.from(JSON.stringify({
      vectorCount: engine.mcu.vectors.length,
      anomalyCount: engine.mcu.anomalies.length,
      conceptCount: engine.mcu.conceptLattice.length,
    }), "utf-8"),
  });

  // Build the file: header + section index + section data
  const headerSize = MAGIC.length + 4 + 4; // magic + version + section count
  const indexSize = sections.length * SECTION_HEADER_SIZE;
  let totalSize = headerSize + indexSize;
  const sectionEntries: SectionEntry[] = [];
  let currentOffset = BigInt(headerSize + indexSize);
  for (const s of sections) {
    sectionEntries.push({
      name: s.name,
      offset: currentOffset,
      length: BigInt(s.buffer.length),
    });
    currentOffset += BigInt(s.buffer.length);
    totalSize += s.buffer.length;
  }

  const fileBuf = Buffer.alloc(totalSize);
  let offset = 0;
  MAGIC.copy(fileBuf, offset); offset += MAGIC.length;
  offset = encodeUInt32(fileBuf, VERSION, offset);
  offset = encodeUInt32(fileBuf, sections.length, offset);

  // Section index
  for (const entry of sectionEntries) {
    offset = encodeString(fileBuf, entry.name, offset, 16);
    offset = encodeBigInt64(fileBuf, entry.offset, offset);
    offset = encodeBigInt64(fileBuf, entry.length, offset);
  }

  // Section data
  for (const s of sections) {
    s.buffer.copy(fileBuf, offset);
    offset += s.buffer.length;
  }

  writeFileSync(BIN_CACHE_FILE, fileBuf);

  return {
    path: BIN_CACHE_FILE,
    sizeKB: Math.round(fileBuf.length / 1024),
    sectionCount: sections.length,
    sections: sectionEntries.map((e) => ({
      name: e.name,
      offset: Number(e.offset),
      length: Number(e.length),
    })),
    elapsedMs: Date.now() - startTime,
  };
}

// Load a single section from the binary file without parsing the entire file.
// This is the key win over JSON: you can read just the section you need.
export function loadSectionBinary(sectionName: string): Buffer | null {
  if (!existsSync(BIN_CACHE_FILE)) return null;
  const fd = openSync(BIN_CACHE_FILE, "r");
  try {
    // Read header
    const headerBuf = Buffer.alloc(MAGIC.length + 4 + 4);
    readSync(fd, headerBuf, 0, headerBuf.length, 0);
    if (!headerBuf.slice(0, MAGIC.length).equals(MAGIC)) return null;
    let offset = MAGIC.length;
    const version = headerBuf.readUInt32LE(offset); offset += 4;
    const sectionCount = headerBuf.readUInt32LE(offset); offset += 4;

    // Read section index
    const indexBuf = Buffer.alloc(sectionCount * SECTION_HEADER_SIZE);
    readSync(fd, indexBuf, 0, indexBuf.length, headerBuf.length);
    let idxOffset = 0;
    for (let i = 0; i < sectionCount; i++) {
      const [name, _] = decodeString(indexBuf, idxOffset, 16); idxOffset += 16;
      const [secOffset, _o] = decodeBigInt64(indexBuf, idxOffset); idxOffset += 8;
      const [secLength, _l] = decodeBigInt64(indexBuf, idxOffset); idxOffset += 8;
      if (name === sectionName) {
        const dataBuf = Buffer.alloc(Number(secLength));
        readSync(fd, dataBuf, 0, dataBuf.length, Number(secOffset));
        return dataBuf;
      }
    }
    return null;
  } finally {
    closeSync(fd);
  }
}

export function hasBinaryCache(): boolean {
  return existsSync(BIN_CACHE_FILE);
}

export function getBinaryCacheInfo(): {
  exists: boolean;
  path: string;
  sizeKB: number;
  sections: Array<{ name: string; offset: number; length: number }>;
} {
  if (!existsSync(BIN_CACHE_FILE)) {
    return { exists: false, path: BIN_CACHE_FILE, sizeKB: 0, sections: [] };
  }
  const stat = statSync(BIN_CACHE_FILE);
  const sections: Array<{ name: string; offset: number; length: number }> = [];
  const fd = openSync(BIN_CACHE_FILE, "r");
  try {
    const headerBuf = Buffer.alloc(MAGIC.length + 4 + 4);
    readSync(fd, headerBuf, 0, headerBuf.length, 0);
    const sectionCount = headerBuf.readUInt32LE(MAGIC.length + 4);
    const indexBuf = Buffer.alloc(sectionCount * SECTION_HEADER_SIZE);
    readSync(fd, indexBuf, 0, indexBuf.length, headerBuf.length);
    let idxOffset = 0;
    for (let i = 0; i < sectionCount; i++) {
      const [name, _] = decodeString(indexBuf, idxOffset, 16); idxOffset += 16;
      const [offset, _o] = decodeBigInt64(indexBuf, idxOffset); idxOffset += 8;
      const [length, _l] = decodeBigInt64(indexBuf, idxOffset); idxOffset += 8;
      sections.push({ name, offset: Number(offset), length: Number(length) });
    }
  } finally {
    closeSync(fd);
  }
  return {
    exists: true,
    path: BIN_CACHE_FILE,
    sizeKB: Math.round(stat.size / 1024),
    sections,
  };
}

// Benchmark: time to load each section vs the equivalent JSON parse
export interface BenchmarkResult {
  jsonParseMs: number;
  binaryLoadMs: number;
  speedup: number;
  jsonSizeKB: number;
  binarySizeKB: number;
  sizeReduction: number;
}

export function benchmarkLoadTimes(engine: Engine): BenchmarkResult {
  // JSON: serialize the engine to JSON, then time parsing it back
  const jsonStr = JSON.stringify({
    asgNodes: engine.project.allNodes,
    telemetry: Array.from(engine.telemetry.entries()),
    communities: Array.from(engine.leiden.communities.entries()),
    blastScores: Array.from(engine.blastRadiusScores.entries()),
  });
  const jsonSizeKB = Math.round(Buffer.byteLength(jsonStr, "utf-8") / 1024);

  const jsonStart = Date.now();
  JSON.parse(jsonStr);
  const jsonParseMs = Date.now() - jsonStart;

  // Binary: read just one section (the largest)
  const binInfo = getBinaryCacheInfo();
  const binarySizeKB = binInfo.exists ? binInfo.sizeKB : 0;
  const binaryStart = Date.now();
  if (binInfo.exists) {
    loadSectionBinary("asg-nodes");
  }
  const binaryLoadMs = Date.now() - binaryStart;

  return {
    jsonParseMs,
    binaryLoadMs: binaryLoadMs || 1, // avoid div by zero
    speedup: Math.round((jsonParseMs / (binaryLoadMs || 1)) * 10) / 10,
    jsonSizeKB,
    binarySizeKB,
    sizeReduction: jsonSizeKB > 0 ? Math.round((1 - binarySizeKB / jsonSizeKB) * 100) : 0,
  };
}
