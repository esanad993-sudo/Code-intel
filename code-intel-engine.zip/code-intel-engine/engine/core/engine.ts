// Orchestrator: builds all indexes / graphs once, exposes cached instances.
// Used by API routes to avoid recomputing on every request.
//
// Persistence: on first build, the engine is serialized to disk at
// .engine-cache/engine.json (legacy JSON) + .engine-cache/engine.bin
// (binary, FlatBuffers-style). On subsequent loads, we read from disk first
// and skip the index-time work. Use the /api/reindex endpoint to force
// a rebuild (e.g. after editing sample codebase files or uploading OTel).

import { getProject, getProjectAsync, rebuildProject } from "./ast/project";
import { buildInvertedIndex, InvertedIndex, getIdfStats } from "./algorithms/bm25";
import { buildPDGHNSW, PDGHNSWResult } from "./algorithms/pdg-hnsw";
import { buildASG, ASG, runLeiden, LeidenResult } from "./algorithms/leiden";
import { runLPA, LPAState } from "./algorithms/lpa";
import {
  generateSyntheticTelemetry,
  buildPPRGraph,
  runPPR,
  PPRGraph,
  TelemetryData,
} from "./algorithms/ppr";
import { buildMCU, MCUResult } from "./algorithms/mcu";
import { runKCore, KCoreResult } from "./algorithms/kcore";
import { runKTruss, KTrussResult } from "./algorithms/ktruss";
import {
  ingestOTelDump,
  hasOTelDump,
  getOTelDumpInfo,
  writeSampleOTelDump,
  IngestionResult,
} from "./algorithms/otel-sink";
import { buildWLHashIndex, WLHashIndex, findCrossLanguageClones, CrossLanguageClone } from "./algorithms/isomorphism";
import { saveEngineBinary, hasBinaryCache, getBinaryCacheInfo, BenchmarkResult, benchmarkLoadTimes } from "./binary-cache";
import { ASTProject } from "./ast/types";
import { loadEngine, saveEngine, hasCachedEngine, getCacheInfo, clearCache } from "./persistence";

export interface Engine {
  project: ASTProject;
  bm25Index: InvertedIndex;
  pdgHnsw: PDGHNSWResult;
  asg: ASG;
  leiden: LeidenResult;
  lpa: LPAState;
  telemetry: Map<string, TelemetryData>;
  pprGraph: PPRGraph;
  mcu: MCUResult;
  blastRadiusScores: Map<string, number>;
  // Upgrade 1: k-core decomposition (fast, always computed)
  kcore: KCoreResult;
  // k-truss decomposition (lazy — only computed on demand via /api/kcore?truss=true)
  // Why lazy: k-truss takes 192-204ms (2/3 of index time) and is NOT on the query path.
  // k-core at 3-7ms provides the same structural hub information for query-time use.
  // k-truss is available for deeper analysis but doesn't block index construction.
  ktruss: KTrussResult | null;
  // Upgrade 3: OTel ingestion (if a dump file is present)
  otelIngestion: IngestionResult | null;
  // Module 10: WL hash inverted index for structural isomorphism
  wlHashIndex: WLHashIndex | null;
  // Pre-computed cross-language clones
  crossLanguageClones: CrossLanguageClone[];
  // Metadata
  builtAt: string;
  loadedFromCache: boolean;
  telemetrySource: "synthetic" | "otel" | "structural";
}

let cachedEngine: Engine | null = null;

export function getEngine(): Engine {
  if (cachedEngine) return cachedEngine;

  // Try loading from disk first
  if (hasCachedEngine()) {
    const loaded = loadEngine();
    if (loaded) {
      cachedEngine = {
        ...loaded,
        builtAt: (loaded as any).builtAt || new Date().toISOString(),
        loadedFromCache: true,
      };
      console.log(`[engine] loaded from cache (built at ${cachedEngine.builtAt})`);
      return cachedEngine;
    }
  }

  // Build fresh
  console.log("[engine] building fresh (no cache found)");
  cachedEngine = buildEngineInternal();
  // Save to disk for next time
  try {
    saveEngine(cachedEngine);
  } catch (e: any) {
    console.warn(`[engine] failed to save cache: ${e.message}`);
  }
  return cachedEngine;
}

function buildEngineInternal(): Engine {
  const project = getProject();
  const bm25Index = buildInvertedIndex(project);
  const pdgHnsw = buildPDGHNSW(project);
  const asg = buildASG(project);
  const leiden = runLeiden(asg, 5);
  const lpa = runLPA(project, 20);

  // Upgrade 3: OTel ingestion — if a dump file is present at
  // .engine-cache/otel-dump.json, use real telemetry; else fall back to synthetic.
  let telemetry: Map<string, TelemetryData> = generateSyntheticTelemetry(project);
  let otelIngestion: IngestionResult | null = null;
  let telemetrySource: "synthetic" | "otel" | "structural" = "structural";
  if (hasOTelDump()) {
    try {
      otelIngestion = ingestOTelDump(project);
      if (otelIngestion.matchedSpans > 0) {
        // Merge: OTel spans override synthetic for matched nodes;
        // unmatched nodes keep their synthetic telemetry.
        for (const [nodeId, t] of otelIngestion.nodeTelemetry) {
          telemetry.set(nodeId, t);
        }
        telemetrySource = "otel";
        console.log(`[engine] ingested ${otelIngestion.matchedSpans} OTel spans (${otelIngestion.unmatchedSpans} unmatched)`);
      }
    } catch (e: any) {
      console.warn(`[engine] OTel ingestion failed: ${e.message}`);
    }
  }

  const pprGraph = buildPPRGraph(project, telemetry);

  const topHotNode = Array.from(telemetry.values())
    .filter((t) => {
      const n = project.nodesById.get(t.nodeId);
      return (
        n &&
        (n.type === "FunctionDeclaration" || n.type === "MethodDeclaration")
      );
    })
    .sort((a, b) => b.callFrequency - a.callFrequency)[0];
  const blastRadiusScores = new Map<string, number>();
  if (topHotNode) {
    const ppr = runPPR(pprGraph, project, telemetry, topHotNode.nodeId, 0.85, 100, 1e-6);
    for (const n of project.allNodes) {
      blastRadiusScores.set(n.id, ppr.scores.get(n.id) ?? 0);
    }
  }

  const mcu = buildMCU(project, telemetry, blastRadiusScores);

  // Upgrade 1: k-core decomposition
  const kcore = runKCore(project, asg, leiden.communities);

  // k-truss is LAZY — not computed at index time.
  // It's available on demand via the API but doesn't block index construction.
  // k-core (3-7ms) provides structural hubs for query-time use.
  // k-truss (192-204ms) is for deeper analysis only.
  const ktruss: KTrussResult | null = null;

  // Module 10: WL hash inverted index for structural isomorphism matching
  let wlHashIndex: WLHashIndex | null = null;
  let crossLanguageClones: CrossLanguageClone[] = [];
  try {
    wlHashIndex = buildWLHashIndex(pdgHnsw.pdg, 3);
    crossLanguageClones = findCrossLanguageClones(project, wlHashIndex);
  } catch (e: any) {
    console.warn(`[engine] WL hash index build failed: ${e.message}`);
  }

  return {
    project,
    bm25Index,
    pdgHnsw,
    asg,
    leiden,
    lpa,
    telemetry,
    pprGraph,
    mcu,
    blastRadiusScores,
    kcore,
    ktruss,
    otelIngestion,
    wlHashIndex,
    crossLanguageClones,
    builtAt: new Date().toISOString(),
    loadedFromCache: false,
    telemetrySource,
  };
}

// Force a rebuild — clears cache, rebuilds engine, saves new cache (JSON + binary).
export function rebuildEngine(): Engine {
  clearCache();
  cachedEngine = null;
  // Also force a fresh project parse (clears the in-memory AST cache)
  rebuildProject();
  const engine = buildEngineInternal();
  cachedEngine = engine;
  try {
    saveEngine(engine);
  } catch (e: any) {
    console.warn(`[engine] failed to save JSON cache: ${e.message}`);
  }
  // Upgrade 4: also save binary cache
  try {
    saveEngineBinary(engine);
  } catch (e: any) {
    console.warn(`[engine] failed to save binary cache: ${e.message}`);
  }
  return engine;
}

export function getBM25IdfStats() {
  return getIdfStats(getEngine().bm25Index);
}

export function getEngineCacheInfo() {
  return {
    json: getCacheInfo(),
    binary: getBinaryCacheInfo(),
    otel: getOTelDumpInfo(),
    binaryAvailable: hasBinaryCache(),
    otelAvailable: hasOTelDump(),
  };
}

export function getEngineBenchmark(): BenchmarkResult {
  return benchmarkLoadTimes(getEngine());
}

// Generate a sample OTel dump matching the sample codebase, save to disk,
// then rebuild the engine to use real telemetry.
export function loadSampleOTelAndRebuild(): Engine {
  const project = getProject();
  writeSampleOTelDump(project);
  return rebuildEngine();
}

// Async variant — uses the Python sidecar for non-TS files.
// Falls back to the sync version if sidecar is unavailable.
export async function getEngineAsync(): Promise<Engine> {
  if (cachedEngine) return cachedEngine;

  // Try cache first
  if (hasCachedEngine()) {
    const loaded = loadEngine();
    if (loaded) {
      cachedEngine = {
        ...loaded,
        builtAt: (loaded as any).builtAt || new Date().toISOString(),
        loadedFromCache: true,
      };
      return cachedEngine;
    }
  }

  // Build with async project (uses sidecar for Python/Rust/Go)
  try {
    const project = await getProjectAsync();
    const bm25Index = buildInvertedIndex(project);
    const pdgHnsw = buildPDGHNSW(project);
    const asg = buildASG(project);
    const leiden = runLeiden(asg, 5);
    const lpa = runLPA(project, 20);
    let telemetry = generateSyntheticTelemetry(project);
    let otelIngestion: IngestionResult | null = null;
    let telemetrySource: "synthetic" | "otel" | "structural" = "structural";
    if (hasOTelDump()) {
      try {
        otelIngestion = ingestOTelDump(project);
        if (otelIngestion.matchedSpans > 0) {
          for (const [nodeId, t] of otelIngestion.nodeTelemetry) {
            telemetry.set(nodeId, t);
          }
          telemetrySource = "otel";
        }
      } catch {}
    }
    const pprGraph = buildPPRGraph(project, telemetry);
    const topHotNode = Array.from(telemetry.values())
      .filter((t) => {
        const n = project.nodesById.get(t.nodeId);
        return n && (n.type === "FunctionDeclaration" || n.type === "MethodDeclaration");
      })
      .sort((a, b) => b.callFrequency - a.callFrequency)[0];
    const blastRadiusScores = new Map<string, number>();
    if (topHotNode) {
      const ppr = runPPR(pprGraph, project, telemetry, topHotNode.nodeId, 0.85, 100, 1e-6);
      for (const n of project.allNodes) {
        blastRadiusScores.set(n.id, ppr.scores.get(n.id) ?? 0);
      }
    }
    const mcu = buildMCU(project, telemetry, blastRadiusScores);
    const kcore = runKCore(project, asg, leiden.communities);
    cachedEngine = {
      project,
      bm25Index,
      pdgHnsw,
      asg,
      leiden,
      lpa,
      telemetry,
      pprGraph,
      mcu,
      blastRadiusScores,
      kcore,
      otelIngestion,
      builtAt: new Date().toISOString(),
      loadedFromCache: false,
      telemetrySource,
    };
    try {
      saveEngine(cachedEngine);
    } catch (e: any) {
      console.warn(`[engine] failed to save cache: ${e.message}`);
    }
    try {
      saveEngineBinary(cachedEngine);
    } catch (e: any) {
      console.warn(`[engine] failed to save binary cache: ${e.message}`);
    }
    return cachedEngine;
  } catch (e: any) {
    console.warn(`[engine] async build failed, falling back to sync: ${e.message}`);
    return getEngine();
  }
}
