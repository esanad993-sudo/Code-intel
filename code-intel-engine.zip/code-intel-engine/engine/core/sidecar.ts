// Python sidecar client — runs Python as a subprocess for each batch.
// This is more robust in sandboxed environments than keeping a long-running
// uvicorn process alive.
//
// In production you'd swap this out for an HTTP fetch to a persistent
// uvicorn/gunicorn deployment; the contract is identical.

import { spawn } from "child_process";
import { writeFileSync, mkdtempSync } from "fs";
import { join } from "path";
import { tmpdir } from "os";

const SIDECAR_PATH = "/home/z/my-project/mini-services/code-intel/index.py";

export interface SidecarParseFile {
  path: string;
  content: string;
  language?: string;
}

export interface SidecarParseResponse {
  documents: any[];
  errors: any[];
  language_count: number;
}

export interface SidecarEmbedResponse {
  vectors: number[][];
  dim: number;
  backend: string;
}

// Run a Python script with JSON stdin and parse JSON stdout.
function runPython(payload: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const proc = spawn("python3", [SIDECAR_PATH, "--json-stdin"], {
      cwd: "/home/z/my-project/mini-services/code-intel",
      env: { ...process.env, PYTHONWARNINGS: "ignore" },
      stdio: ["pipe", "pipe", "pipe"],
    });
    const stdout: Buffer[] = [];
    const stderr: Buffer[] = [];
    proc.stdout.on("data", (d) => stdout.push(d));
    proc.stderr.on("data", (d) => stderr.push(d));
    proc.on("error", (e) => reject(e));
    proc.on("close", (code) => {
      if (code !== 0) {
        const errText = Buffer.concat(stderr).toString("utf-8");
        reject(new Error(`python exited ${code}: ${errText.slice(0, 1000)}`));
        return;
      }
      try {
        const text = Buffer.concat(stdout).toString("utf-8");
        resolve(JSON.parse(text));
      } catch (e: any) {
        reject(new Error(`python output not JSON: ${(e as Error).message}`));
      }
    });
    proc.stdin.write(JSON.stringify(payload));
    proc.stdin.end();
  });
}

export async function parseFiles(
  files: SidecarParseFile[]
): Promise<SidecarParseResponse> {
  return runPython({ op: "parse", files });
}

export async function embedTexts(
  texts: string[]
): Promise<SidecarEmbedResponse> {
  return runPython({ op: "embed", texts });
}

export async function checkHealth(): Promise<{
  status: string;
  languages: string[];
  embeddings: string;
  embed_dim: number;
}> {
  return runPython({ op: "health" });
}
