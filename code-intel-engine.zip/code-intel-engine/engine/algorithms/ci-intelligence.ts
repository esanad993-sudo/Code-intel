// ============================================================
// Tier 1 Features: CI Intelligence Queries
// ============================================================
// Five production features that require NO new algorithms.
// They're new queries against data the engine already computes:
//   1. Change impact → test selection (the killer CI feature)
//   2. Dead code detection (reverse graph query)
//   3. Duplication detection (expose WL hash index)
//   4. Test gap analysis (test→production reachability)
//   5. Migration planning (BM25+PPR+Leiden ordered plan)

import { ASTProject, ASTNode } from "../ast/types";
import { Engine } from "../engine";
import { runPPR } from "./ppr";
import { search as bm25Search } from "./bm25";

// ==================== 1. Change Impact → Test Selection ====================
// Given a git diff (list of changed file:line ranges), map to AST nodes,
// run PPR from each changed node, find test files in the impact set.
// Output: "run only these tests."

export interface ChangedFile {
  path: string;
  startLine: number;
  endLine: number;
}

export interface TestSelectionResult {
  changedNodes: Array<{ nodeId: string; name: string; type: string; filePath: string }>;
  impactedNodes: Array<{ nodeId: string; name: string; filePath: string; score: number }>;
  testFiles: Array<{ filePath: string; reason: string; confidence: number }>;
  skippedTests: number;
  totalTests: number;
  reductionPercent: number;
}

function isTestFile(filePath: string): boolean {
  const lower = filePath.toLowerCase();
  return (
    lower.endsWith("_test.go") ||
    lower.endsWith(".test.ts") ||
    lower.endsWith(".spec.ts") ||
    lower.endsWith("_test.py") ||
    lower.startsWith("test_") ||
    lower.includes("/tests/") ||
    lower.includes("/__tests__/") ||
    lower.endsWith(".test.js") ||
    lower.endsWith(".spec.js") ||
    lower.endsWith("_test.rs") ||
    lower.includes("/tests/")
  );
}

export function selectTestsForChanges(
  project: ASTProject,
  engine: Engine,
  changes: ChangedFile[]
): TestSelectionResult {
  // Step 1: Map changed file:line ranges to AST nodes
  const changedNodeIds: string[] = [];
  for (const change of changes) {
    for (const node of project.allNodes) {
      if (node.filePath !== change.path) continue;
      // Node overlaps with the changed line range
      if (node.startLine <= change.endLine && node.endLine >= change.startLine) {
        if (
          node.type === "FunctionDeclaration" ||
          node.type === "MethodDeclaration" ||
          node.type === "ClassDeclaration" ||
          node.type === "VariableDeclaration" ||
          node.type === "PropertyDeclaration"
        ) {
          changedNodeIds.push(node.id);
        }
      }
    }
  }

  const changedNodes = changedNodeIds.map(id => {
    const n = project.nodesById.get(id)!;
    return { nodeId: id, name: n.name, type: n.type, filePath: n.filePath };
  });

  // Step 2: Run PPR from each changed node to find impact set
  const impactedNodeIds = new Set<string>();
  const impactScores = new Map<string, number>();

  for (const nodeId of changedNodeIds) {
    try {
      const result = runPPR(
        engine.pprGraph, project, engine.telemetry, nodeId, 0.85, 50, 1e-4
      );
      for (const [id, score] of result.scores) {
        if (score > 0.001 && id !== nodeId) {
          impactedNodeIds.add(id);
          impactScores.set(id, Math.max(impactScores.get(id) || 0, score));
        }
      }
    } catch {
      // PPR may fail if node is not in the PPR graph
    }

    // Also add direct call-graph neighbors (faster, catches edges PPR misses)
    const callers = engine.project.callGraph.get(nodeId) || [];
    for (const callerId of callers) {
      impactedNodeIds.add(callerId);
      impactScores.set(callerId, Math.max(impactScores.get(callerId) || 0, 0.5));
    }
  }

  const impactedNodes = Array.from(impactedNodeIds).map(id => {
    const n = project.nodesById.get(id);
    return {
      nodeId: id,
      name: n?.name || "?",
      filePath: n?.filePath || "?",
      score: impactScores.get(id) || 0,
    };
  }).sort((a, b) => b.score - a.score);

  // Step 3: Find test files in the impact set
  const testFileSet = new Map<string, { reason: string; confidence: number }>();

  for (const node of impactedNodes) {
    if (isTestFile(node.filePath)) {
      // Direct hit: test file itself is in the impact set
      const existing = testFileSet.get(node.filePath);
      const confidence = Math.min(1, node.score * 10);
      if (!existing || existing.confidence < confidence) {
        testFileSet.set(node.filePath, {
          reason: `Test file impacted by ${node.name} (score: ${node.score.toFixed(4)})`,
          confidence,
        });
      }
    }
    // Check if any test file in the project calls this production node
    for (const other of project.allNodes) {
      if (!isTestFile(other.filePath)) continue;
      if (other.filePath === node.filePath) continue;
      // Does the test file reference this production node?
      const refs = other.references;
      if (refs.some(r => r.startsWith("call:") && r.slice(5) === node.name)) {
        const existing = testFileSet.get(other.filePath);
        const confidence = Math.min(0.9, node.score * 8 + 0.3);
        if (!existing || existing.confidence < confidence) {
          testFileSet.set(other.filePath, {
            reason: `Tests ${other.name} calls ${node.name} (score: ${node.score.toFixed(4)})`,
            confidence,
          });
        }
      }
    }
  }

  // Also check: do any test files directly import the changed file?
  for (const change of changes) {
    const changedFileName = change.path.split("/").pop() || change.path;
    const changedBaseName = changedFileName.replace(/\.[^.]+$/, "");
    for (const node of project.allNodes) {
      if (!isTestFile(node.filePath)) continue;
      // Check if the test file imports the changed file
      const refs = node.references;
      if (refs.some(r => r.includes(changedBaseName))) {
        const existing = testFileSet.get(node.filePath);
        if (!existing) {
          testFileSet.set(node.filePath, {
            reason: `Test file imports ${changedFileName}`,
            confidence: 0.5,
          });
        }
      }
    }
  }

  // Count total test files in the project
  const totalTests = new Set(
    project.allNodes
      .filter(n => isTestFile(n.filePath))
      .map(n => n.filePath)
  ).size;

  const testFiles = Array.from(testFileSet.entries()).map(([filePath, info]) => ({
    filePath,
    reason: info.reason,
    confidence: info.confidence,
  })).sort((a, b) => b.confidence - a.confidence);

  return {
    changedNodes,
    impactedNodes: impactedNodes.slice(0, 20),
    testFiles,
    skippedTests: totalTests - testFiles.length,
    totalTests,
    reductionPercent: totalTests > 0 ? Math.round((1 - testFiles.length / totalTests) * 100) : 0,
  };
}

// ==================== 2. Dead Code Detection ====================
// Reverse direction: find nodes that are:
//   - Not reachable from any entry point (main, route handlers, exported functions)
//   - Have zero incoming call edges
//   - Not exported
// Just invert the graph and query.

export interface DeadCodeResult {
  deadNodes: Array<{
    nodeId: string;
    name: string;
    type: string;
    filePath: string;
    reason: string;
  }>;
  entryPoints: number;
  totalNodes: number;
  deadPercent: number;
}

export function detectDeadCode(
  project: ASTProject,
  engine: Engine
): DeadCodeResult {
  // Step 1: Identify entry points
  const entryPointIds = new Set<string>();
  for (const node of project.allNodes) {
    // main functions
    if (node.name === "main" && (node.type === "FunctionDeclaration" || node.type === "MethodDeclaration")) {
      entryPointIds.add(node.id);
    }
    // Route handlers (@route decorator)
    if (node.decorators.some(d => d.name === "@route")) {
      entryPointIds.add(node.id);
    }
    // Exported functions
    if (node.isExported && (node.type === "FunctionDeclaration" || node.type === "ClassDeclaration")) {
      entryPointIds.add(node.id);
    }
    // Go: func main()
    if (node.name === "main" && node.filePath.endsWith(".go")) {
      entryPointIds.add(node.id);
    }
    // Rust: fn main()
    if (node.name === "main" && node.filePath.endsWith(".rs")) {
      entryPointIds.add(node.id);
    }
    // Python: if __name__ == "__main__" → just look for top-level functions
    if (node.scope.length === 0 && node.type === "FunctionDeclaration" && node.filePath.endsWith(".py")) {
      entryPointIds.add(node.id);
    }
  }

  // Step 2: BFS from entry points through the call graph (forward direction)
  const reachable = new Set<string>();
  const queue = Array.from(entryPointIds);
  while (queue.length > 0) {
    const id = queue.shift()!;
    if (reachable.has(id)) continue;
    reachable.add(id);
    const callees = project.callGraph.get(id) || [];
    for (const callee of callees) {
      if (!reachable.has(callee)) queue.push(callee);
    }
  }

  // Step 3: Find dead nodes (not reachable, not exported, not entry points)
  const deadNodes: DeadCodeResult["deadNodes"] = [];
  for (const node of project.allNodes) {
    if (
      node.type !== "FunctionDeclaration" &&
      node.type !== "MethodDeclaration" &&
      node.type !== "VariableDeclaration" &&
      node.type !== "PropertyDeclaration"
    ) continue;

    if (entryPointIds.has(node.id)) continue;
    if (reachable.has(node.id)) continue;
    if (node.isExported) continue;

    // Check if anyone calls this node
    let hasIncomingCalls = false;
    for (const [callerId, callees] of project.callGraph) {
      if (callees.includes(node.id)) {
        hasIncomingCalls = true;
        break;
      }
    }

    if (!hasIncomingCalls) {
      deadNodes.push({
        nodeId: node.id,
        name: node.name,
        type: node.type,
        filePath: node.filePath,
        reason: node.scope.length > 0
          ? `${node.scope.join(".")}.${node.name} is never called and not reachable from any entry point`
          : `${node.name} is never called, not exported, and not reachable from any entry point`,
      });
    }
  }

  const totalFunctionLike = project.allNodes.filter(n =>
    n.type === "FunctionDeclaration" || n.type === "MethodDeclaration" ||
    n.type === "VariableDeclaration" || n.type === "PropertyDeclaration"
  ).length;

  return {
    deadNodes: deadNodes.sort((a, b) => a.filePath.localeCompare(b.filePath)),
    entryPoints: entryPointIds.size,
    totalNodes: totalFunctionLike,
    deadPercent: totalFunctionLike > 0 ? Math.round((deadNodes.length / totalFunctionLike) * 100) : 0,
  };
}

// ==================== 3. Duplication Detection ====================
// Expose the WL hash index as a "find duplicates" API.
// Same WL hash = structurally identical code.

export interface DuplicationResult {
  duplicateGroups: Array<{
    hash: string;
    count: number;
    nodes: Array<{
      nodeId: string;
      name: string;
      type: string;
      filePath: string;
      language: string;
    }>;
    crossLanguage: boolean;
  }>;
  totalDuplicates: number;
  crossLanguageClones: number;
}

export function detectDuplicates(
  project: ASTProject,
  engine: Engine
): DuplicationResult {
  if (!engine.wlHashIndex) {
    return { duplicateGroups: [], totalDuplicates: 0, crossLanguageClones: 0 };
  }

  const groups: DuplicationResult["duplicateGroups"] = [];
  let totalDupes = 0;
  let crossLang = 0;

  for (const [hash, nodeIds] of engine.wlHashIndex.hashToNodes) {
    if (nodeIds.length < 2) continue;

    const nodes = nodeIds.map(id => {
      const n = project.nodesById.get(id);
      const ext = n?.filePath.split(".").pop() || "?";
      return {
        nodeId: id,
        name: n?.name || "?",
        type: n?.type || "?",
        filePath: n?.filePath || "?",
        language: ext,
      };
    });

    const languages = new Set(nodes.map(n => n.language));
    const isCrossLang = languages.size > 1;
    if (isCrossLang) crossLang++;
    totalDupes += nodes.length - 1;

    groups.push({ hash, count: nodes.length, nodes, crossLanguage: isCrossLang });
  }

  groups.sort((a, b) => b.count - a.count);

  return {
    duplicateGroups: groups.slice(0, 20),
    totalDuplicates: totalDupes,
    crossLanguageClones: crossLang,
  };
}

// ==================== 4. Test Gap Analysis ====================
// Map test files → their call subgraph → production nodes reachable.
// Production nodes with no test ancestor = untested.
// Blast radius × untested = prioritized risk surface.

export interface TestGapResult {
  untestedNodes: Array<{
    nodeId: string;
    name: string;
    type: string;
    filePath: string;
    scope: string[];
    blastRadiusScore: number;
    riskScore: number;
    reason: string;
  }>;
  testedNodes: number;
  untestedCount: number;
  coveragePercent: number;
  highRiskUntested: number;
}

export function analyzeTestGaps(
  project: ASTProject,
  engine: Engine
): TestGapResult {
  // Step 1: Identify test files and their call targets
  const testCallTargets = new Set<string>();
  for (const node of project.allNodes) {
    if (!isTestFile(node.filePath)) continue;
    // Find what this test calls
    for (const ref of node.references) {
      if (ref.startsWith("call:")) {
        const calleeName = ref.slice(5);
        const candidates = project.allNodes.filter(n =>
          (n.type === "FunctionDeclaration" || n.type === "MethodDeclaration") &&
          n.name === calleeName
        );
        for (const c of candidates) {
          testCallTargets.add(c.id);
        }
      }
    }
  }

  // Step 2: Find production nodes (function-like, not in test files)
  const productionNodes = project.allNodes.filter(n =>
    (n.type === "FunctionDeclaration" || n.type === "MethodDeclaration") &&
    !isTestFile(n.filePath)
  );

  // Step 3: Find untested nodes (not in testCallTargets)
  const untested: TestGapResult["untestedNodes"] = [];
  let testedCount = 0;

  for (const node of productionNodes) {
    if (testCallTargets.has(node.id)) {
      testedCount++;
      continue;
    }

    // Also check: is this node reachable from any test file's call graph?
    let reachable = false;
    for (const testId of testCallTargets) {
      const callees = project.callGraph.get(testId) || [];
      if (callees.includes(node.id)) {
        reachable = true;
        break;
      }
    }

    if (reachable) {
      testedCount++;
      continue;
    }

    // This node is untested
    const blastScore = engine.blastRadiusScores.get(node.id) || 0;
    const isEntryPoint = node.name === "main" || node.decorators.some(d => d.name === "@route");
    const riskScore = blastScore * 100 + (isEntryPoint ? 50 : 0) + (node.isExported ? 10 : 0);

    untested.push({
      nodeId: node.id,
      name: node.name,
      type: node.type,
      filePath: node.filePath,
      scope: node.scope,
      blastRadiusScore: Math.round(blastScore * 10000) / 10000,
      riskScore: Math.round(riskScore),
      reason: isEntryPoint
        ? "Entry point with no test coverage"
        : node.isExported
          ? "Exported function with no test coverage"
          : "No test file calls this function",
    });
  }

  untested.sort((a, b) => b.riskScore - a.riskScore);

  return {
    untestedNodes: untested.slice(0, 30),
    testedNodes: testedCount,
    untestedCount: untested.length,
    coveragePercent: productionNodes.length > 0
      ? Math.round((testedCount / productionNodes.length) * 100)
      : 0,
    highRiskUntested: untested.filter(n => n.riskScore > 50).length,
  };
}

// ==================== 5. Migration Planning ====================
// "We're moving from X to Y."
// BM25 finds all uses of X, PPR ranks by centrality, Leiden groups by subsystem.
// Output: ordered migration plan, subsystem by subsystem.

export interface MigrationPlanResult {
  query: string;
  affectedNodes: Array<{
    nodeId: string;
    name: string;
    filePath: string;
    scope: string[];
    community: number;
    blastRadiusScore: number;
    migrationOrder: number;
    reason: string;
  }>;
  communityOrder: Array<{
    communityId: number;
    nodeCount: number;
    totalBlastRadius: number;
    description: string;
  }>;
  totalAffected: number;
  estimatedEffort: string;
}

export function planMigration(
  project: ASTProject,
  engine: Engine,
  oldLibrary: string,
  newLibrary?: string
): MigrationPlanResult {
  // Step 1: BM25 search for all uses of the old library
  const results = bm25Search(project, engine.bm25Index, { text: oldLibrary }, { expandSynonyms: true });

  // Step 2: Group by Leiden community
  const communityNodes = new Map<number, Array<{ nodeId: string; name: string; filePath: string; scope: string[]; blastRadiusScore: number }>>();
  const affectedNodes: MigrationPlanResult["affectedNodes"] = [];

  for (const result of results.slice(0, 50)) {
    const node = result.node;
    const community = engine.leiden.communities.get(node.id) ?? -1;
    const blastScore = engine.blastRadiusScores.get(node.id) || 0;

    if (!communityNodes.has(community)) communityNodes.set(community, []);
    communityNodes.get(community)!.push({
      nodeId: node.id,
      name: node.name,
      filePath: node.filePath,
      scope: node.scope,
      blastRadiusScore: blastScore,
    });
  }

  // Step 3: Order communities by total blast radius (highest risk first)
  const communityOrder: MigrationPlanResult["communityOrder"] = [];
  for (const [commId, nodes] of communityNodes) {
    const totalBlast = nodes.reduce((s, n) => s + n.blastRadiusScore, 0);
    const nodeNames = nodes.map(n => n.name).slice(0, 3).join(", ");
    communityOrder.push({
      communityId: commId,
      nodeCount: nodes.length,
      totalBlastRadius: Math.round(totalBlast * 10000) / 10000,
      description: `Community ${commId}: ${nodes.length} nodes (${nodeNames}${nodes.length > 3 ? "..." : ""})`,
    });
  }
  communityOrder.sort((a, b) => b.totalBlastRadius - a.totalBlastRadius);

  // Step 4: Assign migration order (community by community, blast radius within)
  let order = 0;
  for (const comm of communityOrder) {
    const nodes = communityNodes.get(comm.communityId) || [];
    nodes.sort((a, b) => b.blastRadiusScore - a.blastRadiusScore);
    for (const n of nodes) {
      affectedNodes.push({
        ...n,
        community: comm.communityId,
        migrationOrder: ++order,
        reason: `Community ${comm.communityId}, blast radius ${n.blastRadiusScore.toFixed(4)}`,
      });
    }
  }

  // Estimate effort
  const total = affectedNodes.length;
  const effort = total <= 5 ? "Small (< 1 hour)" :
    total <= 15 ? "Medium (half day)" :
    total <= 30 ? "Large (1-2 days)" :
    "Major (1+ sprint)";

  return {
    query: `Migrate from ${oldLibrary}${newLibrary ? ` to ${newLibrary}` : ""}`,
    affectedNodes: affectedNodes.slice(0, 30),
    communityOrder: communityOrder.slice(0, 10),
    totalAffected: total,
    estimatedEffort: effort,
  };
}
