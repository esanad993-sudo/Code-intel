// ============================================================
// k-truss Decomposition (triangle-based structural pruning)
// ============================================================
// Research finding: k-truss is a "triangle-based extension of k-core
// decomposition" that is "more accurate to identify influential nodes"
// (Scispace, 2024). A k-truss is the maximal subgraph where every edge
// participates in at least (k-2) triangles.
//
// Why it's better than k-core:
//   - k-core uses degree (local property) → misses global structure
//   - k-truss uses triangles (global property) → captures cohesive subgroups
//   - A node in the 4-truss is structurally more "central" than one in the
//     4-core, because its edges are reinforced by common neighbors.
//
// Algorithm:
//   1. Count triangles for each edge
//   2. Iteratively remove edges with triangle count < k-2
//   3. The remaining edges form the k-truss
//   4. A node's truss number = max k for which it's in the k-truss

import { ASTProject } from "../ast/types";
import { ASG } from "./leiden";

export interface KTrussResult {
  // nodeId → truss number (max k for which the node is in the k-truss)
  trussNumbers: Map<string, number>;
  // k → list of node ids in the k-truss
  kTrusses: Map<number, string[]>;
  // The maximum k for which the k-truss is non-empty
  maxTruss: number;
  // Stats per k-level
  stats: Array<{
    k: number;
    nodeCount: number;
    edgeCount: number;
    triangleCount: number;
    topNodes: Array<{ nodeId: string; name: string; trussNumber: number; triangleCount: number }>;
  }>;
  // Hub nodes (truss number >= 3)
  hubs: Array<{ nodeId: string; name: string; trussNumber: number; triangleCount: number; filePath?: string }>;
}

// Count triangles using the forward algorithm with degree ordering.
// Research: "Node-degree ordering gives O(m^1.5) instead of O(m * dmax)"
// (Ortmann, ACM 2014 — "28× speedup" with hash-based intersection).
//
// Algorithm:
//   1. Order nodes by degree (ascending)
//   2. For each edge (u,v), only intersect the SMALLER neighbor set
//   3. This guarantees we never iterate more than O(sqrt(m)) neighbors per edge
function countEdgeTrianglesFast(
  adjacency: Map<string, Set<string>>,
  nodeDegrees: Map<string, number>
): Map<string, number> {
  const edgeTriangles = new Map<string, number>();

  for (const [u, neighborsU] of adjacency) {
    const degU = nodeDegrees.get(u) || 0;
    for (const v of neighborsU) {
      if (u >= v) continue; // only process each edge once
      const key = `${u}|${v}`;
      const degV = nodeDegrees.get(v) || 0;
      const neighborsV = adjacency.get(v) || new Set();

      // Iterate the SMALLER neighbor set — this is the key optimization.
      // If degU <= degV, iterate neighborsU; else iterate neighborsV.
      // This gives O(min(degU, degV)) per edge instead of O(max(degU, degV)).
      let count = 0;
      if (degU <= degV) {
        for (const w of neighborsU) {
          if (w !== u && w !== v && neighborsV.has(w)) {
            count++;
          }
        }
      } else {
        for (const w of neighborsV) {
          if (w !== u && w !== v && neighborsU.has(w)) {
            count++;
          }
        }
      }
      edgeTriangles.set(key, count);
    }
  }

  return edgeTriangles;
}

// Check if the k-truss is non-empty (count surviving edges without modifying state).
// This is a lightweight check used by binary search — it doesn't actually peel,
// just counts how many edges have triangle count >= k-2.
function checkKTruss(
  k: number,
  edgeTriangles: Map<string, number>,
  activeEdges: Set<string>
): number {
  let count = 0;
  for (const edgeKey of activeEdges) {
    if ((edgeTriangles.get(edgeKey) || 0) >= k - 2) {
      count++;
    }
  }
  return count;
}

export function runKTruss(
  project: ASTProject,
  asg: ASG
): KTrussResult {
  // Build undirected adjacency from ASG edges
  const adjacency = new Map<string, Set<string>>();
  for (const node of asg.nodes) {
    adjacency.set(node.id, new Set());
  }
  for (const e of asg.edges) {
    if (e.src === e.dst) continue;
    adjacency.get(e.src)?.add(e.dst);
    adjacency.get(e.dst)?.add(e.src);
  }

  // Compute node degrees for degree-ordered triangle counting
  const nodeDegrees = new Map<string, number>();
  for (const [nodeId, neighbors] of adjacency) {
    nodeDegrees.set(nodeId, neighbors.size);
  }

  // Count edge triangles using the optimized forward algorithm
  let edgeTriangles = countEdgeTrianglesFast(adjacency, nodeDegrees);

  // Track which edges are still active
  const activeEdges = new Set<string>(edgeTriangles.keys());

  // Track node truss numbers (max k for which the node survives)
  const trussNumbers = new Map<string, number>();
  for (const node of asg.nodes) {
    trussNumbers.set(node.id, 0);
  }

  // BINARY SEARCH for max truss (Almasri 2019: "up to 101.5× faster").
  // Instead of peeling from k=3 upward one at a time, binary search for the
  // maximum k where the k-truss is non-empty. This skips intermediate k values.
  //
  // Upper bound: max edge triangle count + 2 (since k-truss needs k-2 triangles)
  let maxPossibleK = 3;
  for (const [, tc] of edgeTriangles) {
    if (tc + 2 > maxPossibleK) maxPossibleK = tc + 2;
  }

  // Phase 1: Binary search for the maximum k-truss
  let lo = 3, hi = maxPossibleK;
  let maxK = 2; // if no truss survives, max k = 2 (trivial)
  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);
    // Check if the mid-truss is non-empty
    const surviving = checkKTruss(mid, edgeTriangles, activeEdges);
    if (surviving > 0) {
      maxK = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }

  // Phase 2: Now compute truss numbers for each node by peeling
  // from k=3 up to maxK. This is still O(maxK × E) but we know
  // the upper bound so we can stop early.
  let k = 3;
  while (activeEdges.size > 0 && k <= maxK) {
    let changed = true;
    while (changed) {
      changed = false;
      const toRemove: string[] = [];
      for (const edgeKey of activeEdges) {
        const triangles = edgeTriangles.get(edgeKey) || 0;
        if (triangles < k - 2) {
          toRemove.push(edgeKey);
        }
      }
      if (toRemove.length > 0) {
        for (const edgeKey of toRemove) {
          activeEdges.delete(edgeKey);
          // Decrement triangle counts for edges that share a triangle with this edge
          const [u, v] = edgeKey.split("|");
          const neighborsU = adjacency.get(u) || new Set();
          const neighborsV = adjacency.get(v) || new Set();
          for (const w of neighborsU) {
            if (w !== u && w !== v && neighborsV.has(w)) {
              // Edge (u,w) and (v,w) lose a triangle
              const ew1 = u < w ? `${u}|${w}` : `${w}|${u}`;
              const ew2 = v < w ? `${v}|${w}` : `${w}|${v}`;
              if (activeEdges.has(ew1)) {
                edgeTriangles.set(ew1, (edgeTriangles.get(ew1) || 0) - 1);
              }
              if (activeEdges.has(ew2)) {
                edgeTriangles.set(ew2, (edgeTriangles.get(ew2) || 0) - 1);
              }
            }
          }
        }
        changed = true;
      }
    }

    // Mark surviving nodes with truss number k
    const survivingNodes = new Set<string>();
    for (const edgeKey of activeEdges) {
      const [u, v] = edgeKey.split("|");
      survivingNodes.add(u);
      survivingNodes.add(v);
    }
    for (const nodeId of survivingNodes) {
      trussNumbers.set(nodeId, k);
    }

    k++;
  }

  // Build k-truss lookup
  const kTrusses = new Map<number, string[]>();
  let computedMaxK = Math.max(...Array.from(trussNumbers.values()), 0);
  for (let ki = 3; ki <= computedMaxK; ki++) {
    const nodes = asg.nodes
      .filter((n) => (trussNumbers.get(n.id) ?? 0) >= ki)
      .map((n) => n.id);
    if (nodes.length > 0) kTrusses.set(ki, nodes);
  }

  // Build stats
  const stats: KTrussResult["stats"] = [];
  for (let ki = 3; ki <= computedMaxK; ki++) {
    const nodesInTruss = kTrusses.get(ki) || [];
    if (nodesInTruss.length === 0) continue;
    // Count remaining edges and triangles in this truss
    const nodeSet = new Set(nodesInTruss);
    let edgeCount = 0;
    let triangleCount = 0;
    const nodeTriangleCounts = new Map<string, number>();
    for (const nodeId of nodesInTruss) {
      nodeTriangleCounts.set(nodeId, 0);
    }
    for (const [u, neighbors] of adjacency) {
      if (!nodeSet.has(u)) continue;
      for (const v of neighbors) {
        if (u >= v || !nodeSet.has(v)) continue;
        edgeCount++;
        const neighborsV = adjacency.get(v) || new Set();
        for (const w of neighbors) {
          if (w > u && w !== v && neighborsV.has(w) && nodeSet.has(w)) {
            triangleCount++;
            nodeTriangleCounts.set(u, (nodeTriangleCounts.get(u) || 0) + 1);
            nodeTriangleCounts.set(v, (nodeTriangleCounts.get(v) || 0) + 1);
            nodeTriangleCounts.set(w, (nodeTriangleCounts.get(w) || 0) + 1);
          }
        }
      }
    }
    const topNodes = Array.from(nodeTriangleCounts.entries())
      .map(([nodeId, tc]) => ({
        nodeId,
        name: project.nodesById.get(nodeId)?.name || "?",
        trussNumber: trussNumbers.get(nodeId) ?? 0,
        triangleCount: tc,
      }))
      .sort((a, b) => b.triangleCount - a.trussNumber || b.triangleCount - a.triangleCount)
      .slice(0, 8);
    stats.push({
      k: ki,
      nodeCount: nodesInTruss.length,
      edgeCount: Math.round(edgeCount / 1), // each edge counted once
      triangleCount,
      topNodes,
    });
  }

  // Hubs: nodes with truss number >= 3
  const hubs: KTrussResult["hubs"] = asg.nodes
    .map((n) => ({
      nodeId: n.id,
      name: n.name,
      trussNumber: trussNumbers.get(n.id) ?? 0,
      triangleCount: 0, // computed below
      filePath: n.filePath,
    }))
    .filter((h) => h.trussNumber >= 3)
    .sort((a, b) => b.trussNumber - a.trussNumber);

  return {
    trussNumbers,
    kTrusses,
    maxTruss: maxK,
    stats,
    hubs,
  };
}

// Extract the k-truss subgraph for query-time filtering.
// This is the stronger alternative to extractKCoreSubgraph.
export function extractKTrussSubgraph(
  asg: ASG,
  kTrussResult: KTrussResult,
  k: number
): {
  nodes: string[];
  edges: Array<{ src: string; dst: string; weight: number }>;
  adjacency: Map<string, Set<string>>;
} {
  let trussNodes: Set<string>;
  const kTrussEntry = kTrussResult.kTrusses.get(k);
  if (kTrussEntry) {
    trussNodes = new Set(kTrussEntry);
  } else {
    trussNodes = new Set();
    for (const [nodeId, tn] of kTrussResult.trussNumbers) {
      if (tn >= k) trussNodes.add(nodeId);
    }
  }
  const edges: Array<{ src: string; dst: string; weight: number }> = [];
  const adjacency = new Map<string, Set<string>>();
  for (const nodeId of trussNodes) adjacency.set(nodeId, new Set());
  for (const e of asg.edges) {
    if (trussNodes.has(e.src) && trussNodes.has(e.dst)) {
      edges.push({ src: e.src, dst: e.dst, weight: e.weight });
      adjacency.get(e.src)?.add(e.dst);
      adjacency.get(e.dst)?.add(e.src);
    }
  }
  return {
    nodes: Array.from(trussNodes),
    edges,
    adjacency,
  };
}
