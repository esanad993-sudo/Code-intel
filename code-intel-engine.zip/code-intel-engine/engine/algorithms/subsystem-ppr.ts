// ============================================================
// Subsystem-Bounded PageRank
// ============================================================
// Instead of running PPR over the entire ASG from a global seed,
// we partition the graph by Leiden community and run power iteration
// only within the community containing the seed node.
//
// This keeps index/query time bounded by community size (~10-20 nodes
// per community) rather than global graph size (potentially 10,000+ nodes).
//
// For a seed in community C, the blast radius is computed over only
// the subgraph induced by C. Cross-community edges are treated as
// "leakage" — they contribute to a `crossCommunityImpact` score
// but don't pull the random walk into other subsystems.

import { ASTProject, ASTNode } from "../ast/types";
import { TelemetryData, PPRGraph, PPRResult } from "./ppr";
import { ASG } from "./leiden";

export interface SubsystemPPRResult {
  // The community ID the seed belongs to
  communityId: number;
  // Nodes within the community (the bounded subgraph)
  subgraphNodes: string[];
  // PPR scores restricted to the community
  scores: Map<string, number>;
  // Top impacted nodes within the community
  topImpacted: Array<{
    nodeId: string;
    name: string;
    type: string;
    score: number;
    path: string[];
    cumulativeLatencyMs: number;
  }>;
  // Cross-community leakage: how much probability "leaked" out of the community
  // via cross-community edges. Low leakage = self-contained subsystem.
  // High leakage = the change ripples into other subsystems.
  crossCommunityLeakage: number;
  // List of communities impacted by the leakage
  impactedCommunities: Array<{
    communityId: number;
    leakageScore: number;
    nodeCount: number;
  }>;
  // Localized blast radius (1 - seed score, within the community only)
  localBlastRadius: number;
  // Iterations the power iteration took to converge
  iterations: number;
  // Wall-clock time taken (for benchmarking)
  elapsedMs: number;
}

// Build a per-community subgraph view.
// For each community, we extract the induced subgraph + track which edges
// cross community boundaries (for leakage computation).
export interface CommunitySubgraph {
  communityId: number;
  nodes: Set<string>;
  // Edges fully inside the community
  internalEdges: Array<{ src: string; dst: string; weight: number }>;
  // Edges that cross to another community
  crossEdges: Array<{
    src: string;
    dst: string;
    weight: number;
    dstCommunity: number;
  }>;
  // Adjacency: src -> [{dst, weight}] for internal edges only
  internalAdjacency: Map<string, Array<{ dst: string; weight: number }>>;
}

export function buildCommunitySubgraphs(
  pprGraph: PPRGraph,
  communities: Map<string, number>
): Map<number, CommunitySubgraph> {
  const result = new Map<number, CommunitySubgraph>();

  // Group nodes by community
  const commToNodes = new Map<number, Set<string>>();
  for (const [nodeId, commId] of communities) {
    if (!commToNodes.has(commId)) commToNodes.set(commId, new Set());
    commToNodes.get(commId)!.add(nodeId);
  }

  for (const [commId, nodes] of commToNodes) {
    const internalEdges: CommunitySubgraph["internalEdges"] = [];
    const crossEdges: CommunitySubgraph["crossEdges"] = [];
    const internalAdjacency = new Map<string, Array<{ dst: string; weight: number }>>();
    for (const n of nodes) internalAdjacency.set(n, []);

    for (const nodeId of nodes) {
      const outs = pprGraph.outAdjacency.get(nodeId) || [];
      for (const e of outs) {
        const dstComm = communities.get(e.dst);
        if (dstComm === commId) {
          // Internal edge
          internalEdges.push({ src: nodeId, dst: e.dst, weight: e.weight });
          internalAdjacency.get(nodeId)?.push({ dst: e.dst, weight: e.weight });
        } else if (dstComm !== undefined) {
          // Cross-community edge
          crossEdges.push({
            src: nodeId,
            dst: e.dst,
            weight: e.weight,
            dstCommunity: dstComm,
          });
        }
      }
    }

    result.set(commId, {
      communityId: commId,
      nodes,
      internalEdges,
      crossEdges,
      internalAdjacency,
    });
  }

  return result;
}

// Normalize the internal adjacency weights to transition probabilities.
// Cross-community edges contribute to "leakage" — they're modeled as
// probability that escapes the subsystem (teleport back to the seed).
function normalizeInternalWeights(subgraph: CommunitySubgraph): void {
  for (const [src, outs] of subgraph.internalAdjacency) {
    const total = outs.reduce((s, e) => s + e.weight, 0);
    if (total > 0) {
      for (const e of outs) e.weight /= total;
    }
  }
}

export function runSubsystemPPR(
  project: ASTProject,
  pprGraph: PPRGraph,
  communities: Map<string, number>,
  telemetry: Map<string, TelemetryData>,
  seedNodeId: string,
  damping: number = 0.85,
  maxIterations: number = 50,
  tolerance: number = 1e-6
): SubsystemPPRResult {
  const startTime = Date.now();

  const seedCommunity = communities.get(seedNodeId);
  if (seedCommunity === undefined) {
    return {
      communityId: -1,
      subgraphNodes: [],
      scores: new Map(),
      topImpacted: [],
      crossCommunityLeakage: 0,
      impactedCommunities: [],
      localBlastRadius: 0,
      iterations: 0,
      elapsedMs: Date.now() - startTime,
    };
  }

  // Build (or reuse) the community subgraphs
  const subgraphs = buildCommunitySubgraphs(pprGraph, communities);
  const subgraph = subgraphs.get(seedCommunity)!;
  normalizeInternalWeights(subgraph);

  const subgraphNodes = Array.from(subgraph.nodes);
  const N = subgraphNodes.length;
  if (N === 0) {
    return {
      communityId: seedCommunity,
      subgraphNodes: [],
      scores: new Map(),
      topImpacted: [],
      crossCommunityLeakage: 0,
      impactedCommunities: [],
      localBlastRadius: 0,
      iterations: 0,
      elapsedMs: Date.now() - startTime,
    };
  }

  // Compute leakage: sum of cross-edge weights as fraction of total out-weight
  let totalInternalWeight = 0;
  let totalCrossWeight = 0;
  for (const nodeId of subgraphNodes) {
    const outs = pprGraph.outAdjacency.get(nodeId) || [];
    for (const e of outs) {
      const dstComm = communities.get(e.dst);
      if (dstComm === seedCommunity) {
        totalInternalWeight += e.weight;
      } else {
        totalCrossWeight += e.weight;
      }
    }
  }
  const crossCommunityLeakage =
    totalInternalWeight + totalCrossWeight > 0
      ? totalCrossWeight / (totalInternalWeight + totalCrossWeight)
      : 0;

  // Power iteration within the subgraph
  const scores = new Map<string, number>();
  for (const n of subgraphNodes) scores.set(n, 0);
  scores.set(seedNodeId, 1);

  let iter = 0;
  let delta = Infinity;
  while (iter < maxIterations && delta > tolerance) {
    iter++;
    const newScores = new Map<string, number>();
    for (const n of subgraphNodes) newScores.set(n, 0);

    for (const src of subgraphNodes) {
      const s = scores.get(src) || 0;
      if (s === 0) continue;
      const outs = subgraph.internalAdjacency.get(src) || [];
      if (outs.length === 0) {
        // Dangling node within subgraph — redistribute within community
        for (const n of subgraphNodes) {
          newScores.set(n, (newScores.get(n) || 0) + s / N);
        }
      } else {
        for (const e of outs) {
          newScores.set(e.dst, (newScores.get(e.dst) || 0) + s * e.weight);
        }
      }
    }

    // Apply damping: PPR = damping * walk + (1-damping) * seed
    for (const n of subgraphNodes) {
      const v =
        (newScores.get(n) || 0) * damping +
        (1 - damping) * (n === seedNodeId ? 1 : 0);
      newScores.set(n, v);
    }

    delta = 0;
    for (const n of subgraphNodes) {
      delta += Math.abs((newScores.get(n) || 0) - (scores.get(n) || 0));
    }
    for (const [k, v] of newScores) scores.set(k, v);
  }

  // Compute top impacted nodes within the community
  const topImpacted: SubsystemPPRResult["topImpacted"] = [];
  for (const [nodeId, score] of scores) {
    if (nodeId === seedNodeId) continue;
    if (score <= 0) continue;
    const node = project.nodesById.get(nodeId);
    if (!node) continue;
    const t = telemetry.get(nodeId);
    topImpacted.push({
      nodeId,
      name: node.name,
      type: node.type,
      score,
      path: findInternalPath(subgraph, seedNodeId, nodeId),
      cumulativeLatencyMs: t?.p99LatencyMs || 0,
    });
  }
  topImpacted.sort((a, b) => b.score - a.score);
  topImpacted.length = Math.min(topImpacted.length, 10);

  // Add cumulative latency along path
  for (const item of topImpacted) {
    let latency = 0;
    for (let i = 0; i < item.path.length - 1; i++) {
      const t = telemetry.get(item.path[i + 1]);
      if (t) latency += t.p99LatencyMs;
    }
    item.cumulativeLatencyMs = Math.round(latency * 10) / 10;
  }

  // Compute impacted communities via cross-edges
  const commLeakage = new Map<number, number>();
  for (const ce of subgraph.crossEdges) {
    const srcScore = scores.get(ce.src) || 0;
    if (srcScore === 0) continue;
    const dstComm = ce.dstCommunity;
    commLeakage.set(dstComm, (commLeakage.get(dstComm) || 0) + srcScore * ce.weight * 0.1);
  }
  const impactedCommunities: SubsystemPPRResult["impactedCommunities"] = [];
  const subgraphsAll = subgraphs;
  for (const [commId, leak] of commLeakage) {
    const sg = subgraphsAll.get(commId);
    impactedCommunities.push({
      communityId: commId,
      leakageScore: Math.round(leak * 10000) / 10000,
      nodeCount: sg?.nodes.size || 0,
    });
  }
  impactedCommunities.sort((a, b) => b.leakageScore - a.leakageScore);

  const seedScore = scores.get(seedNodeId) || 0;
  const localBlastRadius = 1 - seedScore;

  return {
    communityId: seedCommunity,
    subgraphNodes,
    scores,
    topImpacted,
    crossCommunityLeakage: Math.round(crossCommunityLeakage * 10000) / 10000,
    impactedCommunities,
    localBlastRadius: Math.round(localBlastRadius * 10000) / 10000,
    iterations: iter,
    elapsedMs: Date.now() - startTime,
  };
}

// Dijkstra within the subgraph to find the highest-probability path
function findInternalPath(
  subgraph: CommunitySubgraph,
  src: string,
  dst: string
): string[] {
  if (src === dst) return [src];
  const dist = new Map<string, number>();
  const prev = new Map<string, string | null>();
  for (const n of subgraph.nodes) {
    dist.set(n, Infinity);
    prev.set(n, null);
  }
  dist.set(src, 0);
  const queue = new Set<string>(subgraph.nodes);
  while (queue.size > 0) {
    let minNode: string | null = null;
    let minDist = Infinity;
    for (const n of queue) {
      const d = dist.get(n) || Infinity;
      if (d < minDist) {
        minDist = d;
        minNode = n;
      }
    }
    if (minNode === null || minDist === Infinity) break;
    queue.delete(minNode);
    if (minNode === dst) break;
    const outs = subgraph.internalAdjacency.get(minNode) || [];
    for (const e of outs) {
      if (!queue.has(e.dst)) continue;
      if (e.weight <= 0) continue;
      const alt = dist.get(minNode)! + -Math.log(e.weight);
      if (alt < (dist.get(e.dst) || Infinity)) {
        dist.set(e.dst, alt);
        prev.set(e.dst, minNode);
      }
    }
  }
  const path: string[] = [];
  let cur: string | null = dst;
  while (cur) {
    path.unshift(cur);
    cur = prev.get(cur) || null;
    if (cur === src) {
      path.unshift(cur);
      break;
    }
  }
  if (path[0] !== src) return [src, dst];
  return path;
}
