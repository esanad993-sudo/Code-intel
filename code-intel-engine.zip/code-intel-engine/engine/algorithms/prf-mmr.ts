// ============================================================
// Pseudo-Relevance Feedback (PRF) + Maximal Marginal Relevance (MMR)
// ============================================================
// Research findings:
//   PRF: "Query expansion via pseudo-relevance feedback has been proven
//   effective in many IR tasks" (ACM, 2026). Top-k results from the initial
//   search are used to expand the query with their most distinctive terms.
//
//   MMR: "Reduces redundancy while maintaining query relevance" (ResearchGate).
//   When selecting impact nodes, MMR ensures we don't return 5 nodes that
//   all call the same function — it maximizes diversity.

import { ASTProject, SearchResult } from "../ast/types";
import { InvertedIndex, bm25Score } from "./bm25";

// ------------------- Pseudo-Relevance Feedback -------------------
// After the initial BM25 search, take the top-k results and extract
// their most distinctive terms (high TF in the result set, low DF globally).
// Add these terms to the query and re-search.
//
// This is deterministic, requires no ML, and improves recall by 8-10%
// (per AutoIndex, alphaxiv 2026).

export interface PRFExpansion {
  originalTerms: string[];
  expandedTerms: string[];
  feedbackTerms: Array<{ term: string; score: number; source: string }>;
}

export function pseudoRelevanceFeedback(
  project: ASTProject,
  index: InvertedIndex,
  query: string,
  initialResults: SearchResult[],
  topK: number = 3,
  maxExpansionTerms: number = 5
): PRFExpansion {
  // Take the top-k results
  const topResults = initialResults.slice(0, topK);
  if (topResults.length === 0) {
    return { originalTerms: [], expandedTerms: [], feedbackTerms: [] };
  }

  // Collect term frequencies across the top-k results
  const termFreqInTopK = new Map<string, number>();
  for (const result of topResults) {
    const indexed = index.docs.get(result.node.id);
    if (!indexed) continue;
    for (const [term, freq] of indexed.tokenFreq) {
      termFreqInTopK.set(term, (termFreqInTopK.get(term) || 0) + freq);
    }
  }

  // Score each term by KL-divergence-like score:
  // high frequency in top-k results, low frequency globally (= low DF)
  const feedbackTerms: Array<{ term: string; score: number; source: string }> = [];
  for (const [term, freqInTopK] of termFreqInTopK) {
    const df = index.df.get(term) || 0;
    if (df === 0) continue;
    // Skip terms already in the query
    if (query.toLowerCase().includes(term)) continue;
    // Score: freq in top-k / (df + 1) — distinctive terms get high scores
    const score = freqInTopK / (df + 1);
    // Find which result this term came from
    const source = topResults.find((r) => {
      const indexed = index.docs.get(r.node.id);
      return indexed?.tokenFreq.has(term);
    });
    feedbackTerms.push({
      term,
      score: Math.round(score * 1000) / 1000,
      source: source ? source.node.name : "?",
    });
  }

  feedbackTerms.sort((a, b) => b.score - a.score);
  const expanded = feedbackTerms.slice(0, maxExpansionTerms).map((t) => t.term);

  return {
    originalTerms: query.split(/[\s,]+/).filter(Boolean),
    expandedTerms: expanded,
    feedbackTerms: feedbackTerms.slice(0, maxExpansionTerms),
  };
}

// ------------------- Maximal Marginal Relevance (MMR) -------------------
// Select a diverse subset of impact nodes.
// MMR(node) = λ * relevance(node, query) - (1-λ) * max(similarity(node, selected))
//
// This prevents the payload from containing 5 nodes that all call
// the same function — it maximizes coverage of different code paths.

export interface MMRResult {
  selected: Array<{ nodeId: string; name: string; relevance: number; diversity: number; mmrScore: number }>;
  rejected: Array<{ nodeId: string; name: string; reason: string }>;
}

export function maximalMarginalRelevance(
  candidates: Array<{
    nodeId: string;
    name: string;
    relevance: number;
    references: string[];
    filePath: string;
  }>,
  lambda: number = 0.7,
  maxSelect: number = 10
): MMRResult {
  // ADAPTIVE LAMBDA: if the query is narrow (few candidates), prefer relevance (high λ).
  // If the query is broad (many candidates), prefer diversity (low λ).
  // Research: "λ=1.0 gives pure relevance, λ=0.3 emphasizes diversity for exploration"
  // (LinkedIn, Mixpeek 2025).
  const effectiveLambda = candidates.length <= 5
    ? 0.9  // narrow query → mostly relevance
    : candidates.length <= 15
      ? 0.7  // medium → balance
      : 0.5; // broad query → emphasize diversity

  if (candidates.length === 0) {
    return { selected: [], rejected: [] };
  }

  const selected: MMRResult["selected"] = [];
  const selectedIds = new Set<string>();
  const rejected: MMRResult["rejected"] = [];

  // Sort candidates by relevance
  const sorted = [...candidates].sort((a, b) => b.relevance - a.relevance);

  while (selected.length < maxSelect && sorted.length > 0) {
    let bestNode: typeof sorted[0] | null = null;
    let bestMMR = -Infinity;
    let bestIdx = -1;

    for (let i = 0; i < sorted.length; i++) {
      const candidate = sorted[i];
      // Compute max similarity to already selected nodes
      let maxSim = 0;
      for (const sel of selected) {
        const sim = jaccardSimilarity(
          candidate.references,
          candidates.find((c) => c.nodeId === sel.nodeId)?.references || []
        );
        if (sim > maxSim) maxSim = sim;
      }
      // Also penalize same-file nodes (they're likely redundant)
      const sameFilePenalty = selected.some((s) => {
        const selNode = candidates.find((c) => c.nodeId === s.nodeId);
        return selNode && selNode.filePath === candidate.filePath;
      }) ? 0.3 : 0;

      const mmr = effectiveLambda * candidate.relevance - (1 - effectiveLambda) * maxSim - sameFilePenalty;
      if (mmr > bestMMR) {
        bestMMR = mmr;
        bestNode = candidate;
        bestIdx = i;
      }
    }

    if (bestNode && bestIdx >= 0) {
      selected.push({
        nodeId: bestNode.nodeId,
        name: bestNode.name,
        relevance: bestNode.relevance,
        diversity: 1 - (bestMMR < 0 ? 0 : bestMMR / (effectiveLambda * bestNode.relevance || 1)),
        mmrScore: Math.round(bestMMR * 1000) / 1000,
      });
      selectedIds.add(bestNode.nodeId);
      sorted.splice(bestIdx, 1);
    } else {
      break;
    }
  }

  // Remaining candidates are rejected
  for (const c of sorted) {
    rejected.push({
      nodeId: c.nodeId,
      name: c.name,
      reason: "redundant with selected nodes",
    });
  }

  return { selected, rejected };
}

// Jaccard similarity between two reference arrays
function jaccardSimilarity(a: string[], b: string[]): number {
  if (a.length === 0 || b.length === 0) return 0;
  const setA = new Set(a);
  const setB = new Set(b);
  let intersection = 0;
  for (const x of setA) {
    if (setB.has(x)) intersection++;
  }
  const union = setA.size + setB.size - intersection;
  return union > 0 ? intersection / union : 0;
}
