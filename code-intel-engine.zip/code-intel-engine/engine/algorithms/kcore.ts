// ============================================================
// Module 8: K-Core Decomposition (Graph Degeneracy)
// ============================================================
// When an AI agent asks a question, running Leiden or PPR on the entire
// codebase graph yields too much structural noise.
//
// K-core decomposition strips away the "leaves" of the codebase
// (small utility files, simple model mappings) and isolates the highly
// interconnected structural "hubs" (core orchestration engines,
// authentication pipelines).
//
// A k-core is the maximal subgraph where every node has degree >= k
// within the subgraph. We compute it iteratively: peel away nodes with
// degree < k, recompute degrees, repeat until stable.
//
// The "core number" of a node is the largest k for which it belongs to
// the k-core. Nodes with high core numbers are structural hubs.

import { ASTProject } from "../ast/types";
import { ASG } from "./leiden";

export interface KCoreResult {
  // nodeId -> core number (the largest k for which the node is in the k-core)
  coreNumbers: Map<string, number>;
  // k -> list of node ids in the k-core
  kCores: Map<number, string[]>;
  // The maximum k for which the k-core is non-empty (the graph's degeneracy)
  degeneracy: number;
  // Stats per k-level
  stats: Array<{
    k: number;
    nodeCount: number;
    edgeCount: number;
    avgDegree: number;
    // Top nodes in this core (by degree within the subgraph)
    topNodes: Array<{ nodeId: string; name: string; degree: number; coreNumber: number }>;
  }>;
  // Hub nodes (core number >= 3, i.e. in the 3-core or higher)
  hubs: Array<{ nodeId: string; name: string; coreNumber: number; degree: number }>;
  // Per-community core distribution: which communities have high-core hubs?
  communityCores: Array<{
    communityId: number;
    nodeCount: number;
    maxCore: number;
    avgCore: number;
    hubCount: number;
  }>;
}

// Compute the degree of each node in the current subgraph.
function computeDegrees(
  adjacency: Map<string, Array<{ dst: string; weight: number }>>,
  activeNodes: Set<string>
): Map<string, number> {
  const degrees = new Map<string, number>();
  for (const nodeId of activeNodes) {
    const neighbors = adjacency.get(nodeId) || [];
    let deg = 0;
    for (const nb of neighbors) {
      if (activeNodes.has(nb.dst)) deg++;
    }
    degrees.set(nodeId, deg);
  }
  return degrees;
}

export function runKCore(
  project: ASTProject,
  asg: ASG,
  leidenCommunities: Map<string, number>
): KCoreResult {
  // Build undirected adjacency from the ASG edges (ignoring direction)
  const adjacency = new Map<string, Set<string>>();
  for (const node of asg.nodes) {
    adjacency.set(node.id, new Set());
  }
  for (const e of asg.edges) {
    if (e.src === e.dst) continue;
    adjacency.get(e.src)?.add(e.dst);
    adjacency.get(e.dst)?.add(e.src);
  }
  // Convert to weighted-adjacency shape for the degree function
  const weightedAdj = new Map<string, Array<{ dst: string; weight: number }>>();
  for (const [src, neighbors] of adjacency) {
    weightedAdj.set(
      src,
      Array.from(neighbors).map((dst) => ({ dst, weight: 1 }))
    );
  }

  // Initialize: all nodes are active
  let activeNodes = new Set<string>(asg.nodes.map((n) => n.id));
  const coreNumbers = new Map<string, number>();
  let k = 0;

  // Iterative peeling
  while (activeNodes.size > 0) {
    let changed = true;
    while (changed) {
      changed = false;
      const degrees = computeDegrees(weightedAdj, activeNodes);
      const toRemove: string[] = [];
      for (const [nodeId, deg] of degrees) {
        if (deg < k) {
          toRemove.push(nodeId);
        }
      }
      if (toRemove.length > 0) {
        for (const nodeId of toRemove) {
          activeNodes.delete(nodeId);
          coreNumbers.set(nodeId, k);
        }
        changed = true;
      }
    }
    k++;
  }

  // Build k-core lookup: k -> list of nodes with core number >= k
  const kCores = new Map<number, string[]>();
  const maxK = Math.max(...Array.from(coreNumbers.values()), 0);
  for (let ki = 0; ki <= maxK; ki++) {
    const nodes = asg.nodes
      .filter((n) => (coreNumbers.get(n.id) ?? 0) >= ki)
      .map((n) => n.id);
    if (nodes.length > 0) kCores.set(ki, nodes);
  }

  // Build stats per k-level
  const stats: KCoreResult["stats"] = [];
  for (let ki = 0; ki <= maxK; ki++) {
    const nodesInCore = kCores.get(ki) || [];
    if (nodesInCore.length === 0) continue;
    const activeSet = new Set(nodesInCore);
    const degrees = computeDegrees(weightedAdj, activeSet);
    const totalDegree = Array.from(degrees.values()).reduce((s, d) => s + d, 0);
    const edgeCount = totalDegree / 2; // undirected
    const avgDegree = nodesInCore.length > 0 ? totalDegree / nodesInCore.length : 0;
    // Top nodes by degree within this core
    const topNodes = Array.from(degrees.entries())
      .map(([nodeId, degree]) => ({
        nodeId,
        name: project.nodesById.get(nodeId)?.name || "?",
        degree,
        coreNumber: coreNumbers.get(nodeId) ?? 0,
      }))
      .sort((a, b) => b.degree - a.degree)
      .slice(0, 8);
    stats.push({
      k: ki,
      nodeCount: nodesInCore.length,
      edgeCount: Math.round(edgeCount),
      avgDegree: Math.round(avgDegree * 100) / 100,
      topNodes,
    });
  }

  // Hubs: nodes with core number >= 3
  const hubs: KCoreResult["hubs"] = asg.nodes
    .map((n) => ({
      nodeId: n.id,
      name: n.name,
      coreNumber: coreNumbers.get(n.id) ?? 0,
      degree: (adjacency.get(n.id)?.size ?? 0),
    }))
    .filter((h) => h.coreNumber >= 3)
    .sort((a, b) => b.coreNumber - a.coreNumber || b.degree - a.degree);

  // Per-community core distribution
  const commMap = new Map<number, number[]>();
  for (const [nodeId, coreNum] of coreNumbers) {
    const commId = leidenCommunities.get(nodeId);
    if (commId === undefined) continue;
    if (!commMap.has(commId)) commMap.set(commId, []);
    commMap.get(commId)!.push(coreNum);
  }
  const communityCores: KCoreResult["communityCores"] = [];
  for (const [commId, cores] of commMap) {
    const maxCore = Math.max(...cores);
    const avgCore = cores.reduce((s, c) => s + c, 0) / cores.length;
    const hubCount = cores.filter((c) => c >= 3).length;
    communityCores.push({
      communityId: commId,
      nodeCount: cores.length,
      maxCore,
      avgCore: Math.round(avgCore * 100) / 100,
      hubCount,
    });
  }
  communityCores.sort((a, b) => b.maxCore - a.maxCore || b.hubCount - a.hubCount);

  return {
    coreNumbers,
    kCores,
    degeneracy: maxK,
    stats,
    hubs,
    communityCores,
  };
}

// Filter the ASG to only nodes in the k-core (degree >= k).
// Returns the subgraph as adjacency + node list, ready to feed into
// RRF or PPR for query-time structural filtering.
export function extractKCoreSubgraph(
  asg: ASG,
  kCoreResult: KCoreResult,
  k: number
): {
  nodes: string[];
  edges: Array<{ src: string; dst: string; weight: number }>;
  adjacency: Map<string, Set<string>>;
} {
  // kCores keys are numbers; fall back to filtering by coreNumbers directly
  let coreNodes: Set<string>;
  const kCoreEntry = kCoreResult.kCores.get(k);
  if (kCoreEntry) {
    coreNodes = new Set(kCoreEntry);
  } else {
    // Fallback: filter all nodes by core number >= k
    coreNodes = new Set();
    for (const [nodeId, coreNum] of kCoreResult.coreNumbers) {
      if (coreNum >= k) coreNodes.add(nodeId);
    }
  }
  const edges: Array<{ src: string; dst: string; weight: number }> = [];
  const adjacency = new Map<string, Set<string>>();
  for (const nodeId of coreNodes) adjacency.set(nodeId, new Set());
  for (const e of asg.edges) {
    if (coreNodes.has(e.src) && coreNodes.has(e.dst)) {
      edges.push({ src: e.src, dst: e.dst, weight: e.weight });
      adjacency.get(e.src)?.add(e.dst);
      adjacency.get(e.dst)?.add(e.src);
    }
  }
  return {
    nodes: Array.from(coreNodes),
    edges,
    adjacency,
  };
}
