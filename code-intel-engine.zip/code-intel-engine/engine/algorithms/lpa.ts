// ============================================================
// Module 5: AST Taint & Scope Propagation (Code-Native LPA)
// ============================================================
// Standard LPA passes labels across unweighted, undirected web links.
// We diffuse labels strictly along ASG data-flow edges:
//   - function call edges (caller -> callee): the caller's label flows
//     downstream to the callee (taint propagation through calls).
//   - variable assignment edges (source -> sink): a label on the source
//     propagates to the sink (taint propagation through assignments).
//
// This acts as a real-time taint tracker: tagging a parameter with
// @UntrustedInput or @Deprecated lets the label diffuse through the
// entire downstream data-flow graph in milliseconds.

import { ASTProject, ASTNode } from "../ast/types";

export type Label = "UntrustedInput" | "Deprecated" | "Sensitive" | "AdminOnly" | "Cached";

export interface LPAState {
  // nodeId -> set of labels
  labels: Map<string, Set<Label>>;
  // nodeId -> label -> iteration number when label was first applied
  labelIteration: Map<string, Map<Label, number>>;
  // History of propagation steps for visualization
  propagationHistory: Array<{
    iteration: number;
    fromNode: string;
    toNode: string;
    label: Label;
    edgeType: "call" | "data" | "parent";
  }>;
  // Initial seed labels (provided by user)
  seeds: Array<{ nodeId: string; label: Label }>;
  // Total iterations run
  iterations: number;
  // Final list of tainted nodes (those that received any label)
  taintedNodes: string[];
}

// Seed labels: scan the AST for decorators. The decorator name (minus @)
// becomes the label name if it matches one of our known labels.
// We also support implicit "UntrustedInput" tagging for parameters
// of methods decorated with @route.
export function findSeedLabels(project: ASTProject): Array<{ nodeId: string; label: Label }> {
  const seeds: Array<{ nodeId: string; label: Label }> = [];

  // Map decorator names to labels
  const decoratorToLabel: Record<string, Label> = {
    "@UntrustedInput": "UntrustedInput",
    "@Deprecated": "Deprecated",
    "@deprecated": "Deprecated",
    "@Sensitive": "Sensitive",
    "@sensitive": "Sensitive",
    "@adminOnly": "AdminOnly",
    "@AdminOnly": "AdminOnly",
    "@Cached": "Cached",
    "@cached": "Cached",
  };

  // Walk all nodes
  for (const node of project.allNodes) {
    for (const dec of node.decorators) {
      const label = decoratorToLabel[dec.name];
      if (label) {
        seeds.push({ nodeId: node.id, label });
      }
    }
  }

  // Implicit taint: any method decorated with @route receives "UntrustedInput"
  // because it directly handles HTTP request data.
  for (const node of project.allNodes) {
    if (
      (node.type === "MethodDeclaration" || node.type === "FunctionDeclaration") &&
      node.decorators.some((d) => d.name === "@route")
    ) {
      if (!seeds.some((s) => s.nodeId === node.id && s.label === "UntrustedInput")) {
        seeds.push({ nodeId: node.id, label: "UntrustedInput" });
      }
    }
  }

  // Implicit adminOnly: any method decorated with @adminOnly
  for (const node of project.allNodes) {
    if (
      (node.type === "MethodDeclaration" || node.type === "FunctionDeclaration") &&
      node.decorators.some((d) => d.name === "@adminOnly")
    ) {
      if (!seeds.some((s) => s.nodeId === node.id && s.label === "AdminOnly")) {
        seeds.push({ nodeId: node.id, label: "AdminOnly" });
      }
    }
  }

  return seeds;
}

export function runLPA(project: ASTProject, maxIterations: number = 20): LPAState {
  const seeds = findSeedLabels(project);

  // Initialize label state
  const labels = new Map<string, Set<Label>>();
  const labelIteration = new Map<string, Map<Label, number>>();
  for (const node of project.allNodes) {
    labels.set(node.id, new Set());
    labelIteration.set(node.id, new Map());
  }

  // Apply seeds at iteration 0
  const propagationHistory: LPAState["propagationHistory"] = [];
  for (const seed of seeds) {
    labels.get(seed.nodeId)!.add(seed.label);
    labelIteration.get(seed.nodeId)!.set(seed.label, 0);
  }

  // Build a unified directed propagation graph:
  //   - call edges: caller -> callee (label flows downstream)
  //   - data-flow edges: source -> sink (label flows downstream)
  //   - parent edges: parent -> child (label flows down the AST)
  //     (e.g. a "Deprecated" label on a class propagates to all its methods)
  const outgoing = new Map<string, Array<{ dst: string; type: "call" | "data" | "parent" }>>();
  for (const node of project.allNodes) {
    outgoing.set(node.id, []);
  }
  for (const [caller, callees] of project.callGraph) {
    for (const callee of callees) {
      outgoing.get(caller)?.push({ dst: callee, type: "call" });
    }
  }
  for (const [src, dsts] of project.dataFlowGraph) {
    for (const dst of dsts) {
      outgoing.get(src)?.push({ dst, type: "data" });
    }
  }
  for (const node of project.allNodes) {
    if (node.parentId) {
      outgoing.get(node.parentId)?.push({ dst: node.id, type: "parent" });
    }
  }

  // Iterative propagation: standard Label Diffusion for Taint Tracking
  // adapted for directed, typed edges.
  let iter = 0;
  let changed = true;
  while (changed && iter < maxIterations) {
    changed = false;
    iter++;

    const updates: Array<{ from: string; to: string; label: Label; type: "call" | "data" | "parent" }> = [];

    for (const node of project.allNodes) {
      const currentLabels = labels.get(node.id)!;
      if (currentLabels.size === 0) continue;

      const outs = outgoing.get(node.id) || [];
      for (const { dst, type } of outs) {
        const dstLabels = labels.get(dst)!;
        for (const label of currentLabels) {
          if (!dstLabels.has(label)) {
            updates.push({ from: node.id, to: dst, label, type });
          }
        }
      }
    }

    // Apply all updates atomically per iteration
    for (const u of updates) {
      const dstLabels = labels.get(u.to)!;
      if (!dstLabels.has(u.label)) {
        dstLabels.add(u.label);
        labelIteration.get(u.to)!.set(u.label, iter);
        propagationHistory.push({
          iteration: iter,
          fromNode: u.from,
          toNode: u.to,
          label: u.label,
          edgeType: u.type,
        });
        changed = true;
      }
    }
  }

  // Compute tainted nodes (those with any label)
  const taintedNodes: string[] = [];
  for (const [nodeId, labelSet] of labels) {
    if (labelSet.size > 0) taintedNodes.push(nodeId);
  }

  return {
    labels,
    labelIteration,
    propagationHistory,
    seeds,
    iterations: iter,
    taintedNodes,
  };
}
