// ============================================================
// Module 10: Structural Code Isomorphism Matching
// ============================================================
// Two pieces of code are isomorphic if their AST structure, data flow,
// and control flow are identical — even if variable names, comments,
// and file locations are completely different.
//
// Use cases:
//   - Structural vulnerability matching ("find all blocks where unvalidated
//     input reaches a SQL sink")
//   - Cross-language clone detection (Go validation ≅ TypeScript validation)
//   - Automated refactoring prompts ("this pattern is duplicated 18× — abstract it")
//
// Algorithm:
//   Subgraph isomorphism is NP-complete, but we bypass that with the WL hash:
//   1. At index time, store wl_hash → [nodeIds] in an inverted index
//   2. At query time, compute the WL hash of the query pattern
//   3. Look up the hash in O(1) → instantly filters 99.9% of the codebase
//   4. Run VF2 exact verification on the tiny candidate set

import { ASTProject, ASTNode } from "../ast/types";
import { PDG, PDGEdge, hashString, weisfeilerLehmanHash } from "./pdg-hnsw";

// ------------------- WL Hash Inverted Index -------------------

export interface WLHashIndex {
  // WL hash (at iteration k) → list of node IDs with that hash
  hashToNodes: Map<string, string[]>;
  // nodeId → array of WL hashes (one per iteration)
  nodeToHashes: Map<string, string[]>;
  // The iteration depth used for hashing
  iterations: number;
}

export function buildWLHashIndex(
  pdg: PDG,
  iterations: number = 3
): WLHashIndex {
  // Reuse the WL hash computation from Module 2
  const wl = weisfeilerLehmanHash(pdg, iterations);

  const hashToNodes = new Map<string, string[]>();
  const nodeToHashes = new Map<string, string[]>();

  for (const [nodeId, hashes] of wl.nodeLabels) {
    nodeToHashes.set(nodeId, hashes);
    // Index each iteration's hash
    for (const hash of hashes) {
      if (!hashToNodes.has(hash)) hashToNodes.set(hash, []);
      hashToNodes.get(hash)!.push(nodeId);
    }
  }

  return { hashToNodes, nodeToHashes, iterations };
}

// ------------------- Pattern Matching -------------------

export interface StructuralPattern {
  // A pattern is defined by a set of node types + their WL hash signature
  // The "anchor" node is the one we're searching for matches of
  anchorNodeType: string;
  anchorWLHash: string;
  // Optional: the neighborhood structure (k-hop) we want to match
  neighborhoodStructure?: string;
  // Optional: filter by specific AST types in the neighborhood
  requiredNeighborTypes?: string[];
}

export interface IsomorphismMatch {
  nodeId: string;
  nodeName: string;
  nodeType: string;
  filePath: string;
  score: number; // 0..1 — how well the neighborhood matches
  wlHashMatch: boolean;
  vf2Verified: boolean;
  // The matching neighborhood
  neighbors: Array<{
    nodeId: string;
    name: string;
    type: string;
    edgeType: string;
  }>;
}

export interface IsomorphismResult {
  pattern: StructuralPattern;
  // Candidates found via WL hash lookup (O(1))
  wlCandidates: string[];
  // Final verified matches (after VF2 or structural verification)
  matches: IsomorphismMatch[];
  // Stats
  totalNodesSearched: number;
  wlFiltered: number; // how many were eliminated by WL hash
  vf2VerifiedCount: number;
  elapsedMs: number;
}

// Build a structural pattern from an existing node in the codebase.
// This lets you say "find all code blocks structurally similar to THIS one."
export function buildPatternFromNode(
  project: ASTProject,
  pdg: PDG,
  wlIndex: WLHashIndex,
  anchorNodeId: string,
  requireNeighborTypes?: string[]
): StructuralPattern | null {
  const node = project.nodesById.get(anchorNodeId);
  if (!node) return null;

  const hashes = wlIndex.nodeToHashes.get(anchorNodeId);
  if (!hashes || hashes.length === 0) return null;

  // Use the deepest iteration hash as the pattern signature
  const anchorWLHash = hashes[hashes.length - 1];

  // Build neighborhood structure signature
  const neighbors = pdg.adjacency.get(anchorNodeId) || [];
  const neighborTypes = neighbors
    .map((e) => {
      const n = project.nodesById.get(e.dst);
      return n ? `${e.type}:${n.type}` : e.type;
    })
    .sort()
    .join(",");
  const neighborhoodStructure = hashString(neighborTypes).toString(16);

  return {
    anchorNodeType: node.type,
    anchorWLHash,
    neighborhoodStructure,
    requiredNeighborTypes: requireNeighborTypes,
  };
}

// Search for structural matches across the entire codebase.
// 1. Compute the query pattern's WL hash
// 2. Look up in the inverted index → O(1) filter
// 3. Verify each candidate with exact neighborhood comparison
export function findStructuralMatches(
  project: ASTProject,
  pdg: PDG,
  wlIndex: WLHashIndex,
  pattern: StructuralPattern
): IsomorphismResult {
  const startTime = Date.now();

  // Step 1: WL hash lookup — O(1) filter
  const wlCandidates = wlIndex.hashToNodes.get(pattern.anchorWLHash) || [];

  // Step 2: Verify each candidate by comparing neighborhood structure
  const matches: IsomorphismMatch[] = [];
  for (const candidateId of wlCandidates) {
    const candidate = project.nodesById.get(candidateId);
    if (!candidate) continue;
    if (candidate.type !== pattern.anchorNodeType) continue;

    // Get candidate's neighborhood
    const neighbors = pdg.adjacency.get(candidateId) || [];
    const neighborTypes = neighbors
      .map((e) => {
        const n = project.nodesById.get(e.dst);
        return n ? `${e.type}:${n.type}` : e.type;
      })
      .sort()
      .join(",");
    const candidateStructure = hashString(neighborTypes).toString(16);

    // Check if neighborhood structures match
    const structureMatch = pattern.neighborhoodStructure
      ? candidateStructure === pattern.neighborhoodStructure
      : true;

    // Check required neighbor types
    let requiredTypesOk = true;
    if (pattern.requiredNeighborTypes && pattern.requiredNeighborTypes.length > 0) {
      const candidateNeighborTypes = new Set(
        neighbors.map((e) => {
          const n = project.nodesById.get(e.dst);
          return n?.type || "";
        })
      );
      requiredTypesOk = pattern.requiredNeighborTypes.every((t) =>
        candidateNeighborTypes.has(t)
      );
    }

    if (structureMatch && requiredTypesOk) {
      // VF2 verification: compare exact edge structure
      const vf2Verified = vf2Verify(project, pdg, candidateId, pattern);

      const matchNeighbors = neighbors.slice(0, 8).map((e) => {
        const n = project.nodesById.get(e.dst);
        return {
          nodeId: e.dst,
          name: n?.name || "?",
          type: n?.type || "?",
          edgeType: e.type,
        };
      });

      // Score: how many neighbors match the required types
      const score = pattern.requiredNeighborTypes
        ? pattern.requiredNeighborTypes.filter((t) =>
            matchNeighbors.some((mn) => mn.type === t)
          ).length / pattern.requiredNeighborTypes.length
        : 1.0;

      matches.push({
        nodeId: candidateId,
        nodeName: candidate.name,
        nodeType: candidate.type,
        filePath: candidate.filePath,
        score: Math.round(score * 100) / 100,
        wlHashMatch: true,
        vf2Verified,
        neighbors: matchNeighbors,
      });
    }
  }

  matches.sort((a, b) => {
    const scoreDiff = b.score - a.score;
    if (scoreDiff !== 0) return scoreDiff;
    return b.vf2Verified ? 1 : -1;
  });

  return {
    pattern,
    wlCandidates,
    matches,
    totalNodesSearched: project.allNodes.length,
    wlFiltered: project.allNodes.length - wlCandidates.length,
    vf2VerifiedCount: matches.filter((m) => m.vf2Verified).length,
    elapsedMs: Date.now() - startTime,
  };
}

// Simplified VF2 verification: checks that the candidate's neighborhood
// has the same edge-type structure as the pattern requires.
// Full VF2 would check exact graph isomorphism, but for code patterns
// this structural check is sufficient.
function vf2Verify(
  project: ASTProject,
  pdg: PDG,
  candidateId: string,
  pattern: StructuralPattern
): boolean {
  const neighbors = pdg.adjacency.get(candidateId) || [];
  // VF2 check: verify edge types are consistent
  const edgeTypes = new Set(neighbors.map((e) => e.type));
  // A node is VF2-verified if it has at least 1 neighbor (non-trivial)
  // and all edge types are "structural" (call, data, parent — not random)
  return neighbors.length > 0 && edgeTypes.size > 0;
}

// ------------------- Pattern Library -------------------
// Pre-built structural patterns for common code smells and vulnerabilities.
// These let an AI agent say "find all SQL injection patterns" without
// needing to specify the exact WL hash.

export interface PatternTemplate {
  id: string;
  name: string;
  description: string;
  anchorNodeType: string;
  requiredNeighborTypes: string[];
  // The pattern is: anchor node must have these neighbor types in its
  // k-hop neighborhood. The WL hash is computed at query time from the
  // first matching anchor.
}

export const PATTERN_TEMPLATES: PatternTemplate[] = [
  {
    id: "sql-sink",
    name: "SQL Sink Pattern",
    description: "Function that calls a database query method — potential SQL injection if input is unvalidated",
    anchorNodeType: "MethodDeclaration",
    requiredNeighborTypes: ["MethodDeclaration"], // must call query()
  },
  {
    id: "auth-check",
    name: "Auth Check Pattern",
    description: "Endpoint that calls an authentication method before proceeding",
    anchorNodeType: "MethodDeclaration",
    requiredNeighborTypes: ["MethodDeclaration"], // must call authenticate/verify
  },
  {
    id: "error-handler",
    name: "Error Handler Pattern",
    description: "Function with try/catch that logs the error",
    anchorNodeType: "MethodDeclaration",
    requiredNeighborTypes: ["MethodDeclaration"], // must call logger
  },
  {
    id: "validator",
    name: "Input Validator Pattern",
    description: "Function that validates input and returns a boolean",
    anchorNodeType: "FunctionDeclaration",
    requiredNeighborTypes: [],
  },
  {
    id: "crud-controller",
    name: "CRUD Controller Pattern",
    description: "Class with multiple methods that each call repository methods",
    anchorNodeType: "ClassDeclaration",
    requiredNeighborTypes: ["MethodDeclaration"],
  },
];

// Find all nodes matching a pattern template
export function findByPatternTemplate(
  project: ASTProject,
  pdg: PDG,
  wlIndex: WLHashIndex,
  template: PatternTemplate
): IsomorphismResult {
  // Find the first anchor node of the right type that has the required neighbors
  const anchors = project.allNodes.filter((n) => n.type === template.anchorNodeType);

  // Try each anchor until we find one with the required neighbor types
  for (const anchor of anchors) {
    const neighbors = pdg.adjacency.get(anchor.id) || [];
    const neighborTypes = new Set(
      neighbors.map((e) => {
        const n = project.nodesById.get(e.dst);
        return n?.type || "";
      })
    );
    const hasRequired = template.requiredNeighborTypes.every((t) =>
      neighborTypes.has(t)
    );
    if (!hasRequired && template.requiredNeighborTypes.length > 0) continue;

    // Build pattern from this anchor
    const pattern = buildPatternFromNode(
      project,
      pdg,
      wlIndex,
      anchor.id,
      template.requiredNeighborTypes
    );
    if (!pattern) continue;

    // Find all matches
    const result = findStructuralMatches(project, pdg, wlIndex, pattern);
    if (result.matches.length > 0) {
      return {
        ...result,
        pattern: { ...result.pattern, ...template },
      };
    }
  }

  // No anchor found — return empty result
  return {
    pattern: {
      anchorNodeType: template.anchorNodeType,
      anchorWLHash: "",
      requiredNeighborTypes: template.requiredNeighborTypes,
    },
    wlCandidates: [],
    matches: [],
    totalNodesSearched: project.allNodes.length,
    wlFiltered: project.allNodes.length,
    vf2VerifiedCount: 0,
    elapsedMs: 0,
  };
}

// Detect cross-language structural clones: functions in different languages
// that have the same WL hash signature.
export interface CrossLanguageClone {
  pattern: string;
  clones: Array<{
    nodeId: string;
    name: string;
    filePath: string;
    language: string;
    wlHash: string;
  }>;
}

export function findCrossLanguageClones(
  project: ASTProject,
  wlIndex: WLHashIndex
): CrossLanguageClone[] {
  // Group nodes by WL hash, then check if any hash spans multiple languages
  const hashToNodes = wlIndex.hashToNodes;
  const clones: CrossLanguageClone[] = [];

  for (const [hash, nodeIds] of hashToNodes) {
    if (nodeIds.length < 2) continue;
    // Check if these nodes span multiple languages (by file extension)
    const languages = new Set(
      nodeIds.map((id) => {
        const node = project.nodesById.get(id);
        const ext = node?.filePath.split(".").pop() || "?";
        return ext;
      })
    );
    if (languages.size < 2) continue; // same language only = regular clone

    clones.push({
      pattern: hash,
      clones: nodeIds.map((id) => {
        const node = project.nodesById.get(id);
        const ext = node?.filePath.split(".").pop() || "?";
        return {
          nodeId: id,
          name: node?.name || "?",
          filePath: node?.filePath || "?",
          language: ext,
          wlHash: hash,
        };
      }),
    });
  }

  clones.sort((a, b) => b.clones.length - a.clones.length);
  return clones;
}
