// ============================================================
// Module 3: AST-Scoped Rank Fusion (Code-Native RRF)
// ============================================================
// Standard RRF merges flat result lists blindly. We extend it to:
// 1. Merge AST-BM25 hits with PDG-HNSW hits
// 2. Apply scope-filtering rules (only nodes within the same AST
//    parent-child subtree as the top-ranked hit are kept)
// 3. Validate that every returned seed node is a structurally
//    valid entry point (function/method/class — not a statement)

import { ASTNode, ASTProject, SearchResult } from "../ast/types";
import { InvertedIndex, search as bm25Search } from "./bm25";
import { HNSWIndex, hnswSearch } from "./pdg-hnsw";
import { SearchQuery } from "../ast/types";

export interface RRFResult {
  node: ASTNode;
  // Original scores from each retriever
  bm25Score: number;
  hnswScore: number;
  // Final fused score
  fusedScore: number;
  // Rank in the BM25 list (0-indexed, -1 if not present)
  bm25Rank: number;
  // Rank in the HNSW list
  hnswRank: number;
  // Whether this node survived scope filtering
  scopeValid: boolean;
  // Validation status: is this a valid entry-point node?
  isValidEntryPoint: boolean;
}

const RRF_K = 60; // standard RRF constant

// Scope validation rule: a candidate node is "scope valid" if it shares
// at least one scope ancestor with the top-ranked BM25 hit OR if it has
// no scope (top-level) AND the top hit is also top-level.
function isScopeValid(node: ASTNode, anchorNode: ASTNode): boolean {
  if (node.id === anchorNode.id) return true;
  // If the anchor has no scope (e.g. a class declaration at file scope),
  // accept any other node that has the anchor in its scope chain.
  if (anchorNode.scope.length === 0) {
    return node.scope.includes(anchorNode.name);
  }
  // Otherwise, require at least one shared scope name.
  const anchorScopeSet = new Set(anchorNode.scope);
  return node.scope.some((s) => anchorScopeSet.has(s));
}

// Entry-point validation: a seed node must be a function-like or class
// declaration. Statements like IfStatement, ReturnStatement are filtered out.
function isValidEntryPoint(node: ASTNode): boolean {
  const validTypes = new Set([
    "ClassDeclaration",
    "FunctionDeclaration",
    "MethodDeclaration",
    "ConstructorDeclaration",
    "VariableDeclaration",
  ]);
  return validTypes.has(node.type);
}

export function astScopedRRF(
  project: ASTProject,
  index: InvertedIndex,
  hnsw: HNSWIndex,
  features: Map<string, number[]>,
  query: SearchQuery,
  topK: number = 10
): RRFResult[] {
  // 1. Run BM25 retrieval
  const bm25Results = bm25Search(project, index, query).slice(0, 50);

  // 2. Build a synthetic query vector for HNSW:
  //    Use the centroid of the top BM25 hits' feature vectors.
  let queryVec: number[] = [];
  if (bm25Results.length > 0) {
    const dim = features.get(bm25Results[0].node.id)?.length || 0;
    queryVec = new Array(dim).fill(0);
    for (const r of bm25Results.slice(0, 5)) {
      const v = features.get(r.node.id);
      if (v) {
        for (let i = 0; i < dim; i++) queryVec[i] += v[i];
      }
    }
    for (let i = 0; i < dim; i++) queryVec[i] /= Math.min(5, bm25Results.length);
  }

  const hnswResults = queryVec.length > 0 ? hnswSearch(hnsw, queryVec, 50, 100) : [];

  // 3. Build maps of nodeId -> rank for each retriever
  const bm25RankMap = new Map<string, number>();
  bm25Results.forEach((r, i) => bm25RankMap.set(r.node.id, i));

  const hnswRankMap = new Map<string, number>();
  hnswResults.forEach((r, i) => hnswRankMap.set(r.id, i));

  // 4. Union of all candidate node IDs
  const allNodeIds = new Set<string>([
    ...bm25Results.map((r) => r.node.id),
    ...hnswResults.map((r) => r.id),
  ]);

  // 5. Compute fused RRF score for each candidate
  const fused: RRFResult[] = [];
  for (const nodeId of allNodeIds) {
    const node = project.nodesById.get(nodeId);
    if (!node) continue;

    const bm25Rank = bm25RankMap.has(nodeId) ? bm25RankMap.get(nodeId)! : -1;
    const hnswRank = hnswRankMap.has(nodeId) ? hnswRankMap.get(nodeId)! : -1;

    let rrfScore = 0;
    if (bm25Rank >= 0) rrfScore += 1 / (RRF_K + bm25Rank + 1);
    if (hnswRank >= 0) rrfScore += 1 / (RRF_K + hnswRank + 1);

    const bm25Score =
      bm25Results.find((r) => r.node.id === nodeId)?.score || 0;
    const hnswScore =
      hnswResults.find((r) => r.id === nodeId)?.score || 0;

    fused.push({
      node,
      bm25Score,
      hnswScore,
      fusedScore: rrfScore,
      bm25Rank,
      hnswRank,
      scopeValid: true, // will be set below
      isValidEntryPoint: isValidEntryPoint(node),
    });
  }

  // 6. Sort by fused score descending
  fused.sort((a, b) => b.fusedScore - a.fusedScore);

  // 7. Apply scope filtering: anchor on the top BM25 hit.
  if (bm25Results.length > 0) {
    const anchorNode = bm25Results[0].node;
    for (const r of fused) {
      r.scopeValid = isScopeValid(r.node, anchorNode);
    }
  }

  // 8. Return top K — but only seed nodes that are scope-valid AND valid entry points.
  // For visualization, we also include the rejected nodes (dimmed in UI).
  return fused.slice(0, topK);
}

// Get the AST parent-child subtree for a given node (for visualization).
export function getSubtree(project: ASTProject, nodeId: string, maxDepth: number = 2): ASTNode[] {
  const result: ASTNode[] = [];
  const queue: Array<{ id: string; depth: number }> = [{ id: nodeId, depth: 0 }];
  const visited = new Set<string>();
  while (queue.length > 0) {
    const { id, depth } = queue.shift()!;
    if (visited.has(id) || depth > maxDepth) continue;
    visited.add(id);
    const node = project.nodesById.get(id);
    if (!node) continue;
    result.push(node);
    for (const childId of node.childIds) {
      queue.push({ id: childId, depth: depth + 1 });
    }
  }
  return result;
}
