// ============================================================
// Module 4: Call-Graph Bounded Community Detection (Leiden)
// ============================================================
// Build an Abstract Semantic Graph (ASG) with edge weights reflecting:
//   - static call frequencies
//   - type dependencies
//   - module imports
// Then run the Leiden algorithm to partition the codebase into
// architectural subsystems / bounded contexts.

import { ASTProject, ASTNode } from "../ast/types";

// ------------------- ASG Construction -------------------

export interface ASGNode {
  id: string;
  label: string;
  nodeType: string;
  filePath: string;
  // Pre-computed metadata for weighting
  callCount: number;
  typeDeps: number;
  importCount: number;
}

export interface ASGEdge {
  src: string;
  dst: string;
  weight: number;
  // Composition of the weight
  callWeight: number;
  typeWeight: number;
  importWeight: number;
}

export interface ASG {
  nodes: ASGNode[];
  edges: ASGEdge[];
  nodeIndex: Map<string, number>;
  neighbors: Map<string, Array<{ dst: string; weight: number }>>;
}

export function buildASG(project: ASTProject): ASG {
  const nodes: ASGNode[] = [];
  const edges: ASGEdge[] = [];
  const nodeIndex = new Map<string, number>();
  const neighbors = new Map<string, Array<{ dst: string; weight: number }>>();

  // Only class/function/method/variable/property declarations are nodes
  const asgNodeTypes = new Set([
    "ClassDeclaration",
    "FunctionDeclaration",
    "MethodDeclaration",
    "ConstructorDeclaration",
    "VariableDeclaration",
    "PropertyDeclaration",
  ]);

  for (const node of project.allNodes) {
    if (!asgNodeTypes.has(node.type)) continue;
    // Count type deps = number of unique parameter/return types
    const typeDeps = new Set<string>([
      ...node.parameterTypes,
      ...(node.returnType ? [node.returnType] : []),
    ]).size;
    nodes.push({
      id: node.id,
      label: `${node.type}:${node.name}`,
      nodeType: node.type,
      filePath: node.filePath,
      callCount: project.callGraph.get(node.id)?.length || 0,
      typeDeps,
      importCount: node.type === "ImportDeclaration" ? 1 : 0,
    });
    nodeIndex.set(node.id, nodes.length - 1);
    neighbors.set(node.id, []);
  }

  // Build edges by merging call, type, and import relationships
  const edgeMap = new Map<string, ASGEdge>();

  const getEdgeKey = (a: string, b: string) => (a < b ? `${a}|${b}` : `${b}|${a}`);

  const addEdge = (
    a: string,
    b: string,
    callWeight: number,
    typeWeight: number,
    importWeight: number
  ) => {
    if (a === b) return;
    const key = getEdgeKey(a, b);
    if (!edgeMap.has(key)) {
      const edge: ASGEdge = {
        src: a,
        dst: b,
        weight: 0,
        callWeight: 0,
        typeWeight: 0,
        importWeight: 0,
      };
      edgeMap.set(key, edge);
    }
    const e = edgeMap.get(key)!;
    e.callWeight += callWeight;
    e.typeWeight += typeWeight;
    e.importWeight += importWeight;
    e.weight = e.callWeight * 2 + e.typeWeight * 1.5 + e.importWeight * 1.0;
  };

  // Call graph edges
  for (const [callerId, calleeIds] of project.callGraph) {
    for (const calleeId of calleeIds) {
      if (nodeIndex.has(callerId) && nodeIndex.has(calleeId)) {
        addEdge(callerId, calleeId, 1, 0, 0);
      }
    }
  }

  // Type dependency edges: connect functions that share parameter/return types
  const asgNodes = nodes;
  const typeMap = new Map<string, string[]>();
  for (const node of asgNodes) {
    const astNode = project.nodesById.get(node.id);
    if (!astNode) continue;
    const types = [
      ...astNode.parameterTypes.map((p) => p.split(":")[1] || ""),
      astNode.returnType || "",
    ].filter((t) => t.length > 0 && t !== "void" && t !== "any");
    for (const t of types) {
      if (!typeMap.has(t)) typeMap.set(t, []);
      typeMap.get(t)!.push(node.id);
    }
  }
  for (const [, nodeIds] of typeMap) {
    for (let i = 0; i < nodeIds.length; i++) {
      for (let j = i + 1; j < nodeIds.length; j++) {
        addEdge(nodeIds[i], nodeIds[j], 0, 0.5, 0);
      }
    }
  }

  // Import edges: connect nodes that import the same module
  const importMap = new Map<string, string[]>();
  for (const node of asgNodes) {
    const astNode = project.nodesById.get(node.id);
    if (!astNode || astNode.type !== "ImportDeclaration") continue;
    const imports = astNode.references;
    for (const imp of imports) {
      if (!importMap.has(imp)) importMap.set(imp, []);
      importMap.get(imp)!.push(node.id);
    }
  }
  for (const [, nodeIds] of importMap) {
    for (let i = 0; i < nodeIds.length; i++) {
      for (let j = i + 1; j < nodeIds.length; j++) {
        addEdge(nodeIds[i], nodeIds[j], 0, 0, 1);
      }
    }
  }

  for (const e of edgeMap.values()) {
    edges.push(e);
    if (!neighbors.has(e.src)) neighbors.set(e.src, []);
    if (!neighbors.has(e.dst)) neighbors.set(e.dst, []);
    neighbors.get(e.src)!.push({ dst: e.dst, weight: e.weight });
    neighbors.get(e.dst)!.push({ dst: e.src, weight: e.weight });
  }

  return { nodes, edges, nodeIndex, neighbors };
}

// ------------------- Leiden Algorithm -------------------
// Simplified Leiden implementation:
// Phase 1: local moving — each node moves to the community that maximizes
//          the modularity gain (with the CPM quality function).
// Phase 2: refinement — refine communities into potentially overlapping
//          sub-communities to guarantee connectedness.
// Phase 3: aggregation — merge nodes in the same community into a single node.
// Repeat until no further improvement.

export interface LeidenResult {
  // nodeId -> community id (integer label)
  communities: Map<string, number>;
  // Per-community stats for visualization
  communityStats: Array<{
    id: number;
    size: number;
    nodes: string[];
    totalWeight: number;
    modularity: number;
  }>;
  modularity: number;
  iterations: number;
}

function computeModularity(
  asg: ASG,
  communities: Map<string, number>
): number {
  // Standard modularity: Q = (1/2m) * sum [ (A_ij - k_i*k_j / 2m) * delta(c_i, c_j) ]
  const m = asg.edges.reduce((sum, e) => sum + e.weight, 0) / 2;
  if (m === 0) return 0;

  const degree = new Map<string, number>();
  for (const node of asg.nodes) degree.set(node.id, 0);
  for (const e of asg.edges) {
    degree.set(e.src, (degree.get(e.src) || 0) + e.weight);
    degree.set(e.dst, (degree.get(e.dst) || 0) + e.weight);
  }

  let q = 0;
  for (const e of asg.edges) {
    const ci = communities.get(e.src);
    const cj = communities.get(e.dst);
    if (ci === cj) {
      const ki = degree.get(e.src) || 0;
      const kj = degree.get(e.dst) || 0;
      q += e.weight - (ki * kj) / (2 * m);
    }
  }
  q /= 2 * m;
  return q;
}

function localMovingPhase(
  asg: ASG,
  initialCommunities: Map<string, number>
): Map<string, number> {
  const communities = new Map(initialCommunities);
  const m = asg.edges.reduce((sum, e) => sum + e.weight, 0) / 2;
  if (m === 0) return communities;

  const degree = new Map<string, number>();
  for (const node of asg.nodes) degree.set(node.id, 0);
  for (const e of asg.edges) {
    degree.set(e.src, (degree.get(e.src) || 0) + e.weight);
    degree.set(e.dst, (degree.get(e.dst) || 0) + e.weight);
  }

  // sum of weights from community to node, sum of degrees in community
  const communityDegree = new Map<number, number>();
  for (const node of asg.nodes) {
    const c = communities.get(node.id)!;
    communityDegree.set(c, (communityDegree.get(c) || 0) + (degree.get(node.id) || 0));
  }

  // Sum of weights from each community to a specific node
  const communityNodeWeight = new Map<string, number>();

  let changed = true;
  let iterations = 0;
  while (changed && iterations < 20) {
    changed = false;
    iterations++;

    for (const node of asg.nodes) {
      const neighbors = asg.neighbors.get(node.id) || [];
      if (neighbors.length === 0) continue;

      // Compute weight to each community
      const commWeights = new Map<number, number>();
      for (const nb of neighbors) {
        const c = communities.get(nb.dst);
        if (c === undefined) continue;
        commWeights.set(c, (commWeights.get(c) || 0) + nb.weight);
      }

      const currentComm = communities.get(node.id)!;
      const ki = degree.get(node.id) || 0;
      const kC = communityDegree.get(currentComm) || 0;
      // Modularity gain for moving node to community c:
      // delta = (commWeights[c] - commWeights[currentComm]) + (ki * (kC - ki)) / (2m)
      // We compute delta for each candidate community and pick the best.

      let bestComm = currentComm;
      let bestGain = 0;
      for (const [c, w] of commWeights) {
        const kC2 = communityDegree.get(c) || 0;
        const gain = (w - (commWeights.get(currentComm) || 0)) + (ki * (kC - kC2)) / (2 * m);
        if (gain > bestGain) {
          bestGain = gain;
          bestComm = c;
        }
      }

      if (bestComm !== currentComm) {
        communityDegree.set(currentComm, (communityDegree.get(currentComm) || 0) - ki);
        communityDegree.set(bestComm, (communityDegree.get(bestComm) || 0) + ki);
        communities.set(node.id, bestComm);
        changed = true;
      }
    }
  }

  return communities;
}

function refinementPhase(
  asg: ASG,
  communities: Map<string, number>
): Map<string, number> {
  // Simplified refinement: for each community, split into connected components
  // (using subgraph). This guarantees the connectedness requirement of Leiden.
  const refined = new Map<string, number>();
  // Map community -> set of nodes
  const commNodes = new Map<number, Set<string>>();
  for (const [nodeId, c] of communities) {
    if (!commNodes.has(c)) commNodes.set(c, new Set());
    commNodes.get(c)!.add(nodeId);
  }

  let nextCommId = 0;
  for (const [originalComm, nodeSet] of commNodes) {
    // Build subgraph
    const subNeighbors = new Map<string, Set<string>>();
    for (const nodeId of nodeSet) {
      subNeighbors.set(nodeId, new Set());
      const neighbors = asg.neighbors.get(nodeId) || [];
      for (const nb of neighbors) {
        if (nodeSet.has(nb.dst)) {
          subNeighbors.get(nodeId)!.add(nb.dst);
        }
      }
    }
    // Find connected components via BFS
    const visited = new Set<string>();
    for (const nodeId of nodeSet) {
      if (visited.has(nodeId)) continue;
      const component: string[] = [nodeId];
      visited.add(nodeId);
      const queue = [nodeId];
      while (queue.length > 0) {
        const cur = queue.shift()!;
        for (const nb of subNeighbors.get(cur) || []) {
          if (!visited.has(nb)) {
            visited.add(nb);
            component.push(nb);
            queue.push(nb);
          }
        }
      }
      for (const id of component) {
        refined.set(id, nextCommId);
      }
      nextCommId++;
    }
  }
  return refined;
}

function aggregationPhase(
  asg: ASG,
  communities: Map<string, number>
): ASG {
  // Aggregate: merge nodes in the same community into a single node.
  const commToNodes = new Map<number, string[]>();
  for (const [nodeId, c] of communities) {
    if (!commToNodes.has(c)) commToNodes.set(c, []);
    commToNodes.get(c)!.push(nodeId);
  }

  const newNodes: ASGNode[] = [];
  const newNodeIndex = new Map<string, number>();
  const commToNewId = new Map<number, string>();

  for (const [c, nodeIds] of commToNodes) {
    const newId = `C${c}`;
    newNodes.push({
      id: newId,
      label: `Community${c} (${nodeIds.length})`,
      nodeType: "Community",
      filePath: "",
      callCount: 0,
      typeDeps: 0,
      importCount: 0,
    });
    newNodeIndex.set(newId, newNodes.length - 1);
    commToNewId.set(c, newId);
  }

  const newNeighbors = new Map<string, Array<{ dst: string; weight: number }>>();
  for (const node of newNodes) newNeighbors.set(node.id, []);

  const edgeMap = new Map<string, ASGEdge>();
  for (const e of asg.edges) {
    const c1 = communities.get(e.src);
    const c2 = communities.get(e.dst);
    if (c1 === undefined || c2 === undefined || c1 === c2) continue;
    const id1 = commToNewId.get(c1)!;
    const id2 = commToNewId.get(c2)!;
    const key = id1 < id2 ? `${id1}|${id2}` : `${id2}|${id1}`;
    if (!edgeMap.has(key)) {
      edgeMap.set(key, {
        src: id1,
        dst: id2,
        weight: 0,
        callWeight: 0,
        typeWeight: 0,
        importWeight: 0,
      });
    }
    const ne = edgeMap.get(key)!;
    ne.weight += e.weight;
    ne.callWeight += e.callWeight;
    ne.typeWeight += e.typeWeight;
    ne.importWeight += e.importWeight;
  }

  const newEdges: ASGEdge[] = [];
  for (const e of edgeMap.values()) {
    newEdges.push(e);
    newNeighbors.get(e.src)!.push({ dst: e.dst, weight: e.weight });
    newNeighbors.get(e.dst)!.push({ dst: e.src, weight: e.weight });
  }

  return {
    nodes: newNodes,
    edges: newEdges,
    nodeIndex: newNodeIndex,
    neighbors: newNeighbors,
  };
}

export function runLeiden(asg: ASG, maxIterations: number = 5): LeidenResult {
  // Initialize each node to its own community
  let communities = new Map<string, number>();
  for (let i = 0; i < asg.nodes.length; i++) {
    communities.set(asg.nodes[i].id, i);
  }
  let currentASG = asg;
  let mapping = new Map<string, string>(); // original node id -> current aggregated node id
  for (const node of asg.nodes) mapping.set(node.id, node.id);

  let lastModularity = -1;
  let iter = 0;

  while (iter < maxIterations) {
    iter++;
    // Phase 1: local moving
    communities = localMovingPhase(currentASG, communities);

    // Phase 2: refinement
    communities = refinementPhase(currentASG, communities);

    // Phase 3: compute modularity
    const q = computeModularity(currentASG, communities);
    if (q <= lastModularity + 1e-6) break;
    lastModularity = q;

    // Phase 4: aggregate
    const newASG = aggregationPhase(currentASG, communities);
    // Update mapping: original node -> aggregated node
    const newMapping = new Map<string, string>();
    for (const [origId, currentId] of mapping) {
      const newId = communities.get(currentId);
      if (newId !== undefined) {
        newMapping.set(origId, newASG.nodes[newId]?.id || currentId);
      } else {
        newMapping.set(origId, currentId);
      }
    }
    mapping = newMapping;
    communities = new Map<string, number>();
    for (let i = 0; i < newASG.nodes.length; i++) {
      communities.set(newASG.nodes[i].id, i);
    }
    currentASG = newASG;
    if (currentASG.nodes.length === 1) break;
  }

  // Translate aggregated communities back to original node ids
  const finalCommunities = new Map<string, number>();
  const commSet = new Set<number>();
  for (const [origId, currentId] of mapping) {
    const c = currentASG.nodes.findIndex((n) => n.id === currentId);
    if (c >= 0) {
      finalCommunities.set(origId, c);
      commSet.add(c);
    }
  }

  // Renumber communities to be 0..N-1
  const commRenumber = new Map<number, number>();
  let nextId = 0;
  for (const c of commSet) commRenumber.set(c, nextId++);
  for (const [id, c] of finalCommunities) {
    finalCommunities.set(id, commRenumber.get(c)!);
  }

  // Compute community stats
  const commToNodes = new Map<number, string[]>();
  for (const [nodeId, c] of finalCommunities) {
    if (!commToNodes.has(c)) commToNodes.set(c, []);
    commToNodes.get(c)!.push(nodeId);
  }

  const communityStats: LeidenResult["communityStats"] = [];
  for (const [c, nodeIds] of commToNodes) {
    let totalWeight = 0;
    for (const id of nodeIds) {
      const nbs = asg.neighbors.get(id) || [];
      for (const nb of nbs) {
        if (finalCommunities.get(nb.dst) === c) {
          totalWeight += nb.weight;
        }
      }
    }
    communityStats.push({
      id: c,
      size: nodeIds.length,
      nodes: nodeIds,
      totalWeight,
      modularity: 0,
    });
  }
  communityStats.sort((a, b) => b.size - a.size);

  const finalQ = computeModularity(asg, finalCommunities);

  return {
    communities: finalCommunities,
    communityStats,
    modularity: finalQ,
    iterations: iter,
  };
}
