// ============================================================
// Tier 2 & 3 Features: Advanced Code Intelligence
// ============================================================
// Tier 2 (one new primitive each):
//   1. Risk scoring — combine all signals into a single "danger" score
//   2. Onboarding paths — PPR from entry points → top files to read first
//   3. Semantic diffing — graph diff (WL hash changes, community shifts)
//
// Tier 3 (novel contribution):
//   4. Agent memory — multi-turn PPR state for LLM coding assistants
//   5. Cross-language clone → shared library interface suggestion

import { ASTProject, ASTNode } from "../ast/types";
import { Engine } from "../engine";
import { runPPR } from "./ppr";
import { search as bm25Search } from "./bm25";

// ==================== Tier 2.1: Risk Scoring ====================
// Combine every signal into a single 0-100 "how dangerous is it to touch this?" score.
// Signals: blast radius (PPR), community leakage, taint labels, k-core, co-change.
// This becomes the headline feature for engineering managers.

export interface RiskScore {
  nodeId: string;
  name: string;
  type: string;
  filePath: string;
  scope: string[];
  overallRisk: number; // 0-100
  riskFactors: {
    blastRadius: number;      // PPR score (0-30 points)
    communityLeakage: number; // cross-community edges (0-20 points)
    taintExposure: number;    // security labels present (0-20 points)
    structuralCentrality: number; // k-core number (0-15 points)
    changeFrequency: number;  // co-change density (0-15 points)
  };
  riskLevel: "Low" | "Medium" | "High" | "Critical";
  recommendation: string;
}

export interface RiskScoringResult {
  nodes: RiskScore[];
  distribution: { Low: number; Medium: number; High: number; Critical: number };
  topRisks: RiskScore[];
}

export function computeRiskScores(
  project: ASTProject,
  engine: Engine
): RiskScoringResult {
  const scores: RiskScore[] = [];

  for (const node of project.allNodes) {
    if (
      node.type !== "FunctionDeclaration" &&
      node.type !== "MethodDeclaration" &&
      node.type !== "ClassDeclaration" &&
      node.type !== "ConstructorDeclaration"
    ) continue;

    // 1. Blast radius (0-30): PPR score × 1000, capped at 30
    const blastScore = engine.blastRadiusScores.get(node.id) || 0;
    const blastRadius = Math.min(30, Math.round(blastScore * 1000));

    // 2. Community leakage (0-20): count edges crossing community boundaries
    const nodeCommunity = engine.leiden.communities.get(node.id);
    let crossCommEdges = 0;
    const pprEdges = engine.pprGraph.edges.filter(e => e.src === node.id || e.dst === node.id);
    for (const edge of pprEdges) {
      const otherId = edge.src === node.id ? edge.dst : edge.src;
      const otherComm = engine.leiden.communities.get(otherId);
      if (otherComm !== undefined && otherComm !== nodeCommunity) {
        crossCommEdges++;
      }
    }
    const communityLeakage = Math.min(20, crossCommEdges * 4);

    // 3. Taint exposure (0-20): security labels present on this node
    const labels = engine.lpa.labels.get(node.id);
    const taintCount = labels ? labels.size : 0;
    const taintExposure = Math.min(20, taintCount * 7);

    // 4. Structural centrality (0-15): k-core number
    const coreNum = engine.kcore.coreNumbers.get(node.id) || 0;
    const structuralCentrality = Math.min(15, Math.round(coreNum * 0.3));

    // 5. Change frequency (0-15): co-change density
    const telemetry = engine.telemetry.get(node.id);
    let coChangeCount = 0;
    if (telemetry && telemetry.gitCoChanges) {
      for (const [, count] of telemetry.gitCoChanges) {
        if (count > 0) coChangeCount++;
      }
    }
    const changeFrequency = Math.min(15, Math.round(coChangeCount * 0.5));

    const overallRisk = blastRadius + communityLeakage + taintExposure + structuralCentrality + changeFrequency;

    let riskLevel: RiskScore["riskLevel"];
    let recommendation: string;
    if (overallRisk >= 70) {
      riskLevel = "Critical";
      recommendation = "Do not modify without full test suite + code review + staged rollout";
    } else if (overallRisk >= 45) {
      riskLevel = "High";
      recommendation = "Requires code review + targeted tests for impacted nodes";
    } else if (overallRisk >= 20) {
      riskLevel = "Medium";
      recommendation = "Standard review process, run affected tests";
    } else {
      riskLevel = "Low";
      recommendation = "Safe to modify with minimal review";
    }

    scores.push({
      nodeId: node.id,
      name: node.name,
      type: node.type,
      filePath: node.filePath,
      scope: node.scope,
      overallRisk,
      riskFactors: { blastRadius, communityLeakage, taintExposure, structuralCentrality, changeFrequency },
      riskLevel,
      recommendation,
    });
  }

  scores.sort((a, b) => b.overallRisk - a.overallRisk);

  const distribution = { Low: 0, Medium: 0, High: 0, Critical: 0 };
  for (const s of scores) distribution[s.riskLevel]++;

  return {
    nodes: scores,
    distribution,
    topRisks: scores.slice(0, 15),
  };
}

// ==================== Tier 2.2: Onboarding Paths ====================
// Run PPR from entry points (main, route handlers) with high restart probability.
// Top-ranked nodes = "the 20 files a new engineer should read first."
// Uses global PPR (already computed) — just changes the seed.

export interface OnboardingResult {
  entryPoints: Array<{ nodeId: string; name: string; filePath: string; type: string }>;
  recommendedReading: Array<{
    nodeId: string;
    name: string;
    filePath: string;
    scope: string[];
    score: number;
    reason: string;
    concepts: string[];
  }>;
  readingOrder: Array<{ phase: number; description: string; nodes: string[] }>;
}

export function computeOnboardingPath(
  project: ASTProject,
  engine: Engine
): OnboardingResult {
  // Step 1: Identify entry points
  const entryPoints: OnboardingResult["entryPoints"] = [];
  const entryPointIds: string[] = [];

  for (const node of project.allNodes) {
    if (node.name === "main" || node.decorators.some(d => d.name === "@route")) {
      entryPoints.push({ nodeId: node.id, name: node.name, filePath: node.filePath, type: node.type });
      entryPointIds.push(node.id);
    }
    if (node.isExported && node.type === "ClassDeclaration") {
      entryPoints.push({ nodeId: node.id, name: node.name, filePath: node.filePath, type: node.type });
      entryPointIds.push(node.id);
    }
  }

  // Step 2: For each entry point, run PPR with HIGH restart probability (0.5)
  // High restart = stays close to the entry point = "what does this entry point touch?"
  const readingNodes = new Map<string, { score: number; reasons: string[] }>();

  for (const entryId of entryPointIds.slice(0, 5)) {
    const entryNode = project.nodesById.get(entryId);
    if (!entryNode) continue;

    try {
      const result = runPPR(
        engine.pprGraph, project, engine.telemetry, entryId, 0.5, 50, 1e-4
      );
      for (const [nodeId, score] of result.scores) {
        if (score < 0.001 || nodeId === entryId) continue;
        const existing = readingNodes.get(nodeId);
        if (!existing) {
          readingNodes.set(nodeId, { score, reasons: [`Reached from ${entryNode.name}`] });
        } else {
          existing.score = Math.max(existing.score, score);
          existing.reasons.push(`Reached from ${entryNode.name}`);
        }
      }
    } catch {}
  }

  // Step 3: Also add direct call targets from entry points
  for (const entryId of entryPointIds) {
    const callees = project.callGraph.get(entryId) || [];
    for (const calleeId of callees) {
      const existing = readingNodes.get(calleeId);
      if (!existing) {
        readingNodes.set(calleeId, { score: 0.1, reasons: ["Direct call from entry point"] });
      }
    }
  }

  // Step 4: Build reading list with concepts
  const recommendedReading: OnboardingResult["recommendedReading"] = [];
  for (const [nodeId, info] of readingNodes) {
    const node = project.nodesById.get(nodeId);
    if (!node) continue;
    if (node.type !== "FunctionDeclaration" && node.type !== "MethodDeclaration" && node.type !== "ClassDeclaration") continue;

    // Get concept tags from MCU
    const mcuVector = engine.mcu.vectors.find(v => {
      const qn = node.scope.length > 0 ? `${node.scope.join(".")}.${node.name}` : node.name;
      return v.node === qn;
    });

    recommendedReading.push({
      nodeId,
      name: node.scope.length > 0 ? `${node.scope.join(".")}.${node.name}` : node.name,
      filePath: node.filePath,
      scope: node.scope,
      score: info.score,
      reason: info.reasons.join("; "),
      concepts: mcuVector?.conceptTags || [],
    });
  }

  recommendedReading.sort((a, b) => b.score - a.score);

  // Step 5: Group into reading phases
  const readingOrder: OnboardingResult["readingOrder"] = [];
  const top20 = recommendedReading.slice(0, 20);
  const phaseSize = Math.ceil(top20.length / 3);
  for (let i = 0; i < 3; i++) {
    const phaseNodes = top20.slice(i * phaseSize, (i + 1) * phaseSize);
    if (phaseNodes.length === 0) continue;
    readingOrder.push({
      phase: i + 1,
      description: i === 0 ? "Start here: entry points and their direct dependencies"
        : i === 1 ? "Core logic: the main execution paths"
        : "Supporting code: utilities, helpers, and edge cases",
      nodes: phaseNodes.map(n => n.name),
    });
  }

  return {
    entryPoints,
    recommendedReading: top20,
    readingOrder,
  };
}

// ==================== Tier 2.3: Semantic Diffing ====================
// Graph diff, not line diff.
// "This PR deleted 3 WL hashes and introduced 2 new ones.
//  It changed community boundaries between AuthService and SessionManager."

export interface SemanticDiffResult {
  addedNodes: Array<{ name: string; type: string; filePath: string }>;
  removedNodes: Array<{ name: string; type: string; filePath: string }>;
  modifiedNodes: Array<{
    name: string;
    filePath: string;
    changes: string[];
  }>;
  newWLHashes: string[];
  removedWLHashes: string[];
  communityShifts: Array<{
    nodeId: string;
    name: string;
    fromCommunity: number | null;
    toCommunity: number | null;
    significance: string;
  }>;
  summary: string;
}

export function computeSemanticDiff(
  project: ASTProject,
  engine: Engine,
  oldProject?: ASTProject,
  oldEngine?: Engine
): SemanticDiffResult {
  // If no old version provided, compare against an empty baseline
  // (shows everything as "added" — useful for initial analysis)
  const oldNodes = oldProject ? oldProject.allNodes : [];
  const oldCommunities = oldEngine ? oldEngine.leiden.communities : new Map<string, number>();

  const oldNodeIds = new Set(oldNodes.map(n => n.id));
  const currentNodeIds = new Set(project.allNodes.map(n => n.id));

  // Added nodes (in current, not in old)
  const addedNodes = project.allNodes
    .filter(n => !oldNodeIds.has(n.id))
    .filter(n => n.type === "FunctionDeclaration" || n.type === "MethodDeclaration" || n.type === "ClassDeclaration")
    .map(n => ({ name: n.name, type: n.type, filePath: n.filePath }))
    .slice(0, 20);

  // Removed nodes (in old, not in current)
  const removedNodes = oldNodes
    .filter(n => !currentNodeIds.has(n.id))
    .filter(n => n.type === "FunctionDeclaration" || n.type === "MethodDeclaration" || n.type === "ClassDeclaration")
    .map(n => ({ name: n.name, type: n.type, filePath: n.filePath }))
    .slice(0, 20);

  // Modified nodes (in both, but with changed references or scope)
  const modifiedNodes: SemanticDiffResult["modifiedNodes"] = [];
  for (const node of project.allNodes) {
    const oldNode = oldNodes.find(n => n.id === node.id);
    if (!oldNode) continue;

    const changes: string[] = [];
    if (oldNode.references.length !== node.references.length) {
      changes.push(`references: ${oldNode.references.length} → ${node.references.length}`);
    }
    if (JSON.stringify(oldNode.scope) !== JSON.stringify(node.scope)) {
      changes.push(`scope: ${oldNode.scope.join(".")} → ${node.scope.join(".")}`);
    }
    if (oldNode.parameterTypes.length !== node.parameterTypes.length) {
      changes.push(`params: ${oldNode.parameterTypes.length} → ${node.parameterTypes.length}`);
    }

    if (changes.length > 0) {
      modifiedNodes.push({ name: node.name, filePath: node.filePath, changes });
    }
  }

  // WL hash changes
  const currentHashes = engine.wlHashIndex
    ? new Set(engine.wlHashIndex.hashToNodes.keys())
    : new Set<string>();
  const oldHashes = oldEngine?.wlHashIndex
    ? new Set(oldEngine.wlHashIndex.hashToNodes.keys())
    : new Set<string>();

  const newWLHashes = Array.from(currentHashes).filter(h => !oldHashes.has(h));
  const removedWLHashes = Array.from(oldHashes).filter(h => !currentHashes.has(h));

  // Community shifts
  const communityShifts: SemanticDiffResult["communityShifts"] = [];
  for (const node of project.allNodes) {
    const oldComm = oldCommunities.get(node.id) ?? null;
    const newComm = engine.leiden.communities.get(node.id) ?? null;

    if (oldComm !== null && newComm !== null && oldComm !== newComm) {
      communityShifts.push({
        nodeId: node.id,
        name: node.name,
        fromCommunity: oldComm,
        toCommunity: newComm,
        significance: `Moved from community ${oldComm} to ${newComm} — architectural drift detected`,
      });
    }
  }

  // Summary
  const parts: string[] = [];
  if (addedNodes.length > 0) parts.push(`added ${addedNodes.length} nodes`);
  if (removedNodes.length > 0) parts.push(`removed ${removedNodes.length} nodes`);
  if (modifiedNodes.length > 0) parts.push(`modified ${modifiedNodes.length} nodes`);
  if (newWLHashes.length > 0) parts.push(`introduced ${newWLHashes.length} new structural patterns`);
  if (removedWLHashes.length > 0) parts.push(`removed ${removedWLHashes.length} structural patterns`);
  if (communityShifts.length > 0) parts.push(`shifted ${communityShifts.length} nodes between communities`);

  const summary = parts.length > 0
    ? `This change ${parts.join(", ")}.`
    : "No structural changes detected.";

  return {
    addedNodes,
    removedNodes,
    modifiedNodes: modifiedNodes.slice(0, 20),
    newWLHashes: newWLHashes.slice(0, 10),
    removedWLHashes: removedWLHashes.slice(0, 10),
    communityShifts: communityShifts.slice(0, 10),
    summary,
  };
}

// ==================== Tier 3.1: Agent Memory ====================
// Multi-turn PPR state for LLM coding assistants.
// The agent asks for context, we return the payload.
// The agent asks a follow-up, we keep PPR state and return the delta.
// This is the "compressed context" play: 111 tokens vs 4,181 per turn.

export interface AgentMemoryState {
  sessionId: string;
  turn: number;
  visitedNodes: Set<string>;
  lastPayload: { seeds: string[]; impactNodes: string[] } | null;
  pprState: Map<string, number>; // residual PPR scores from last query
}

export interface AgentContextResponse {
  turn: number;
  payload: {
    seeds: string[];
    nodes: string[];
    callTargets: Array<[string, string[]]>;
  };
  tokenCount: number;
  deltaOnly: boolean; // true if this is a follow-up (only new nodes)
  newNodes: string[]; // nodes not seen in previous turns
  visitedTotal: number;
}

// Session store (in-memory, per agent conversation)
const agentSessions = new Map<string, AgentMemoryState>();

export function createAgentSession(sessionId: string): AgentMemoryState {
  const state: AgentMemoryState = {
    sessionId,
    turn: 0,
    visitedNodes: new Set(),
    lastPayload: null,
    pprState: new Map(),
  };
  agentSessions.set(sessionId, state);
  return state;
}

export function getAgentSession(sessionId: string): AgentMemoryState | null {
  return agentSessions.get(sessionId) || null;
}

export function queryAgentContext(
  project: ASTProject,
  engine: Engine,
  sessionId: string,
  query: string
): AgentContextResponse {
  let state = agentSessions.get(sessionId);
  if (!state) {
    state = createAgentSession(sessionId);
  }
  state.turn++;

  // Build payload using the same algorithm as token-benchmark.ts
  
  const results = bm25Search(project, engine.bm25Index, { text: query }, { expandSynonyms: true });

  const seeds = results
    .filter(r => r.node.type === "FunctionDeclaration" || r.node.type === "MethodDeclaration" || r.node.type === "ClassDeclaration")
    .slice(0, 5);

  const impactNodeIds = new Set<string>();
  for (const seed of seeds) {
    impactNodeIds.add(seed.node.id);
    for (const ref of seed.node.references) {
      if (ref.startsWith("call:")) {
        const calleeName = ref.slice(5);
        const callee = project.allNodes.find(n =>
          (n.type === "FunctionDeclaration" || n.type === "MethodDeclaration") && n.name === calleeName
        );
        if (callee) impactNodeIds.add(callee.id);
      }
    }
  }
  for (const r of results.slice(0, 10)) impactNodeIds.add(r.node.id);

  // Compute delta: which nodes are NEW (not visited in previous turns)?
  const newNodes: string[] = [];
  for (const id of impactNodeIds) {
    if (!state.visitedNodes.has(id)) {
      newNodes.push(id);
      state.visitedNodes.add(id);
    }
  }

  // Build compact payload
  const seedNames = seeds.map(s => s.node.scope.length > 0
    ? `${s.node.scope.join(".")}.${s.node.name}`
    : s.node.name
  );

  const nodeSignatures = Array.from(impactNodeIds).map(id => {
    const node = project.nodesById.get(id);
    if (!node) return "?";
    const params = node.parameterTypes.length > 0 ? `(${node.parameterTypes.join(",")})` : "()";
    const ret = node.returnType && !["void", "any", "undefined"].includes(node.returnType.toLowerCase())
      ? `→${node.returnType}` : "";
    const file = node.filePath.split("/").pop() || node.filePath;
    return `${node.name}${params}${ret}@${file}:${node.startLine}`;
  });

  const callTargets = seeds.map(s => {
    const calls = s.node.references.filter(r => r.startsWith("call:")).map(r => r.slice(5));
    return calls.length > 0 ? [s.node.name, calls] as [string, string[]] : null;
  }).filter(Boolean) as Array<[string, string[]]>;

  // Estimate tokens
  const payload = { seeds: seedNames, nodes: nodeSignatures, callTargets };
  const tokenCount = Math.ceil(JSON.stringify(payload).length / 4);

  const isDelta = state.turn > 1 && newNodes.length < impactNodeIds.size;

  state.lastPayload = { seeds: seedNames, impactNodes: Array.from(impactNodeIds) };

  return {
    turn: state.turn,
    payload: {
      seeds: seedNames,
      nodes: isDelta ? nodeSignatures.filter((_, i) => i < newNodes.length + 5) : nodeSignatures,
      callTargets,
    },
    tokenCount,
    deltaOnly: isDelta,
    newNodes: newNodes.map(id => project.nodesById.get(id)?.name || "?").slice(0, 10),
    visitedTotal: state.visitedNodes.size,
  };
}

// ==================== Tier 3.2: Cross-Language Clone → Interface Suggestion ====================
// Given a cluster of cross-language structural clones (same WL hash, different languages),
// suggest the interface for a shared utility.

export interface CloneInterfaceSuggestion {
  hash: string;
  clones: Array<{
    name: string;
    filePath: string;
    language: string;
    parameterTypes: string[];
    returnType: string | null;
  }>;
  suggestedInterface: {
    name: string;
    parameters: Array<{ name: string; type: string }>;
    returnType: string;
    rationale: string;
  };
}

export function suggestSharedInterface(
  project: ASTProject,
  engine: Engine,
  wlHash: string
): CloneInterfaceSuggestion | null {
  if (!engine.wlHashIndex) return null;

  const nodeIds = engine.wlHashIndex.hashToNodes.get(wlHash) || [];
  if (nodeIds.length < 2) return null;

  const clones = nodeIds.map(id => {
    const node = project.nodesById.get(id);
    if (!node) return null;
    const ext = node.filePath.split(".").pop() || "?";
    return {
      name: node.name,
      filePath: node.filePath,
      language: ext,
      parameterTypes: node.parameterTypes,
      returnType: node.returnType,
    };
  }).filter(Boolean) as CloneInterfaceSuggestion["clones"];

  // Check if cross-language
  const languages = new Set(clones.map(c => c.language));
  if (languages.size < 2) return null;

  // Synthesize a shared interface
  // Use the most common parameter pattern across clones
  const paramCounts = new Map<string, number>();
  for (const clone of clones) {
    for (const param of clone.parameterTypes) {
      paramCounts.set(param, (paramCounts.get(param) || 0) + 1);
    }
  }

  // Pick the parameters that appear in the majority of clones
  const threshold = clones.length / 2;
  const sharedParams = Array.from(paramCounts.entries())
    .filter(([_, count]) => count >= threshold)
    .map(([param, _]) => {
      const [name, type] = param.split(":");
      return { name: name || "arg", type: type || "any" };
    });

  // Use the most common return type (non-void)
  const returnTypes = new Map<string, number>();
  for (const clone of clones) {
    if (clone.returnType && clone.returnType !== "void" && clone.returnType !== "any") {
      returnTypes.set(clone.returnType, (returnTypes.get(clone.returnType) || 0) + 1);
    }
  }
  const returnType = returnTypes.size > 0
    ? Array.from(returnTypes.entries()).sort((a, b) => b[1] - a[1])[0][0]
    : "void";

  // Name: use the most common name, or "sharedUtility"
  const nameCounts = new Map<string, number>();
  for (const clone of clones) {
    nameCounts.set(clone.name, (nameCounts.get(clone.name) || 0) + 1);
  }
  const suggestedName = Array.from(nameCounts.entries())
    .sort((a, b) => b[1] - a[1])[0][0] || "sharedUtility";

  return {
    hash: wlHash,
    clones,
    suggestedInterface: {
      name: suggestedName,
      parameters: sharedParams,
      returnType,
      rationale: `${clones.length} clones across ${languages.size} languages (${Array.from(languages).join(", ")}) share this structural pattern. Consolidating into a shared utility would eliminate ${clones.length - 1} duplicate implementations.`,
    },
  };
}
