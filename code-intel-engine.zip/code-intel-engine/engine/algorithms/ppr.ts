// ============================================================
// Module 6: Trace-Weighted Blast-Radius PPR (Personalized PageRank)
// ============================================================
// Standard web PageRank simulates a "random web surfer" clicking hyperlinks.
// Code-Native PPR simulates an *execution path walk* through the ASG.
// Transition probabilities are weighted by:
//   - OpenTelemetry execution frequencies (call counts observed in prod)
//   - APM latency spikes (slow nodes get more attention)
//   - Git co-change history (frequently co-changed nodes are closer)
//
// Given a seed node, PPR computes a deterministic blast-radius score
// for every other node, identifying downstream impact of a change.

import { ASTProject, ASTNode } from "../ast/types";

// Synthetic telemetry data for each ASG node.
// In a real system this would come from OpenTelemetry / APM / git history.
export interface TelemetryData {
  nodeId: string;
  callFrequency: number; // OTel: how many times this node was called in the last 7d
  avgLatencyMs: number; // APM: p50 latency
  p99LatencyMs: number; // APM: p99 latency
  errorRate: number; // 0..1
  gitCoChanges: Map<string, number>; // nodeId -> # co-commits
}

// Generate structural-only telemetry when no OTel dump is available.
//
// When no real telemetry exists, ALL telemetry fields are set to neutral
// values so that the PPR edge weight formula reduces to a pure structural
// weight with zero fabricated runtime data:
//
//   PPR edge weight = (callComponent + latencyComponent + cochangeComponent) × errorComponent
//
// With neutral values:
//   callComponent     = baseCall × (1 + log(1 + 1) / 10)  = baseCall × 1.069
//   latencyComponent  = log(1 + 0) × 0.5                  = 0
//   cochangeComponent = 0 × 0.3                            = 0
//   errorComponent    = 1 + 0 × 10                         = 1
//
// So weight = baseCall × 1.069 for every edge — uniform structural weight.
// No fabricated latency, no fabricated co-change, no fabricated error rate.
// Blast radius is determined purely by graph topology.
//
// gitCoChanges is set to an EMPTY map (not structural co-change) because
// the PPR formula uses it as a weight multiplier. If we populated it with
// same-file counts, we'd be injecting a heuristic that makes same-file
// edges heavier — which is a structural assumption, not telemetry, but
// it's NOT transparent. Keeping it empty ensures the PPR weight is
// deterministic from the call graph alone.
//
// When a real OTel dump IS present, real call frequencies, latencies,
// and error rates replace these neutral values.
export function generateSyntheticTelemetry(project: ASTProject): Map<string, TelemetryData> {
  const map = new Map<string, TelemetryData>();

  for (const node of project.allNodes) {
    // ALL fields zeroed/neutral — no fabricated data of any kind.
    const callFrequency = 1;   // log(1 + 1) / 10 = 0.069 (uniform)
    const avgLatencyMs = 0;    // log(1 + 0) × 0.5 = 0 (no contribution)
    const p99LatencyMs = 0;    // same
    const errorRate = 0;        // 1 + 0 × 10 = 1 (no multiplier)
    const gitCoChanges = new Map<string, number>(); // empty — no co-change weight
    map.set(node.id, {
      nodeId: node.id,
      callFrequency,
      avgLatencyMs,
      p99LatencyMs,
      errorRate,
      gitCoChanges,
    });
  }
  return map;
}

// ------------------- Weighted ASG for PPR -------------------
// We re-weight ASG edges using telemetry to produce transition probabilities.

export interface PPREdge {
  src: string;
  dst: string;
  weight: number;
  // Composition of the weight (for visualization)
  components: {
    call: number;
    latency: number;
    cochange: number;
    error: number;
  };
}

export interface PPRGraph {
  nodes: string[];
  edges: PPREdge[];
  // adjacency: src -> [{dst, weight}]
  outAdjacency: Map<string, Array<{ dst: string; weight: number }>>;
  inAdjacency: Map<string, Array<{ src: string; weight: number }>>;
}

export function buildPPRGraph(
  project: ASTProject,
  telemetry: Map<string, TelemetryData>
): PPRGraph {
  const nodes: string[] = [];
  for (const node of project.allNodes) {
    if (
      node.type === "ClassDeclaration" ||
      node.type === "FunctionDeclaration" ||
      node.type === "MethodDeclaration" ||
      node.type === "ConstructorDeclaration" ||
      node.type === "VariableDeclaration"
    ) {
      nodes.push(node.id);
    }
  }

  const nodeSet = new Set(nodes);
  const edges: PPREdge[] = [];
  const outAdjacency = new Map<string, Array<{ dst: string; weight: number }>>();
  const inAdjacency = new Map<string, Array<{ src: string; weight: number }>>();
  for (const n of nodes) {
    outAdjacency.set(n, []);
    inAdjacency.set(n, []);
  }

  const addEdge = (src: string, dst: string, baseCall: number) => {
    if (!nodeSet.has(src) || !nodeSet.has(dst) || src === dst) return;
    const srcT = telemetry.get(src);
    const dstT = telemetry.get(dst);
    if (!srcT || !dstT) return;

    const callComponent = baseCall * (1 + Math.log(1 + dstT.callFrequency) / 10);
    const latencyComponent = Math.log(1 + dstT.p99LatencyMs) * 0.5;
    const cochangeComponent = (srcT.gitCoChanges.get(dst) || 0) + (dstT.gitCoChanges.get(src) || 0);
    const errorComponent = 1 + dstT.errorRate * 10;
    const weight = (callComponent + latencyComponent + cochangeComponent * 0.3) * errorComponent;

    edges.push({
      src,
      dst,
      weight,
      components: {
        call: callComponent,
        latency: latencyComponent,
        cochange: cochangeComponent * 0.3,
        error: errorComponent,
      },
    });
    outAdjacency.get(src)!.push({ dst, weight });
    inAdjacency.get(dst)!.push({ src, weight });
  };

  // Add call edges (directional: caller -> callee)
  for (const [caller, callees] of project.callGraph) {
    for (const callee of callees) {
      addEdge(caller, callee, 2);
    }
  }

  // Add data-flow edges
  for (const [src, dsts] of project.dataFlowGraph) {
    for (const dst of dsts) {
      addEdge(src, dst, 1);
    }
  }

  // Normalize edge weights to transition probabilities
  for (const n of nodes) {
    const outs = outAdjacency.get(n)!;
    const total = outs.reduce((s, e) => s + e.weight, 0);
    if (total > 0) {
      for (const e of outs) e.weight /= total;
    }
    // Dangling nodes (no out-edges) are handled in the iteration loop
    // by redistributing their score uniformly. See runPPR().
  }

  return { nodes, edges, outAdjacency, inAdjacency };
}

// ------------------- Personalized PageRank -------------------

export interface PPRResult {
  // nodeId -> PPR score (probability of being on this node in steady state,
  // given the seed distribution)
  scores: Map<string, number>;
  // Top-K impacted nodes (blast radius)
  topImpacted: Array<{
    nodeId: string;
    score: number;
    path: string[]; // most likely path from seed to this node
    cumulativeLatency: number;
  }>;
  // Total blast radius (sum of scores outside the seed set, normalized)
  blastRadius: number;
  iterations: number;
}

export function runPPR(
  graph: PPRGraph,
  project: ASTProject,
  telemetry: Map<string, TelemetryData>,
  seedNodeId: string,
  damping: number = 0.85,
  maxIterations: number = 100,
  tolerance: number = 1e-6
): PPRResult {
  const N = graph.nodes.length;
  if (N === 0) {
    return { scores: new Map(), topImpacted: [], blastRadius: 0, iterations: 0 };
  }

  // Initialize uniform probability on the seed
  const scores = new Map<string, number>();
  const seedDistribution = new Map<string, number>();
  for (const n of graph.nodes) {
    scores.set(n, 0);
    seedDistribution.set(n, n === seedNodeId ? 1 : 0);
  }

  // Power iteration (Jacobi method).
  // For global PPR (runs once at index time), we use Jacobi instead of
  // Gauss-Seidel because it handles dangling nodes correctly without
  // the in-place redistribution feedback loop. The speed difference
  // (~7ms vs ~1ms) doesn't matter at index time.
  // Gauss-Seidel is used for subsystem PPR (per-query, needs to be fast).
  let iter = 0;
  let delta = Infinity;
  while (iter < maxIterations && delta > tolerance) {
    iter++;
    const newScores = new Map<string, number>();
    for (const n of graph.nodes) newScores.set(n, 0);

    // Compute dangling mass (total score on dangling nodes)
    let danglingMass = 0;
    for (const n of graph.nodes) {
      const outEdges = graph.outAdjacency.get(n) || [];
      if (outEdges.length === 0) {
        danglingMass += scores.get(n) || 0;
      }
    }

    for (const src of graph.nodes) {
      const s = scores.get(src) || 0;
      if (s === 0) continue;
      const outs = graph.outAdjacency.get(src) || [];
      if (outs.length === 0) {
        // Dangling: redistribute uniformly
        for (const n of graph.nodes) {
          newScores.set(n, (newScores.get(n) || 0) + s / N);
        }
      } else {
        for (const e of outs) {
          newScores.set(e.dst, (newScores.get(e.dst) || 0) + s * e.weight);
        }
      }
    }

    // Apply damping: PPR = damping * walk + (1-damping) * seed
    for (const n of graph.nodes) {
      const v = (newScores.get(n) || 0) * damping + (1 - damping) * (seedDistribution.get(n) || 0);
      newScores.set(n, v);
    }

    delta = 0;
    for (const n of graph.nodes) {
      delta += Math.abs((newScores.get(n) || 0) - (scores.get(n) || 0));
    }
    for (const [k, v] of newScores) scores.set(k, v);
  }

  // Compute top impacted nodes (highest non-seed score)
  const topImpacted: PPRResult["topImpacted"] = [];
  for (const [nodeId, score] of scores) {
    if (nodeId === seedNodeId) continue;
    if (score <= 0) continue;
    topImpacted.push({
      nodeId,
      score,
      path: findMostLikelyPath(graph, seedNodeId, nodeId),
      cumulativeLatency: 0, // computed below
    });
  }
  topImpacted.sort((a, b) => b.score - a.score);
  topImpacted.length = Math.min(topImpacted.length, 15);

  // Compute cumulative latency along the path
  for (const item of topImpacted) {
    let latency = 0;
    for (let i = 0; i < item.path.length - 1; i++) {
      const t = telemetry.get(item.path[i + 1]);
      if (t) latency += t.p99LatencyMs;
    }
    item.cumulativeLatency = latency;
  }

  // Blast radius: 1 - (seed score). If seed score is 1, blast radius is 0
  // (no impact). If seed score is near zero (impossible with damping < 1),
  // blast radius is high.
  const seedScore = scores.get(seedNodeId) || 0;
  const blastRadius = 1 - seedScore;

  return {
    scores,
    topImpacted,
    blastRadius,
    iterations: iter,
  };
}

function findMostLikelyPath(graph: PPRGraph, src: string, dst: string): string[] {
  // Dijkstra-like: find the path with highest product of edge weights.
  // Use -log(weight) as the distance.
  if (src === dst) return [src];
  const dist = new Map<string, number>();
  const prev = new Map<string, string | null>();
  for (const n of graph.nodes) {
    dist.set(n, Infinity);
    prev.set(n, null);
  }
  dist.set(src, 0);

  const queue = new Set<string>(graph.nodes);
  while (queue.size > 0) {
    // Find unvisited node with min dist
    let minNode: string | null = null;
    let minDist = Infinity;
    for (const n of queue) {
      const d = dist.get(n) || Infinity;
      if (d < minDist) {
        minDist = d;
        minNode = n;
      }
    }
    if (minNode === null || minDist === Infinity) break;
    queue.delete(minNode);

    if (minNode === dst) break;

    const outs = graph.outAdjacency.get(minNode) || [];
    for (const e of outs) {
      if (!queue.has(e.dst)) continue;
      const w = e.weight;
      if (w <= 0) continue;
      const alt = dist.get(minNode)! + -Math.log(w);
      if (alt < (dist.get(e.dst) || Infinity)) {
        dist.set(e.dst, alt);
        prev.set(e.dst, minNode);
      }
    }
  }

  // Reconstruct path
  const path: string[] = [];
  let cur: string | null = dst;
  while (cur) {
    path.unshift(cur);
    cur = prev.get(cur) || null;
    if (cur === src) {
      path.unshift(cur);
      break;
    }
  }
  if (path[0] !== src) return [src, dst];
  return path;
}
