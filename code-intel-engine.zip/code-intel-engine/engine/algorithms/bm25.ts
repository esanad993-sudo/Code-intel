// ============================================================
// Module 1: AST-Node Field Inverted Index + Code-Native BM25
// ============================================================
// Unlike standard BM25 that treats code as plain text, we tokenize
// each AST node's *semantic fields* (name, scope, decorators, parameterTypes,
// returnType, references) and build a field-aware inverted index.
//
// IDF weights are computed over AST node frequency, NOT raw text frequency.
// Comments and string literals are explicitly never tokenized.

import { ASTNode, ASTProject, SearchResult, SearchQuery } from "../ast/types";
import { expandQuery as expandQuerySynonyms } from "./synonyms";

export interface IndexField {
  name: string; // e.g. "name", "scope", "decorator"
  tokens: string[];
}

export interface IndexedNode {
  node: ASTNode;
  fields: IndexField[];
  // Combined token frequency map for this node (for BM25 tf)
  tokenFreq: Map<string, number>;
  // Field length (number of tokens) — used as document "length"
  length: number;
}

export interface InvertedIndex {
  // term -> field -> [nodeId, ...]
  postings: Map<string, Map<string, string[]>>;
  // nodeId -> IndexedNode
  docs: Map<string, IndexedNode>;
  // Field name -> average length across all nodes
  avgFieldLength: Map<string, number>;
  // Total number of indexed nodes (documents in IR terms)
  N: number;
  // term -> document frequency (number of nodes containing term in ANY field)
  df: Map<string, number>;
}

// Tokenize an identifier into searchable terms.
// E.g. "authenticateUser" -> ["authenticate", "user", "authenticateuser"]
// E.g. "UserController" -> ["user", "controller", "usercontroller"]
// Lowercased, camelCase split, snake_case split.
// AST-Driven Tokenization: keeps both the split terms AND the original compound
// so exact matching AND structural sub-word matching both score perfectly.
function tokenizeIdent(name: string): string[] {
  if (!name) return [];
  // Strip leading non-alphanumerics
  const cleaned = name.replace(/^[^A-Za-z0-9]+/, "").replace(/[^A-Za-z0-9]+$/, "");
  if (!cleaned) return [];
  // Split camelCase / PascalCase / snake_case / kebab-case
  const parts = cleaned
    .split(/(?=[A-Z])|[_\-.]/)
    .filter((p) => p.length > 0)
    .map((p) => p.toLowerCase());
  // Also include the full identifier (lowercased) for exact-match boost
  const full = cleaned.toLowerCase();
  const tokens = [...parts];
  if (full.length > 0 && !tokens.includes(full)) tokens.push(full);
  return tokens;
}

// Structure-weighted TF: tokens in declaration names get 5-10× weight,
// tokens in parameters get 2×, tokens in body/references get 1×.
// This forces the inverted index to prioritize definitions over usages.
const STRUCTURE_WEIGHTS: Record<string, number> = {
  name: 5,         // MethodDeclaration name, ClassDeclaration identifier → 5×
  scope: 3,        // Enclosing class name → 3×
  decorator: 4,    // @route, @deprecated → 4×
  nodetype: 2,     // "methoddeclaration" etc → 2×
  params: 2,       // Parameter names → 2×
  returntype: 2,   // Return type annotations → 2×
  references: 1,   // Body references (call targets, variable refs) → 1×
  filepath: 1,     // File path tokens → 1×
  // New: component-type field for __type:class, __type:interface, etc.
  // This lets queries like "auth type:interface" filter by AST type.
  type: 3,
};

// Build fields with structure-weighted TF.
// Each token is duplicated according to its field weight, so BM25's term
// frequency naturally prioritizes declaration names over body references.
function buildFields(node: ASTNode): IndexField[] {
  const fields: IndexField[] = [];

  // Field: name (identifier) — 5× weight
  fields.push({
    name: "name",
    tokens: tokenizeIdent(node.name),
  });

  // Field: scope (chain of enclosing scopes) — 3× weight
  fields.push({
    name: "scope",
    tokens: node.scope.flatMap((s) => tokenizeIdent(s)),
  });

  // Field: node type (exact, lowercased) — 2× weight
  fields.push({
    name: "nodetype",
    tokens: [node.type.toLowerCase()],
  });

  // NEW: Component-type field for type filtering.
  // Injects explicit structural tokens: __type:class, __type:method, etc.
  // An AI agent can query "auth type:interface" and we filter by this field.
  fields.push({
    name: "type",
    tokens: [`__type:${node.type.toLowerCase()}`],
  });

  // Field: decorators (e.g. @route -> "route") — 4× weight
  fields.push({
    name: "decorator",
    tokens: node.decorators.map((d) => d.name.replace(/^@/, "").toLowerCase()),
  });

  // Field: parameter types — 2× weight
  const paramTokens: string[] = [];
  for (const p of node.parameterTypes) {
    const [pname, ptype] = p.split(":");
    paramTokens.push(...tokenizeIdent(pname));
    if (ptype) paramTokens.push(...tokenizeIdent(ptype));
  }
  fields.push({ name: "params", tokens: paramTokens });

  // Field: return type — 2× weight
  if (node.returnType) {
    fields.push({ name: "returntype", tokens: tokenizeIdent(node.returnType) });
  }

  // Field: references (call targets + identifiers) — 1× weight (body)
  const refTokens: string[] = [];
  for (const r of node.references) {
    if (r.startsWith("call:")) refTokens.push(...tokenizeIdent(r.slice(5)));
    else if (r.startsWith("ident:")) refTokens.push(...tokenizeIdent(r.slice(6)));
    else if (r.startsWith("member:")) refTokens.push(...tokenizeIdent(r.slice(7)));
  }
  fields.push({ name: "references", tokens: refTokens });

  // Field: file path — 1× weight
  fields.push({
    name: "filepath",
    tokens: tokenizeIdent(node.filePath.split("/").pop() || node.filePath),
  });

  return fields;
}

export function buildInvertedIndex(project: ASTProject): InvertedIndex {
  const postings = new Map<string, Map<string, string[]>>();
  const docs = new Map<string, IndexedNode>();
  const df = new Map<string, number>();
  const fieldLengthSum = new Map<string, number>();
  let fieldCount = new Map<string, number>();

  // Filter to indexable node types
  const indexableTypes = new Set([
    "ClassDeclaration",
    "FunctionDeclaration",
    "MethodDeclaration",
    "ConstructorDeclaration",
    "VariableDeclaration",
    "PropertyDeclaration",
    "ImportDeclaration",
  ]);

  const indexableNodes = project.allNodes.filter((n) => indexableTypes.has(n.type));

  for (const node of indexableNodes) {
    const fields = buildFields(node);
    const tokenFreq = new Map<string, number>();
    let totalLen = 0;
    const seenTerms = new Set<string>();

    for (const field of fields) {
      // Apply structure weight: duplicate tokens by the field weight
      // so BM25's term frequency naturally prioritizes declarations over usages.
      // E.g., a token in "name" (weight 5) is counted 5× vs 1× in "references".
      const weight = STRUCTURE_WEIGHTS[field.name] || 1;
      for (const tok of field.tokens) {
        if (!tok) continue;
        // For weighted fields, add the token `weight` times to the frequency
        totalLen += weight;
        tokenFreq.set(tok, (tokenFreq.get(tok) || 0) + weight);
        seenTerms.add(tok);

        // Update postings: term -> field -> [nodeId]
        if (!postings.has(tok)) postings.set(tok, new Map());
        const fieldMap = postings.get(tok)!;
        if (!fieldMap.has(field.name)) fieldMap.set(field.name, []);
        const arr = fieldMap.get(field.name)!;
        if (arr[arr.length - 1] !== node.id) arr.push(node.id);

        // Update field length sums (weighted)
        fieldLengthSum.set(
          field.name,
          (fieldLengthSum.get(field.name) || 0) + weight
        );
        fieldCount.set(field.name, (fieldCount.get(field.name) || 0) + 1);
      }
    }

    for (const term of seenTerms) {
      df.set(term, (df.get(term) || 0) + 1);
    }

    docs.set(node.id, { node, fields, tokenFreq, length: totalLen });
  }

  const avgFieldLength = new Map<string, number>();
  for (const [field, sum] of fieldLengthSum) {
    avgFieldLength.set(field, sum / (fieldCount.get(field) || 1));
  }

  return {
    postings,
    docs,
    avgFieldLength,
    N: indexableNodes.length,
    df,
  };
}

// BM25 score for a single term against a single node.
// Field-weighted: we sum BM25 scores across all fields the term appears in,
// weighted by field importance (name > scope > decorator > references > ...).
// BM25F field weights: matches the structure weights so that scoring
// also prioritizes declaration names over body references.
const FIELD_WEIGHTS: Record<string, number> = {
  name: 5.0,       // Declaration name → 5× (definitions trump usages)
  scope: 3.0,      // Enclosing class → 3×
  decorator: 4.0,  // @route, @deprecated → 4×
  type: 3.0,       // __type:class etc → 3× (component-type boosting)
  nodetype: 2.0,    // "methoddeclaration" → 2×
  params: 2.0,    // Parameter names → 2×
  returntype: 2.0, // Return type → 2×
  references: 1.0, // Body references → 1×
  filepath: 1.0,   // File path → 1×
};

const BM25_K1 = 1.5;
const BM25_B = 0.75;

export function bm25Score(
  index: InvertedIndex,
  nodeId: string,
  term: string
): number {
  const doc = index.docs.get(nodeId);
  if (!doc) return 0;
  const fieldMap = index.postings.get(term);
  if (!fieldMap) return 0;
  const df = index.df.get(term) || 0;
  if (df === 0) return 0;
  const N = index.N;
  // Standard BM25 IDF (with +1 smoothing to avoid negative IDF)
  const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));

  let score = 0;
  for (const [field, nodeIds] of fieldMap) {
    if (!nodeIds.includes(nodeId)) continue;
    const tf = doc.tokenFreq.get(term) || 0;
    if (tf === 0) continue;
    const avgLen = index.avgFieldLength.get(field) || 1;
    const fieldLen = doc.fields.find((f) => f.name === field)?.tokens.length || 0;
    const norm = 1 - BM25_B + BM25_B * (fieldLen / avgLen);
    const fieldScore = (idf * (tf * (BM25_K1 + 1))) / (tf + BM25_K1 * norm);
    score += fieldScore * (FIELD_WEIGHTS[field] || 1.0);
  }
  return score;
}

export function search(
  project: ASTProject,
  index: InvertedIndex,
  query: SearchQuery,
  options?: { expandSynonyms?: boolean }
): SearchResult[] {
  // Parse "type:X" filters from the query text.
  // E.g., "auth type:interface" → search for "auth" + filter to interface nodes.
  // This is component-type boosting: the AI agent can constrain BM25 by AST type.
  let queryText = query.text;
  const typeFilters: string[] = [];
  const typeMatch = queryText.match(/\btype:(\w+)/g);
  if (typeMatch) {
    for (const m of typeMatch) {
      const t = m.replace("type:", "").toLowerCase();
      typeFilters.push(t);
      queryText = queryText.replace(m, "").trim();
    }
  }

  // Tokenize query text the same way we tokenize identifiers
  const originalTokens = tokenizeIdent(queryText);

  // Optional synonym expansion — algorithmic, deterministic, no embeddings.
  // When enabled, "auth" expands to [authenticate, authentication, authorize, ...].
  // Original tokens get full BM25 weight; synonyms get a 0.5× discount so that
  // exact matches still rank above synonym matches.
  let expandedTerms: Array<{ term: string; isSynonym: boolean }> = originalTokens.map(
    (t) => ({ term: t, isSynonym: false })
  );
  let expansionLog: Array<{ original: string; expansions: string[]; sources: string[] }> = [];
  if (options?.expandSynonyms) {
    const expansion = expandQuerySynonyms(queryText);
    const originalSet = new Set(originalTokens);
    expandedTerms = [
      ...originalTokens.map((t) => ({ term: t, isSynonym: false })),
      ...expansion.expandedTokens
        .filter((t) => !originalSet.has(t))
        .map((t) => ({ term: t, isSynonym: true })),
    ];
    expansionLog = expansion.expansionLog;
  }

  // Apply node-type / scope / decorator / file / type-filter filters first
  const candidateIds: string[] = [];
  for (const [nodeId, indexed] of index.docs) {
    const node = indexed.node;
    if (query.nodeType && node.type !== query.nodeType) continue;
    // Component-type boosting: filter by "type:interface" / "type:class" etc.
    if (typeFilters.length > 0) {
      const nodeTypeLower = node.type.toLowerCase();
      const matchesType = typeFilters.some((tf) => {
        // Support both "interface" and "classdeclaration"
        return nodeTypeLower === tf ||
          nodeTypeLower.includes(tf) ||
          tf.includes(nodeTypeLower);
      });
      if (!matchesType) continue;
    }
    if (query.scope) {
      const scopeMatch = node.scope.some(
        (s) => s.toLowerCase() === query.scope!.toLowerCase()
      );
      if (!scopeMatch) continue;
    }
    if (query.decorator) {
      const decMatch = node.decorators.some(
        (d) => d.name.toLowerCase() === query.decorator!.toLowerCase()
      );
      if (!decMatch) continue;
    }
    if (query.filePath && !node.filePath.includes(query.filePath)) continue;
    candidateIds.push(nodeId);
  }

  // Score each candidate
  const scored: SearchResult[] = [];
  for (const nodeId of candidateIds) {
    const indexed = index.docs.get(nodeId)!;
    const matchedFields: string[] = [];
    let totalScore = 0;

    for (const { term, isSynonym } of expandedTerms) {
      const fieldMap = index.postings.get(term);
      if (!fieldMap) continue;
      const s = bm25Score(index, nodeId, term);
      if (s > 0) {
        // Synonym matches get a 0.5× discount so exact matches rank higher
        totalScore += s * (isSynonym ? 0.5 : 1.0);
        for (const field of fieldMap.keys()) {
          if (!matchedFields.includes(field)) matchedFields.push(field);
        }
      }
    }

    if (totalScore > 0) {
      const node = indexed.node;
      // Build snippet from source lines
      const doc = project.documents.find((d) => d.filePath === node.filePath);
      let snippet = "";
      if (doc) {
        const start = Math.max(0, node.startLine - 1);
        const end = Math.min(doc.sourceLines.length, node.endLine);
        snippet = doc.sourceLines.slice(start, end).join("\n");
      }
      scored.push({
        node,
        score: totalScore,
        matchedFields,
        snippet,
      });
    }
  }

  scored.sort((a, b) => b.score - a.score);
  // Attach expansion log as a non-enumerable property so callers can read it
  // without it polluting the SearchResult shape.
  if (expansionLog.length > 0) {
    Object.defineProperty(scored, "expansionLog", {
      value: expansionLog,
      enumerable: false,
    });
  }
  return scored;
}

// Helper to read the expansion log from a search result list.
export function getExpansionLog(results: SearchResult[]): Array<{
  original: string;
  expansions: string[];
  sources: string[];
}> {
  return (results as any).expansionLog || [];
}

// Compute IDF statistics for display in the UI.
export function getIdfStats(index: InvertedIndex): Array<{ term: string; df: number; idf: number }> {
  const stats: Array<{ term: string; df: number; idf: number }> = [];
  for (const [term, df] of index.df) {
    const idf = Math.log(1 + (index.N - df + 0.5) / (df + 0.5));
    stats.push({ term, df, idf });
  }
  stats.sort((a, b) => b.idf - a.idf);
  return stats;
}
