// ============================================================
// OTel Schema Sink — OpenTelemetry trace ingestion
// ============================================================
// Replaces synthetic telemetry with real production traces.
//
// Developers drop a JSON file at .engine-cache/otel-dump.json containing
// OTel span exports. The engine matches spans against AST nodes by
// function descriptor (Namespace.Class.Method or file:function:line).
//
// The ingestion schema supports both standard OTel export format AND
// a simplified "APM dump" format for easy manual creation.

import { readFileSync, existsSync, writeFileSync, mkdirSync, statSync } from "fs";
import { join } from "path";
import { ASTProject, ASTNode } from "../ast/types";
import { TelemetryData } from "./ppr";

const OTEL_DUMP_PATH = "/home/z/my-project/.engine-cache/otel-dump.json";

// ------------------- OTel ingestion schema -------------------

// Standard OTel ResourceSpans format (simplified subset)
export interface OTelResourceSpans {
  resource?: {
    attributes?: Array<{ key: string; value: { stringValue?: string; intValue?: string } }>;
  };
  scopeSpans?: Array<{
    scope?: { name: string };
    spans: OTelSpan[];
  }>;
}

export interface OTelSpan {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  name: string; // e.g. "AuthService.login" or "GET /login"
  kind?: number; // 0=INTERNAL, 1=SERVER, 2=CLIENT, ...
  startTimeUnixNano?: string;
  endTimeUnixNano?: string;
  attributes?: Array<{ key: string; value: { stringValue?: string; intValue?: string; doubleValue?: number } }>;
  status?: { code?: number; message?: string };
  // Simplified APM dump fields (alternative format)
  durationMs?: number;
  errorMessage?: string;
}

export interface OTelDump {
  resourceSpans?: OTelResourceSpans[];
  // Simplified format: flat list of spans
  spans?: OTelSpan[];
}

// ------------------- Matching logic -------------------

// Match an OTel span name to an AST node.
// Strategy (in priority order):
//   1. Exact "Namespace.Class.Method" match against node scope chain
//   2. "Class.method" match
//   3. Bare function name match (e.g. "hashPassword")
//   4. HTTP route path match (e.g. "GET /login" against @route decorators)
export interface SpanMatch {
  spanName: string;
  nodeId: string | null;
  nodeName: string;
  matchKind: "exact" | "class.method" | "function" | "route" | "unmatched";
  durationMs: number;
  isError: boolean;
}

export interface IngestionResult {
  totalSpans: number;
  matchedSpans: number;
  unmatchedSpans: number;
  matches: SpanMatch[];
  // Per-node aggregated telemetry
  nodeTelemetry: Map<string, TelemetryData>;
  // Stats for the UI
  stats: {
    avgDurationMs: number;
    p99DurationMs: number;
    errorRate: number;
    totalErrors: number;
    uniqueFunctions: number;
    unmatchedSpanNames: string[];
  };
  // Source file we ingested from
  source: string;
  ingestedAt: string;
}

function parseOTelDump(raw: any): OTelSpan[] {
  const spans: OTelSpan[] = [];
  // Standard OTel format
  if (raw.resourceSpans) {
    for (const rs of raw.resourceSpans) {
      for (const ss of rs.scopeSpans || []) {
        for (const span of ss.spans || []) {
          spans.push(span);
        }
      }
    }
  }
  // Simplified format
  if (raw.spans) {
    spans.push(...raw.spans);
  }
  return spans;
}

function getSpanDurationMs(span: OTelSpan): number {
  if (span.durationMs !== undefined) return span.durationMs;
  if (span.startTimeUnixNano && span.endTimeUnixNano) {
    const start = parseInt(span.startTimeUnixNano, 10);
    const end = parseInt(span.endTimeUnixNano, 10);
    return (end - start) / 1_000_000; // ns to ms
  }
  return 0;
}

function isSpanError(span: OTelSpan): boolean {
  if (span.status?.code === 2) return true; // STATUS_CODE_ERROR
  if (span.errorMessage) return true;
  if (span.attributes) {
    for (const attr of span.attributes) {
      if (attr.key === "error" && attr.value.boolValue) return true;
      if (attr.key === "http.status_code") {
        const code = parseInt(attr.value.intValue || "0", 10);
        if (code >= 400) return true;
      }
    }
  }
  return false;
}

function matchSpanToNode(span: OTelSpan, project: ASTProject): SpanMatch {
  const spanName = span.name;
  const durationMs = getSpanDurationMs(span);
  const isError = isSpanError(span);

  // Strategy 1: Exact "Namespace.Class.Method" — match against scope chain
  const parts = spanName.split(/[.:]/).filter(Boolean);
  if (parts.length >= 2) {
    const methodName = parts[parts.length - 1];
    const className = parts[parts.length - 2];
    for (const node of project.allNodes) {
      if (
        (node.type === "MethodDeclaration" || node.type === "FunctionDeclaration") &&
        node.name === methodName &&
        node.scope.includes(className)
      ) {
        return {
          spanName,
          nodeId: node.id,
          nodeName: `${className}.${methodName}`,
          matchKind: "exact",
          durationMs,
          isError,
        };
      }
    }
  }

  // Strategy 2: "Class.method" (dot-separated)
  if (spanName.includes(".")) {
    const [cls, mth] = spanName.split(".").slice(-2);
    for (const node of project.allNodes) {
      if (
        (node.type === "MethodDeclaration" || node.type === "FunctionDeclaration") &&
        node.name === mth &&
        node.scope.includes(cls)
      ) {
        return {
          spanName,
          nodeId: node.id,
          nodeName: `${cls}.${mth}`,
          matchKind: "class.method",
          durationMs,
          isError,
        };
      }
    }
  }

  // Strategy 3: Bare function name
  for (const node of project.allNodes) {
    if (
      (node.type === "MethodDeclaration" || node.type === "FunctionDeclaration") &&
      node.name === spanName
    ) {
      return {
        spanName,
        nodeId: node.id,
        nodeName: node.name,
        matchKind: "function",
        durationMs,
        isError,
      };
    }
  }

  // Strategy 4: HTTP route path (e.g. "GET /login")
  const routeMatch = spanName.match(/^(GET|POST|PUT|DELETE|PATCH)\s+(\/\S+)/);
  if (routeMatch) {
    const [, method, path] = routeMatch;
    for (const node of project.allNodes) {
      const routeDec = node.decorators.find((d) => d.name === "@route");
      if (routeDec) {
        const decPath = routeDec.args[0];
        const decMethod = routeDec.args[1] || "GET";
        if (decPath === path && decMethod.toUpperCase() === method) {
          return {
            spanName,
            nodeId: node.id,
            nodeName: `${method} ${path}`,
            matchKind: "route",
            durationMs,
            isError,
          };
        }
      }
    }
  }

  return {
    spanName,
    nodeId: null,
    nodeName: spanName,
    matchKind: "unmatched",
    durationMs,
    isError,
  };
}

// Aggregate matched spans into per-node TelemetryData
function aggregateTelemetry(
  matches: SpanMatch[],
  project: ASTProject
): Map<string, TelemetryData> {
  const byNode = new Map<string, SpanMatch[]>();
  for (const m of matches) {
    if (m.nodeId === null) continue;
    if (!byNode.has(m.nodeId)) byNode.set(m.nodeId, []);
    byNode.get(m.nodeId)!.push(m);
  }

  const result = new Map<string, TelemetryData>();
  for (const [nodeId, spans] of byNode) {
    const durations = spans.map((s) => s.durationMs).sort((a, b) => a - b);
    const errors = spans.filter((s) => s.isError).length;
    const callFrequency = spans.length;
    const avgLatencyMs =
      durations.length > 0
        ? durations.reduce((s, d) => s + d, 0) / durations.length
        : 0;
    // p99 latency
    const p99Idx = Math.floor(durations.length * 0.99);
    const p99LatencyMs = durations.length > 0 ? durations[Math.min(p99Idx, durations.length - 1)] : 0;
    const errorRate = callFrequency > 0 ? errors / callFrequency : 0;

    // Git co-change is preserved from synthetic (we don't have real git history
    // in the OTel dump). Cross-reference with the existing telemetry if present.
    const gitCoChanges = new Map<string, number>();
    for (const other of project.allNodes) {
      if (other.id === nodeId) continue;
      if (other.filePath === project.nodesById.get(nodeId)?.filePath) {
        gitCoChanges.set(other.id, 3);
      }
    }

    result.set(nodeId, {
      nodeId,
      callFrequency,
      avgLatencyMs: Math.round(avgLatencyMs * 100) / 100,
      p99LatencyMs: Math.round(p99LatencyMs * 100) / 100,
      errorRate: Math.round(errorRate * 10000) / 10000,
      gitCoChanges,
    });
  }

  return result;
}

export function ingestOTelDump(project: ASTProject, dumpPath: string = OTEL_DUMP_PATH): IngestionResult {
  if (!existsSync(dumpPath)) {
    return {
      totalSpans: 0,
      matchedSpans: 0,
      unmatchedSpans: 0,
      matches: [],
      nodeTelemetry: new Map(),
      stats: {
        avgDurationMs: 0,
        p99DurationMs: 0,
        errorRate: 0,
        totalErrors: 0,
        uniqueFunctions: 0,
        unmatchedSpanNames: [],
      },
      source: dumpPath,
      ingestedAt: new Date().toISOString(),
    };
  }

  const raw = JSON.parse(readFileSync(dumpPath, "utf-8"));
  const spans = parseOTelDump(raw);
  const matches: SpanMatch[] = spans.map((s) => matchSpanToNode(s, project));
  const matched = matches.filter((m) => m.nodeId !== null);
  const unmatched = matches.filter((m) => m.nodeId === null);

  const nodeTelemetry = aggregateTelemetry(matches, project);

  // Stats
  const allDurations = matches.map((m) => m.durationMs).filter((d) => d > 0).sort((a, b) => a - b);
  const totalErrors = matches.filter((m) => m.isError).length;
  const avgDurationMs =
    allDurations.length > 0
      ? allDurations.reduce((s, d) => s + d, 0) / allDurations.length
      : 0;
  const p99Idx = Math.floor(allDurations.length * 0.99);
  const p99DurationMs = allDurations.length > 0 ? allDurations[Math.min(p99Idx, allDurations.length - 1)] : 0;
  const errorRate = matches.length > 0 ? totalErrors / matches.length : 0;

  // Collect unique unmatched span names (top 10)
  const unmatchedNames = Array.from(new Set(unmatched.map((m) => m.spanName))).slice(0, 10);

  return {
    totalSpans: spans.length,
    matchedSpans: matched.length,
    unmatchedSpans: unmatched.length,
    matches: matches.slice(0, 50), // cap for UI display
    nodeTelemetry,
    stats: {
      avgDurationMs: Math.round(avgDurationMs * 100) / 100,
      p99DurationMs: Math.round(p99DurationMs * 100) / 100,
      errorRate: Math.round(errorRate * 10000) / 100,
      totalErrors,
      uniqueFunctions: nodeTelemetry.size,
      unmatchedSpanNames: unmatchedNames,
    },
    source: dumpPath,
    ingestedAt: new Date().toISOString(),
  };
}

// Generate a sample OTel dump file that matches our sample codebase.
// Developers can use this as a template for their own dumps.
export function generateSampleOTelDump(project: ASTProject): OTelDump {
  const spans: OTelSpan[] = [];

  // Generate spans for hot-path functions
  const hotFunctions = [
    { name: "AuthService.login", method: "POST", path: "/login", count: 8540, p99: 412, errRate: 0.045 },
    { name: "AuthService.authenticateUser", method: "GET", path: "/users/me", count: 6230, p99: 156, errRate: 0.022 },
    { name: "AuthService.registerUser", method: "POST", path: "/register", count: 4100, p99: 198, errRate: 0.018 },
    { name: "AuthService.revokeToken", method: "POST", path: "/logout", count: 210, p99: 87, errRate: 0.005 },
    { name: "Database.query", count: 1890, p99: 195, errRate: 0.041 },
    { name: "Database.findUser", count: 6840, p99: 56, errRate: 0.012 },
    { name: "Database.createUser", count: 4100, p99: 142, errRate: 0.008 },
    { name: "UserRepository.findById", count: 2370, p99: 506, errRate: 0.031 },
    { name: "UserRepository.create", count: 4100, p99: 142, errRate: 0.008 },
    { name: "hashPassword", count: 12600, p99: 58, errRate: 0.003 },
    { name: "verifyToken", count: 7400, p99: 537, errRate: 0.018 },
    { name: "EmailService.send", count: 5810, p99: 49, errRate: 0.008 },
    { name: "validateEmail", count: 4100, p99: 1, errRate: 0.0 },
    { name: "validatePassword", count: 4100, p99: 1, errRate: 0.0 },
    { name: "Logger.info", count: 42000, p99: 1, errRate: 0.0 },
    { name: "Logger.error", count: 1240, p99: 1, errRate: 0.0 },
  ];

  for (const hf of hotFunctions) {
    const errorCount = Math.floor(hf.count * hf.errRate);
    for (let i = 0; i < Math.min(hf.count, 100); i++) {
      // Cap at 100 spans per function for the sample dump
      const isError = i < errorCount;
      const durationVariation = 0.5 + Math.random();
      const duration = Math.round(hf.p99 * durationVariation * 10) / 10;
      const startNs = (Date.now() - i * 1000) * 1_000_000;
      spans.push({
        traceId: `trace-${hf.name}-${i}`.replace(/[^a-zA-Z0-9]/g, "").padEnd(32, "0").slice(0, 32),
        spanId: `span${i}`.padEnd(16, "0").slice(0, 16),
        name: hf.name,
        kind: 1, // SERVER
        startTimeUnixNano: startNs.toString(),
        endTimeUnixNano: (startNs + duration * 1_000_000).toString(),
        durationMs: duration,
        status: isError ? { code: 2, message: "internal error" } : { code: 1 },
        errorMessage: isError ? "InternalServerError" : undefined,
        attributes: hf.path
          ? [
              { key: "http.method", value: { stringValue: hf.method } },
              { key: "http.route", value: { stringValue: hf.path } },
              { key: "http.status_code", value: { intValue: isError ? "500" : "200" } },
            ]
          : [
              { key: "code.function", value: { stringValue: hf.name } },
            ],
      });
    }
  }

  return { spans };
}

// Save a sample OTel dump to disk so the user can see the format
export function writeSampleOTelDump(project: ASTProject): string {
  const dump = generateSampleOTelDump(project);
  const dir = "/home/z/my-project/.engine-cache";
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
  writeFileSync(OTEL_DUMP_PATH, JSON.stringify(dump, null, 2));
  return OTEL_DUMP_PATH;
}

export function hasOTelDump(): boolean {
  return existsSync(OTEL_DUMP_PATH);
}

export function getOTelDumpInfo(): { exists: boolean; path: string; sizeKB: number } {
  if (!existsSync(OTEL_DUMP_PATH)) {
    return { exists: false, path: OTEL_DUMP_PATH, sizeKB: 0 };
  }
  const stat = statSync(OTEL_DUMP_PATH);
  return { exists: true, path: OTEL_DUMP_PATH, sizeKB: Math.round(stat.size / 1024) };
}
