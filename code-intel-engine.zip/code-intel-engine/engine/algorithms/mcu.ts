// ============================================================
// Module 7: Code-Native MCU
// Execution-Informed Virtual Type Inference
// ============================================================
// LSPs operate inside a closed mathematical loop of static type definitions.
// If a variable is typed as `string`, the LSP treats all strings identically —
// it cannot tell a JWT from a UUID from raw HTML.
//
// This engine layers a Virtual Type & Concept Lattice on top of the ASG.
// Each ASG node is fused with:
//   [Static Type (LSP)]      — from our AST parser (returnType, parameterTypes)
//   [Runtime Traces]         — from telemetry (call frequency, latency, errors)
//   [Git Blame / PR history] — synthetic co-change counts (see telemetry)
//   [Semantic Docs]          — extracted from comments / docstrings
//
// The result is a unified "Virtual Type Vector" that AI agents can query for
// autocomplete / context that knows about production behavior, not just syntax.

import { ASTProject, ASTNode } from "../ast/types";
import { TelemetryData } from "./ppr";

// ------------------- Semantic Concept Binding -------------------
// Pull natural-language docs from the source (comments above a node,
// docstrings inside its body) and bind them to the node.

export interface SemanticDoc {
  text: string;
  // Extracted concept tags — high-signal keywords like "auth", "cache",
  // "deprecated", "critical", "leak", "hot path" derived from the doc text.
  conceptTags: string[];
  // Semantic intent — high-level category inferred from tags
  intent: string;
}

// Map of node id → extracted doc text
export function extractDocs(project: ASTProject): Map<string, SemanticDoc> {
  const result = new Map<string, SemanticDoc>();

  // Per file, walk lines above each top-level node to grab comments.
  for (const doc of project.documents) {
    const lines = doc.sourceLines;
    for (const node of doc.nodes) {
      if (node.type === "Program" || node.type === "ImportDeclaration") continue;
      // Walk upward from startLine, collecting consecutive comment lines
      const collected: string[] = [];
      let i = node.startLine - 2; // startLine is 1-indexed; -2 = line above
      while (i >= 0 && i < lines.length) {
        const trimmed = lines[i].trim();
        if (trimmed.startsWith("//")) {
          collected.unshift(trimmed.replace(/^\/\/\s?/, ""));
          i--;
        } else if (trimmed.startsWith("*") || trimmed.startsWith("/*")) {
          collected.unshift(trimmed.replace(/^[\s/*]+/, "").replace(/\*\/$/, "").trim());
          i--;
        } else if (trimmed === "") {
          // allow blank line right above node
          i--;
          if (i >= 0 && !lines[i].trim().startsWith("//") && !lines[i].trim().startsWith("*")) {
            break;
          }
        } else {
          break;
        }
      }

      // Also grab in-body comments (block comments inside the node)
      for (let j = node.startLine - 1; j < node.endLine && j < lines.length; j++) {
        const t = lines[j].trim();
        if (t.startsWith("//") || t.startsWith("*")) {
          collected.push(t.replace(/^[\s/*]+/, "").replace(/\*\/$/, "").trim());
        }
      }

      const text = collected.join(" ").trim();
      if (!text) {
        result.set(node.id, { text: "", conceptTags: [], intent: "Unclassified" });
        continue;
      }
      const conceptTags = extractConceptTags(text);
      const intent = inferIntent(conceptTags, node);
      result.set(node.id, { text, conceptTags, intent });
    }
  }

  return result;
}

const CONCEPT_LEXICON: Record<string, string[]> = {
  Authentication: ["auth", "login", "logout", "token", "session", "credential", "password"],
  Authorization: ["permission", "role", "admin", "access", "rbac", "policy"],
  Crypto: ["hash", "encrypt", "decrypt", "salt", "pbkdf", "hmac", "sha"],
  Database: ["query", "sql", "insert", "update", "delete", "select", "table", "row"],
  Caching: ["cache", "cached", "memoize", "warm"],
  Logging: ["log", "logger", "debug", "info", "warn", "error", "trace"],
  Validation: ["validate", "valid", "regex", "schema", "sanitize"],
  Email: ["email", "smtp", "send", "template", "welcome", "reset"],
  HTTP: ["route", "request", "response", "handler", "endpoint", "rest", "api"],
  Deprecated: ["deprecated", "obsolete", "legacy", "do not use"],
  Critical: ["critical", "tier-0", "hot path", "blast radius", "production"],
  Leak: ["leak", "memory", "footprint", "growth", "unbounded"],
  Untrusted: ["untrusted", "input", "user input", "taint"],
  ReadHeavy: ["read", "read-heavy", "lookup", "find", "get"],
  WriteHeavy: ["write", "write-heavy", "create", "insert", "update"],
};

function extractConceptTags(text: string): string[] {
  const lower = text.toLowerCase();
  const tags: string[] = [];
  for (const [tag, keywords] of Object.entries(CONCEPT_LEXICON)) {
    for (const kw of keywords) {
      if (lower.includes(kw)) {
        if (!tags.includes(tag)) tags.push(tag);
        break;
      }
    }
  }
  return tags;
}

function inferIntent(tags: string[], node: ASTNode): string {
  if (tags.includes("Authentication")) return "Authentication / Session Management";
  if (tags.includes("Authorization")) return "Authorization / RBAC";
  if (tags.includes("Crypto")) return "Cryptographic Operation";
  if (tags.includes("Database")) return "Persistence Layer";
  if (tags.includes("Caching")) return "Caching Layer";
  if (tags.includes("Email")) return "Notification / Email";
  if (tags.includes("Logging")) return "Observability";
  if (tags.includes("Validation")) return "Input Validation / Sanitization";
  if (tags.includes("HTTP")) return "HTTP Transport Layer";
  if (tags.includes("Deprecated")) return "Deprecated — Do Not Use";
  if (tags.includes("Leak")) return "Memory Leak Suspect";
  if (tags.includes("Untrusted")) return "Untrusted Input Boundary";
  if (tags.includes("Critical")) return "Critical Path";
  // Heuristic from AST node type
  if (node.type === "ClassDeclaration") return "Module / Class";
  if (node.type === "FunctionDeclaration" || node.type === "MethodDeclaration") {
    return "Function / Method";
  }
  return "Unclassified";
}

// ------------------- Dynamic Shape Augmentation -------------------
// Tag the static type with a shadow array of runtime properties
// compiled from telemetry.

export type MemoryFootprint = "O(1)" | "O(log N)" | "O(N)" | "O(N log N)" | "O(N²)";
export type CallFrequency = "Cold" | "Low" | "Medium" | "High" | "Extreme";
export type LatencyGrade = "Sub-ms" | "Fast" | "Moderate" | "Slow" | "Critical";

export interface DynamicShape {
  memoryFootprint: MemoryFootprint;
  callFrequency: CallFrequency;
  latencyGrade: LatencyGrade;
  errorRatePercent: number;
  blastRadiusGrade: "Tier-3 Low" | "Tier-2 Moderate" | "Tier-1 High" | "Tier-0 Critical";
}

function classifyCallFrequency(freq: number): CallFrequency {
  if (freq < 50) return "Cold";
  if (freq < 500) return "Low";
  if (freq < 2000) return "Medium";
  if (freq < 5000) return "High";
  return "Extreme";
}

function classifyLatency(p99ms: number): LatencyGrade {
  if (p99ms < 1) return "Sub-ms";
  if (p99ms < 20) return "Fast";
  if (p99ms < 100) return "Moderate";
  if (p99ms < 500) return "Slow";
  return "Critical";
}

function classifyMemoryFootprint(node: ASTNode): MemoryFootprint {
  // Heuristic: methods that allocate arrays / collect rows have higher footprint.
  const refs = node.references;
  let allocHints = 0;
  for (const r of refs) {
    const lower = r.toLowerCase();
    if (lower.includes("map") || lower.includes("filter") || lower.includes("reduce")) {
      allocHints += 1;
    }
    if (lower.includes("query") || lower.includes("find") || lower.includes("select")) {
      allocHints += 1;
    }
  }
  if (allocHints === 0) return "O(1)";
  if (allocHints === 1) return "O(N)";
  return "O(N log N)";
}

function classifyBlastRadius(
  blastRadiusScore: number
): DynamicShape["blastRadiusGrade"] {
  if (blastRadiusScore >= 0.7) return "Tier-0 Critical";
  if (blastRadiusScore >= 0.4) return "Tier-1 High";
  if (blastRadiusScore >= 0.15) return "Tier-2 Moderate";
  return "Tier-3 Low";
}

export function buildDynamicShape(
  node: ASTNode,
  telemetry: TelemetryData,
  blastRadiusScore: number
): DynamicShape {
  return {
    memoryFootprint: classifyMemoryFootprint(node),
    callFrequency: classifyCallFrequency(telemetry.callFrequency),
    latencyGrade: classifyLatency(telemetry.p99LatencyMs),
    errorRatePercent: Math.round(telemetry.errorRate * 10000) / 100,
    blastRadiusGrade: classifyBlastRadius(blastRadiusScore),
  };
}

// ------------------- Virtual Type Vector -------------------
// The unified execution-enriched object returned when an AI agent queries
// a node — what an LSP cannot produce.

export interface VirtualTypeAttribute {
  semantic_intent: string;
  production_behavior: string;
  blast_radius_grade: string;
  implicit_constraints: string[];
}

export interface VirtualTypeVector {
  node: string; // fully-qualified name e.g. "AuthService.getUser"
  lsp_type: string; // static signature, e.g. "(id: string) => Promise<User>"
  virtual_type_attributes: VirtualTypeAttribute;
  dynamic_shape: DynamicShape;
  semantic_doc: SemanticDoc;
  // Combined "MCU score" — how much production context this node carries.
  // Higher = more contextualized = more useful for AI autocomplete.
  mcuScore: number;
  // Sub-concepts attached to the lattice node
  conceptTags: string[];
  // The fused data sources that fed this vector
  sources: {
    lspType: boolean;
    telemetry: boolean;
    gitBlame: boolean;
    semanticDocs: boolean;
  };
}

export interface MCUResult {
  vectors: VirtualTypeVector[];
  // Concept lattice: each concept → list of node ids bound to it
  conceptLattice: Array<{ concept: string; nodeIds: string[]; intent: string }>;
  // Type-shape lattice: each (static type, dynamic shape) pair → node ids
  typeShapeLattice: Array<{
    staticType: string;
    dynamicShape: string;
    nodeIds: string[];
  }>;
  // Distribution of blast-radius grades
  blastRadiusDistribution: Record<string, number>;
  // Top "context-rich" nodes (highest MCU score)
  topContextualized: VirtualTypeVector[];
  // Anomalies: nodes whose static type hides a production problem.
  anomalies: Array<{
    nodeId: string;
    nodeName: string;
    kind: "MemoryLeakSuspect" | "HighErrorRate" | "CriticalLatency" | "TypeDoesNotMatchBehavior";
    detail: string;
  }>;
}

// Build the virtual type vectors for all ASG nodes.
export function buildVirtualTypes(
  project: ASTProject,
  telemetry: Map<string, TelemetryData>,
  docs: Map<string, SemanticDoc>,
  blastRadiusScores: Map<string, number>
): VirtualTypeVector[] {
  const vectors: VirtualTypeVector[] = [];

  for (const node of project.allNodes) {
    if (
      node.type !== "FunctionDeclaration" &&
      node.type !== "MethodDeclaration" &&
      node.type !== "ConstructorDeclaration" &&
      node.type !== "ClassDeclaration"
    ) {
      continue;
    }

    const t = telemetry.get(node.id);
    const d = docs.get(node.id);
    if (!t || !d) continue;

    const blastScore = blastRadiusScores.get(node.id) ?? 0;
    const shape = buildDynamicShape(node, t, blastScore);

    // Build the static type signature
    const params = node.parameterTypes.length
      ? node.parameterTypes.join(", ")
      : "";
    const ret = node.returnType || "void";
    const lspType =
      node.type === "ClassDeclaration"
        ? `class ${node.name}`
        : `(${params}) => ${ret}`;

    // Build implicit constraints from concept tags + telemetry
    const constraints: string[] = [];
    if (d.conceptTags.includes("Authentication")) {
      constraints.push("Must be called inside an authenticated request scope");
    }
    if (d.conceptTags.includes("Crypto")) {
      constraints.push("CPU-intensive — avoid in hot path");
    }
    if (d.conceptTags.includes("Database")) {
      constraints.push("Issues SQL — count against connection pool");
    }
    if (d.conceptTags.includes("Untrusted")) {
      constraints.push("Consumes untrusted input — must validate downstream");
    }
    if (shape.callFrequency === "Extreme") {
      constraints.push(`Called ${t.callFrequency}×/week — must stay sub-${Math.ceil(t.p99LatencyMs)}ms`);
    }
    if (shape.errorRatePercent > 1) {
      constraints.push(`Error rate ${shape.errorRatePercent}% — investigate`);
    }
    if (node.decorators.some((dec) => dec.name === "@Deprecated")) {
      constraints.push("Marked @Deprecated — do not introduce new callers");
    }
    if (node.decorators.some((dec) => dec.name === "@adminOnly")) {
      constraints.push("Admin-only — caller must pass @authenticated + @adminOnly");
    }

    // Build production_behavior summary
    const behavior: string[] = [];
    if (shape.callFrequency === "Extreme" || shape.callFrequency === "High") {
      behavior.push("Hot path");
    } else if (shape.callFrequency === "Cold") {
      behavior.push("Cold path");
    }
    if (d.conceptTags.includes("Caching")) behavior.push("cache-backed");
    if (d.conceptTags.includes("ReadHeavy")) behavior.push("read-heavy");
    if (d.conceptTags.includes("WriteHeavy")) behavior.push("write-heavy");
    behavior.push(`${shape.latencyGrade.toLowerCase()} latency`);
    const productionBehavior = behavior.join(", ");

    // MCU score: weighted blend of telemetry + concept + blast radius richness
    const conceptRichness = d.conceptTags.length;
    const mcuScore =
      Math.log(1 + t.callFrequency) * 0.3 +
      Math.log(1 + t.p99LatencyMs) * 0.15 +
      conceptRichness * 1.5 +
      blastScore * 10 +
      (d.text.length > 0 ? 1 : 0) +
      (node.decorators.length > 0 ? 1 : 0);

    vectors.push({
      node: node.scope.length > 0 ? `${node.scope.join(".")}.${node.name}` : node.name,
      lsp_type: lspType,
      virtual_type_attributes: {
        semantic_intent: d.intent,
        production_behavior: productionBehavior || "Standard",
        blast_radius_grade: shape.blastRadiusGrade,
        implicit_constraints: constraints,
      },
      dynamic_shape: shape,
      semantic_doc: d,
      mcuScore: Math.round(mcuScore * 100) / 100,
      conceptTags: d.conceptTags,
      sources: {
        lspType: true,
        telemetry: true,
        gitBlame: t.gitCoChanges.size > 0,
        semanticDocs: d.text.length > 0,
      },
    });
  }

  return vectors.sort((a, b) => b.mcuScore - a.mcuScore);
}

// Build the concept lattice — group nodes by semantic concept tag.
export function buildConceptLattice(
  project: ASTProject,
  docs: Map<string, SemanticDoc>
): MCUResult["conceptLattice"] {
  const conceptToNodes = new Map<string, Array<{ nodeId: string; intent: string }>>();
  for (const node of project.allNodes) {
    const d = docs.get(node.id);
    if (!d) continue;
    for (const tag of d.conceptTags) {
      if (!conceptToNodes.has(tag)) conceptToNodes.set(tag, []);
      conceptToNodes.get(tag)!.push({ nodeId: node.id, intent: d.intent });
    }
  }
  const lattice: MCUResult["conceptLattice"] = [];
  for (const [concept, entries] of conceptToNodes) {
    const intents = new Set(entries.map((e) => e.intent));
    lattice.push({
      concept,
      nodeIds: entries.map((e) => e.nodeId),
      intent: Array.from(intents).join(" / "),
    });
  }
  lattice.sort((a, b) => b.nodeIds.length - a.nodeIds.length);
  return lattice;
}

// Build the type-shape lattice — group nodes by (static type, dynamic shape).
// This is what makes the "virtual type" useful: nodes that share a static type
// but differ in dynamic shape are NOT interchangeable, even though the LSP
// says they are.
export function buildTypeShapeLattice(
  vectors: VirtualTypeVector[]
): MCUResult["typeShapeLattice"] {
  const map = new Map<string, string[]>();
  for (const v of vectors) {
    const shapeKey = `${v.dynamic_shape.callFrequency}/${v.dynamic_shape.latencyGrade}/${v.dynamic_shape.blastRadiusGrade}`;
    // Bucket by the return type only (so similar signatures group together)
    const retType = v.lsp_type.includes("=>")
      ? v.lsp_type.split("=>").pop()!.trim()
      : v.lsp_type;
    const key = `${retType} :: ${shapeKey}`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(v.node);
  }
  const lattice: MCUResult["typeShapeLattice"] = [];
  for (const [key, nodeIds] of map) {
    const [staticType, dynamicShape] = key.split(" :: ");
    lattice.push({ staticType, dynamicShape, nodeIds });
  }
  lattice.sort((a, b) => b.nodeIds.length - a.nodeIds.length);
  return lattice;
}

// Detect anomalies: nodes whose static type hides a production problem.
export function detectAnomalies(
  project: ASTProject,
  vectors: VirtualTypeVector[]
): MCUResult["anomalies"] {
  const anomalies: MCUResult["anomalies"] = [];
  for (const v of vectors) {
    const node = project.allNodes.find((n) => {
      const qn = n.scope.length > 0 ? `${n.scope.join(".")}.${n.name}` : n.name;
      return qn === v.node;
    });
    if (!node) continue;

    // High error rate
    if (v.dynamic_shape.errorRatePercent > 2) {
      anomalies.push({
        nodeId: node.id,
        nodeName: v.node,
        kind: "HighErrorRate",
        detail: `Error rate ${v.dynamic_shape.errorRatePercent}% — LSP type is valid but production behavior is broken.`,
      });
    }
    // Critical latency on a function whose static return type looks benign
    if (v.dynamic_shape.latencyGrade === "Critical" && v.lsp_type.includes("Promise")) {
      anomalies.push({
        nodeId: node.id,
        nodeName: v.node,
        kind: "CriticalLatency",
        detail: `p99 latency ${"critical"} — async signature hides a slow operation.`,
      });
    }
    // Memory leak suspect: large memory footprint + high call frequency
    if (
      (v.dynamic_shape.memoryFootprint === "O(N)" || v.dynamic_shape.memoryFootprint === "O(N log N)") &&
      (v.dynamic_shape.callFrequency === "High" || v.dynamic_shape.callFrequency === "Extreme")
    ) {
      anomalies.push({
        nodeId: node.id,
        nodeName: v.node,
        kind: "MemoryLeakSuspect",
        detail: `${v.dynamic_shape.memoryFootprint} memory footprint on ${v.dynamic_shape.callFrequency.toLowerCase()} call frequency — growth risk.`,
      });
    }
    // Type-does-not-match-behavior: docstring says "cache" but type doesn't reflect it
    if (
      v.semantic_doc.conceptTags.includes("Caching") &&
      !v.lsp_type.toLowerCase().includes("cache")
    ) {
      anomalies.push({
        nodeId: node.id,
        nodeName: v.node,
        kind: "TypeDoesNotMatchBehavior",
        detail: `Docs claim caching behavior but static type signature doesn't reflect it.`,
      });
    }
  }
  return anomalies;
}

// ------------------- Top-level entry point -------------------
export function buildMCU(
  project: ASTProject,
  telemetry: Map<string, TelemetryData>,
  blastRadiusScores: Map<string, number>
): MCUResult {
  const docs = extractDocs(project);
  const vectors = buildVirtualTypes(project, telemetry, docs, blastRadiusScores);
  const conceptLattice = buildConceptLattice(project, docs);
  const typeShapeLattice = buildTypeShapeLattice(vectors);
  const anomalies = detectAnomalies(project, vectors);

  const blastRadiusDistribution: Record<string, number> = {
    "Tier-0 Critical": 0,
    "Tier-1 High": 0,
    "Tier-2 Moderate": 0,
    "Tier-3 Low": 0,
  };
  for (const v of vectors) {
    blastRadiusDistribution[v.dynamic_shape.blastRadiusGrade]++;
  }

  return {
    vectors,
    conceptLattice,
    typeShapeLattice,
    blastRadiusDistribution,
    topContextualized: vectors.slice(0, 10),
    anomalies,
  };
}
