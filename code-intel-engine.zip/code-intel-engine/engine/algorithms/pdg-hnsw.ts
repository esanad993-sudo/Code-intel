// ============================================================
// Module 2: PDG-Structural Proximity Graph + HNSW
// ============================================================
// Build a Program Dependence Graph (PDG) from the AST.
// Hash structural features with Weisfeiler-Lehman graph isomorphism hashing.
// Index the resulting feature vectors in a simplified HNSW graph.

import { ASTNode, ASTProject } from "../ast/types";

// ------------------- PDG Construction -------------------

export interface PDGNode {
  id: string; // same as AST node id
  label: string; // e.g. "MethodDeclaration:authenticateUser"
  nodeType: string;
}

export interface PDGEdge {
  src: string;
  dst: string;
  type: "control" | "data" | "call" | "parent";
  weight: number;
}

export interface PDG {
  nodes: PDGNode[];
  edges: PDGEdge[];
  adjacency: Map<string, Array<{ dst: string; type: PDGEdge["type"]; weight: number }>>;
}

export function buildPDG(project: ASTProject): PDG {
  const nodes: PDGNode[] = [];
  const edges: PDGEdge[] = [];
  const adjacency = new Map<string, Array<{ dst: string; type: PDGEdge["type"]; weight: number }>>();

  for (const node of project.allNodes) {
    nodes.push({
      id: node.id,
      label: `${node.type}:${node.name}`,
      nodeType: node.type,
    });
    if (!adjacency.has(node.id)) adjacency.set(node.id, []);
  }

  // Parent-child edges (AST structure)
  for (const node of project.allNodes) {
    if (node.parentId) {
      edges.push({
        src: node.parentId,
        dst: node.id,
        type: "parent",
        weight: 1.0,
      });
      adjacency.get(node.parentId)!.push({ dst: node.id, type: "parent", weight: 1.0 });
      if (!adjacency.has(node.id)) adjacency.set(node.id, []);
      adjacency.get(node.id)!.push({ dst: node.parentId, type: "parent", weight: 1.0 });
    }
  }

  // Call edges from call graph
  for (const [callerId, calleeIds] of project.callGraph) {
    for (const calleeId of calleeIds) {
      edges.push({
        src: callerId,
        dst: calleeId,
        type: "call",
        weight: 2.0,
      });
      adjacency.get(callerId)!.push({ dst: calleeId, type: "call", weight: 2.0 });
      if (!adjacency.has(calleeId)) adjacency.set(calleeId, []);
      adjacency.get(calleeId)!.push({ dst: callerId, type: "call", weight: 2.0 });
    }
  }

  // Data-flow edges from data flow graph
  for (const [srcId, dstIds] of project.dataFlowGraph) {
    for (const dstId of dstIds) {
      edges.push({
        src: srcId,
        dst: dstId,
        type: "data",
        weight: 1.5,
      });
      adjacency.get(srcId)!.push({ dst: dstId, type: "data", weight: 1.5 });
      if (!adjacency.has(dstId)) adjacency.set(dstId, []);
      adjacency.get(dstId)!.push({ dst: srcId, type: "data", weight: 1.5 });
    }
  }

  // Control-flow edges: within a function, sequential statements
  for (const node of project.allNodes) {
    if (
      node.type !== "FunctionDeclaration" &&
      node.type !== "MethodDeclaration" &&
      node.type !== "ConstructorDeclaration"
    ) {
      continue;
    }
    // Connect children in sequence
    const children = node.childIds
      .map((id) => project.nodesById.get(id)!)
      .filter((n) => n);
    for (let i = 0; i < children.length - 1; i++) {
      const a = children[i];
      const b = children[i + 1];
      edges.push({ src: a.id, dst: b.id, type: "control", weight: 0.8 });
      adjacency.get(a.id)!.push({ dst: b.id, type: "control", weight: 0.8 });
      adjacency.get(b.id)!.push({ dst: a.id, type: "control", weight: 0.8 });
    }
  }

  return { nodes, edges, adjacency };
}

// ------------------- Weisfeiler-Lehman Hashing -------------------

// WL hashing: iteratively refine each node's label by hashing its
// neighborhood multiset. Produces a fixed-length feature vector
// where each dimension counts how many nodes have a given WL label
// at iteration k. This vector encodes structural patterns and is
// invariant to graph isomorphism.

export function hashString(s: string): number {
  // FNV-1a hash
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export interface WLHashResult {
  // Per-node label history
  nodeLabels: Map<string, string[]>;
  // Per-iteration label -> count vector
  histograms: Map<string, number>[];
  // Final feature vector (concatenated histograms)
  featureVector: number[];
  // Vocabulary: label -> dimension index
  vocab: Map<string, number>;
}

export function weisfeilerLehmanHash(pdg: PDG, iterations: number = 3): WLHashResult {
  // Initialize labels with node type
  const currentLabels = new Map<string, string>();
  const nodeLabels = new Map<string, string[]>();
  for (const node of pdg.nodes) {
    currentLabels.set(node.id, node.nodeType);
    nodeLabels.set(node.id, [node.nodeType]);
  }

  const histograms: Map<string, number>[] = [];
  const vocab = new Map<string, number>();

  // Initial histogram
  const h0 = new Map<string, number>();
  for (const node of pdg.nodes) {
    const lbl = currentLabels.get(node.id)!;
    h0.set(lbl, (h0.get(lbl) || 0) + 1);
    if (!vocab.has(lbl)) vocab.set(lbl, vocab.size);
  }
  histograms.push(h0);

  // Iterative refinement
  for (let iter = 0; iter < iterations; iter++) {
    const newLabels = new Map<string, string>();
    const histogram = new Map<string, number>();

    for (const node of pdg.nodes) {
      const neighbors = pdg.adjacency.get(node.id) || [];
      // Collect neighbor labels with edge types — sort for determinism
      const neighborLabels = neighbors
        .map((e) => {
          const neighborLabel = currentLabels.get(e.dst) || "?";
          return `${e.type}:${neighborLabel}`;
        })
        .sort();
      const concatenated = `${currentLabels.get(node.id)}|${neighborLabels.join(",")}`;
      const hashed = `H${hashString(concatenated).toString(16)}`;
      newLabels.set(node.id, hashed);
      nodeLabels.get(node.id)!.push(hashed);
      histogram.set(hashed, (histogram.get(hashed) || 0) + 1);
      if (!vocab.has(hashed)) vocab.set(hashed, vocab.size);
    }

    currentLabels.clear();
    for (const [id, lbl] of newLabels) currentLabels.set(id, lbl);
    histograms.push(histogram);
  }

  // Build feature vector: dim = vocab size, value = count across all iterations
  const featureVector = new Array(vocab.size).fill(0);
  for (const hist of histograms) {
    for (const [label, count] of hist) {
      const dim = vocab.get(label)!;
      featureVector[dim] += count;
    }
  }

  return { nodeLabels, histograms, featureVector, vocab };
}

// Compute a per-node feature vector: histogram of WL labels in the
// node's K-hop neighborhood. This is the vector we index with HNSW.
export function computeNodeFeatures(pdg: PDG, wl: WLHashResult): Map<string, number[]> {
  const features = new Map<string, number[]>();
  const dim = wl.vocab.size;
  for (const node of pdg.nodes) {
    const vec = new Array(dim).fill(0);
    // Walk 2 hops out, accumulating neighbor WL labels
    const visited = new Set<string>([node.id]);
    const frontier = [node.id];
    for (let hop = 0; hop < 2; hop++) {
      const next: string[] = [];
      for (const src of frontier) {
        const neighbors = pdg.adjacency.get(src) || [];
        for (const e of neighbors) {
          if (visited.has(e.dst)) continue;
          visited.add(e.dst);
          next.push(e.dst);
          const labels = wl.nodeLabels.get(e.dst) || [];
          for (const lbl of labels) {
            const d = wl.vocab.get(lbl);
            if (d !== undefined) vec[d]++;
          }
        }
      }
      frontier.length = 0;
      frontier.push(...next);
    }
    features.set(node.id, vec);
  }
  return features;
}

// ------------------- HNSW (Simplified) -------------------
// We implement a simplified Hierarchical Navigable Small World graph.
// Not as fast as production HNSW but follows the same algorithm:
// multi-layer skip-list-like structure with greedy beam search.

export interface HNSWNode {
  id: string;
  vector: number[];
  level: number;
  neighbors: number[][]; // layer -> neighbor indices
}

export interface HNSWIndex {
  nodes: HNSWNode[];
  entryPointId: string | null;
  maxLayer: number;
  M: number; // max neighbors per layer
  efConstruction: number;
  mL: number; // level generation factor
}

function cosineSim(a: number[], b: number[]): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

// HNSW level assignment uses a seeded PRNG (mulberry32) for determinism.
// "Deterministic given a fixed seed" — not "fully deterministic" in the
// mathematical sense.
//
// *** FORMAT VERSION WARNING ***
// Changing this seed changes the HNSW graph structure, which changes:
//   - Neighbor lists for every node
//   - Approximate kNN query results
//   - Any downstream query that used HNSW candidates
// Treat this seed as part of the index format version. If you change it,
// you MUST invalidate all cached engines (clear .engine-cache/).
// Otherwise, stale caches will have results from the old HNSW structure.
//
// NOTE: HNSW is future-proofing for 10k+ node repos. At 178 nodes, the
// engine uses linear scan for structural similarity queries (the HNSW
// is built but hnswSearch is only called when the isomorphism module
// needs kNN, which currently goes through the WL hash inverted index
// instead). HNSW becomes the hot path when node count exceeds ~1000.
const HNSW_SEED: number = 0x6b8b4567; // DO NOT CHANGE without invalidating caches
let _prngState = HNSW_SEED;
function seededRandom(): number {
  // mulberry32 PRNG
  _prngState |= 0;
  _prngState = (_prngState + 0x6D2B79F5) | 0;
  let t = Math.imul(_prngState ^ (_prngState >>> 15), 1 | _prngState);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function randomLevel(mL: number): number {
  // -ln(uniform()) * mL — using seeded PRNG for determinism
  const u = seededRandom();
  return Math.floor(-Math.log(u + 1e-12) * mL);
}

export function buildHNSW(
  ids: string[],
  vectors: Map<string, number[]>,
  M: number = 16,
  efConstruction: number = 200
): HNSWIndex {
  // Reset PRNG to fixed seed at the start of each build — ensures
  // the same input always produces the same HNSW structure.
  _prngState = HNSW_SEED;

  const index: HNSWIndex = {
    nodes: [],
    entryPointId: null,
    maxLayer: -1,
    M,
    efConstruction,
    mL: 1 / Math.log(M),
  };

  if (ids.length === 0) return index;

  for (const id of ids) {
    const vec = vectors.get(id)!;
    const level = randomLevel(index.mL);
    const node: HNSWNode = {
      id,
      vector: vec,
      level,
      neighbors: Array.from({ length: level + 1 }, () => []),
    };
    index.nodes.push(node);

    if (index.entryPointId === null) {
      index.entryPointId = id;
      index.maxLayer = level;
      continue;
    }

    // Insert: search down layers
    const entryIdx = index.nodes.findIndex((n) => n.id === index.entryPointId)!;
    let entryNode = index.nodes[entryIdx];

    // Greedy search from top down to level+1
    for (let layer = index.maxLayer; layer > level; layer--) {
      const result = greedySearch(index, entryNode, vec, layer, 1);
      if (result.length > 0) {
        entryNode = index.nodes[result[0]];
      }
    }

    // Insert at each layer from min(level, maxLayer) down to 0
    for (let layer = Math.min(level, index.maxLayer); layer >= 0; layer--) {
      const candidates = greedySearch(index, entryNode, vec, layer, efConstruction);
      const neighbors = selectNeighbors(vec, candidates, M, index.nodes);
      for (const nbIdx of neighbors) {
        index.nodes[index.nodes.length - 1].neighbors[layer].push(nbIdx);
        // Bidirectional link
        const nbNode = index.nodes[nbIdx];
        if (nbNode.neighbors[layer]) {
          nbNode.neighbors[layer].push(index.nodes.length - 1);
          // Prune
          if (nbNode.neighbors[layer].length > M) {
            const nbVec = nbNode.vector;
            const pruned = selectNeighbors(nbVec, nbNode.neighbors[layer], M, index.nodes);
            nbNode.neighbors[layer] = pruned;
          }
        }
      }
    }

    if (level > index.maxLayer) {
      index.maxLayer = level;
      index.entryPointId = id;
    }
  }

  return index;
}

function greedySearch(
  index: HNSWIndex,
  entry: HNSWNode,
  query: number[],
  layer: number,
  ef: number
): number[] {
  const visited = new Set<number>([index.nodes.indexOf(entry)]);
  const candidates: Array<{ idx: number; dist: number }> = [
    { idx: index.nodes.indexOf(entry), dist: 1 - cosineSim(entry.vector, query) },
  ];
  const results: Array<{ idx: number; dist: number }> = [...candidates];

  while (candidates.length > 0) {
    candidates.sort((a, b) => a.dist - b.dist);
    const closest = candidates.shift()!;
    const node = index.nodes[closest.idx];
    const neighborIndices = node.neighbors[layer] || [];
    for (const nbIdx of neighborIndices) {
      if (visited.has(nbIdx)) continue;
      visited.add(nbIdx);
      const nbNode = index.nodes[nbIdx];
      const d = 1 - cosineSim(nbNode.vector, query);
      if (results.length < ef || d < results[results.length - 1].dist) {
        candidates.push({ idx: nbIdx, dist: d });
        results.push({ idx: nbIdx, dist: d });
        results.sort((a, b) => a.dist - b.dist);
        if (results.length > ef) results.length = ef;
      }
    }
  }

  results.sort((a, b) => a.dist - b.dist);
  return results.map((r) => r.idx);
}

function selectNeighbors(
  query: number[],
  candidates: number[],
  M: number,
  nodes: HNSWNode[]
): number[] {
  // Simple heuristic: pick M nearest by cosine distance
  const scored = candidates.map((idx) => ({
    idx,
    dist: 1 - cosineSim(query, nodes[idx].vector),
  }));
  scored.sort((a, b) => a.dist - b.dist);
  return scored.slice(0, M).map((s) => s.idx);
}

export function hnswSearch(
  index: HNSWIndex,
  query: number[],
  k: number,
  ef: number = 50
): Array<{ id: string; score: number }> {
  if (index.entryPointId === null) return [];
  const entryIdx = index.nodes.findIndex((n) => n.id === index.entryPointId)!;
  let entryNode = index.nodes[entryIdx];

  for (let layer = index.maxLayer; layer > 0; layer--) {
    const result = greedySearch(index, entryNode, query, layer, 1);
    if (result.length > 0) entryNode = index.nodes[result[0]];
  }
  const results = greedySearch(index, entryNode, query, 0, Math.max(ef, k));
  return results.slice(0, k).map((idx) => ({
    id: index.nodes[idx].id,
    score: 1 - (1 - cosineSim(index.nodes[idx].vector, query)), // similarity = 1 - dist
  }));
}

// ------------------- Combined PDG-HNSW Pipeline -------------------

export interface PDGHNSWResult {
  pdg: PDG;
  wl: WLHashResult;
  features: Map<string, number[]>;
  hnsw: HNSWIndex;
  // Pre-computed similarity examples for the UI
  sampleQueries: Array<{ queryNodeId: string; results: Array<{ id: string; score: number }> }>;
}

export function buildPDGHNSW(project: ASTProject): PDGHNSWResult {
  const pdg = buildPDG(project);
  const wl = weisfeilerLehmanHash(pdg, 3);
  const features = computeNodeFeatures(pdg, wl);
  const ids = pdg.nodes.map((n) => n.id);
  const hnsw = buildHNSW(ids, features, 8, 100);

  // Generate sample queries — pick 3 interesting nodes
  const interestingNodes = pdg.nodes
    .filter(
      (n) =>
        n.label.startsWith("MethodDeclaration:") ||
        n.label.startsWith("FunctionDeclaration:")
    )
    .slice(0, 3);

  const sampleQueries = interestingNodes.map((n) => {
    const vec = features.get(n.id)!;
    const results = hnswSearch(hnsw, vec, 5, 20).filter((r) => r.id !== n.id);
    return { queryNodeId: n.id, results };
  });

  return { pdg, wl, features, hnsw, sampleQueries };
}
