// ============================================================
// Algorithmic Synonym Resolver — Code-Native, No Embeddings
// ============================================================
//
// The problem: BM25 tokenizes "authenticateUser" → ["authenticate", "user"].
// A search for "auth" or "login" doesn't match because there's no exact
// token overlap.
//
// The wrong solution: dense embeddings (heavy, non-deterministic, hallucinate).
//
// The right solution: code synonyms follow 4 patterns. Resolve them with
// deterministic rules. Zero ML, zero hallucination, sub-millisecond.
//
//   1. Morphological:    "authenticate" ↔ "authentication" ↔ "authenticating"
//   2. Abbreviation:     "auth" ↔ "authenticate", "db" ↔ "database"
//   3. Domain lexicon:   "login" ↔ "signin" ↔ "authenticate" (CS-curated)
//   4. Concept binding:  piggyback on Module 7's conceptTags
//                        ("verifyCredential" has concept Authentication → matches "auth")
//
// All four are deterministic, fully inspectable, and produce NO false positives
// that weren't explicitly encoded.

// ------------------- Morphological stemmer -------------------
// Porter-style lightweight stemmer. Handles -ing, -ed, -s, -tion, -ation,
// -er, -or, -ize, -ise, -ment, -ness, -ity, -ies, -ied, -y.
// Not as aggressive as Snowball — we want to keep meaning intact.

export function stem(word: string): string {
  const w = word.toLowerCase();
  if (w.length <= 3) return w;

  // Order matters: longest suffixes first
  const suffixes: Array<[RegExp, string | ((w: string) => string)]> = [
    // -ation → -ate  (authentication → authenticate)
    [/^(.+)ation$/, "$1ate"],
    // -ition → -it   (composition → compose-ish; loose)
    [/^(.+)ition$/, "$1it"],
    // -tion → -t     (creation → create-ish; loose, but keeps stem)
    [/^(.+)tion$/, "$1t"],
    // -ing → ""      (authenticating → authenticate)
    [/^(.+)([^aeiou])ing$/, "$1$2e"],
    [/^(.+)ing$/, "$1"],
    // -ed → ""       (authenticated → authenticate)
    [/^(.+)([^aeiou])ed$/, "$1$2e"],
    [/^(.+)ed$/, "$1"],
    // -ies → -y      (copies → copy)
    [/^(.+)ies$/, "$1y"],
    // -ied → -y      (verified → verify)
    [/^(.+)ied$/, "$1y"],
    // -es → ""       (boxes → box)
    [/^(.+[sxz])es$/, "$1"],
    [/^(.+)es$/, "$1e"],
    // -s → ""        (cats → cat) — but NOT 3-letter words like "is"
    [/^(.+[b-df-hj-np-tv-z])s$/, "$1"],
    // -er → ""       (logger → log)
    [/^(.+)er$/, "$1"],
    // -or → ""       (executor → execute)
    [/^(.+)or$/, "$1"],
    // -ize → ""      (sanitize → sani)
    [/^(.+)ize$/, "$1"],
    // -ise → ""      (British variant)
    [/^(.+)ise$/, "$1"],
    // -ment → ""     (deployment → deploy)
    [/^(.+)ment$/, "$1"],
    // -ness → ""     (darkness → dark)
    [/^(.+)ness$/, "$1"],
    // -ity → ""      (priority → prior)
    [/^(.+)ity$/, "$1"],
    // -al → ""       (refusal → refuse-ish; loose)
    [/^(.+[^aeiou])al$/, "$1"],
    // -y → ""        (lazy → laz; loose, keep meaning by using length check)
    // skip this one — too aggressive
  ];

  for (const [re, repl] of suffixes) {
    const m = w.match(re);
    if (m && m[1].length >= 3) {
      return typeof repl === "string" ? w.replace(re, repl) : repl(w);
    }
  }
  return w;
}

// ------------------- Abbreviation lexicon -------------------
// Curated list of common programming abbreviations.
// Two-way: "auth" → "authenticate", "authenticate" → "auth".
// Pull requests welcome to extend this list — it's the "training data"
// that's actually inspectable.

const ABBREV: Record<string, string[]> = {
  auth: ["authenticate", "authentication", "authorize", "authorization", "authority"],
  cred: ["credential", "credentials"],
  db: ["database", "databases"],
  cfg: ["config", "configuration"],
  config: ["configuration"],
  repo: ["repository"],
  req: ["request"],
  res: ["response", "resource"],
  resp: ["response"],
  err: ["error", "errors"],
  exc: ["exception"],
  ctx: ["context"],
  info: ["information"],
  init: ["initialize", "initialise", "init"],
  dest: ["destination"],
  src: ["source"],
  dst: ["destination"],
  tmp: ["temp", "temporary"],
  temp: ["temporary"],
  usr: ["user"],
  pwd: ["password"],
  passwd: ["password"],
  fn: ["function"],
  args: ["arguments"],
  params: ["parameters"],
  param: ["parameter"],
  ret: ["return"],
  val: ["value", "validate", "valid"],
  valid: ["validate", "validation"],
  verif: ["verify", "verification"],
  confirm: ["confirmation"],
  reg: ["register", "registration"],
  regen: ["regenerate"],
  gen: ["generate", "generator"],
  util: ["utility", "utilities"],
  lib: ["library"],
  pkg: ["package"],
  mod: ["module", "modifier"],
  mgr: ["manager"],
  ctrl: ["controller"],
  svc: ["service"],
  srv: ["server"],
  cli: ["client"],
  api: ["application_programming_interface"],
  html: ["hypertext_markup_language"],
  url: ["uniform_resource_locator"],
  uri: ["uniform_resource_identifier"],
  uuid: ["universally_unique_identifier"],
  jwt: ["json_web_token"],
  ssl: ["secure_sockets_layer"],
  tls: ["transport_layer_security"],
  http: ["hypertext_transfer_protocol"],
  rpc: ["remote_procedure_call"],
  crud: ["create_read_update_delete"],
  dto: ["data_transfer_object"],
  dao: ["data_access_object"],
  orm: ["object_relational_mapping"],
  // NEW: log → login, logger, logging
  // This fixes the "logs in" → "login" gap where "logs" stems to "log"
  // which matches the Logging synonym group instead of the Authentication group.
  log: ["login", "logger", "logging", "logout"],
};

// Build the reverse lookup: full word → list of abbreviations
const FULL_TO_ABBREV: Record<string, string[]> = {};
for (const [abbr, fulls] of Object.entries(ABBREV)) {
  for (const full of fulls) {
    if (!FULL_TO_ABBREV[full]) FULL_TO_ABBREV[full] = [];
    if (!FULL_TO_ABBREV[full].includes(abbr)) FULL_TO_ABBREV[full].push(abbr);
  }
}

// ------------------- Domain synonym lexicon -------------------
// Curated synonym groups for CS / web / database / security domains.
// Each group is a set of words that mean the same thing in code.
// Adding a word here is exactly equivalent to "training the model" —
// except you can read it, review it, and bisect it.

const SYNONYM_GROUPS: string[][] = [
  // Authentication
  ["authenticate", "login", "signin", "logon", "log_in", "sign_in"],
  ["logout", "signout", "signoff", "log_out", "sign_off"],
  ["register", "signup", "sign_up", "enroll"],
  // Authorization
  ["authorize", "permit", "allow", "grant"],
  ["forbid", "deny", "reject", "block", "prohibit"],
  // Validation
  ["validate", "verify", "check", "assert", "ensure"],
  ["sanitize", "clean", "purify", "escape"],
  // Database
  ["query", "fetch", "lookup", "find", "search", "select"],
  ["insert", "create", "add", "store", "persist"],
  ["update", "modify", "patch", "change", "mutate"],
  ["delete", "remove", "drop", "destroy", "purge"],
  // Caching
  ["cache", "memoize", "remember"],
  ["invalidate", "evict", "expire", "clear"],
  // Logging
  ["log", "trace", "record", "emit"],
  ["debug", "inspect", "examine"],
  // HTTP
  ["request", "req", "incoming"],
  ["response", "res", "reply", "outgoing"],
  ["route", "endpoint", "handler", "path"],
  ["get", "fetch", "retrieve"],
  ["post", "submit", "create"],
  // Concurrency
  ["lock", "acquire", "claim"],
  ["unlock", "release", "free"],
  ["async", "asynchronous"],
  ["await", "yield", "suspend"],
  // Crypto
  ["hash", "digest", "checksum"],
  ["encrypt", "encode", "cipher"],
  ["decrypt", "decode", "decipher"],
  ["sign", "seal"],
  // Email
  ["email", "mail", "message"],
  ["send", "dispatch", "deliver", "transmit"],
  // Users
  ["user", "account", "principal", "subject"],
  ["admin", "administrator", "root", "superuser"],
  // Misc utilities
  ["format", "stringify", "serialize"],
  ["parse", "deserialize", "decode"],
  ["render", "draw", "paint"],
  ["emit", "fire", "trigger", "dispatch"],
];

// Build bidirectional lookup: word → list of synonyms (including itself)
const SYNONYM_MAP: Record<string, string[]> = {};
for (const group of SYNONYM_GROUPS) {
  for (const word of group) {
    if (!SYNONYM_MAP[word]) SYNONYM_MAP[word] = [];
    for (const other of group) {
      if (other !== word && !SYNONYM_MAP[word].includes(other)) {
        SYNONYM_MAP[word].push(other);
      }
    }
  }
}

// ------------------- Public API -------------------

export interface SynonymExpansion {
  original: string;
  expansions: string[];
  sources: string[]; // which pattern produced each expansion
}

// Expand a single token into all its synonyms.
export function expandToken(token: string): SynonymExpansion {
  const lower = token.toLowerCase();
  const expansions = new Set<string>();
  const sources: string[] = [];

  // 1. Morphological: stem both directions
  const stemmed = stem(lower);
  if (stemmed !== lower) {
    expansions.add(stemmed);
    sources.push("stem");
  }

  // 2. Abbreviation: "auth" → ["authenticate", ...], "database" → ["db"]
  // Check both the original token AND the stemmed form.
  // This fixes: "logs" → stem "log" → ABBREV["log"] → ["login", "logger", ...]
  if (ABBREV[lower]) {
    for (const full of ABBREV[lower]) {
      expansions.add(full);
      sources.push("abbrev");
    }
  }
  if (stemmed !== lower && ABBREV[stemmed]) {
    for (const full of ABBREV[stemmed]) {
      expansions.add(full);
      sources.push("abbrev(stemmed)");
    }
  }
  if (FULL_TO_ABBREV[lower]) {
    for (const abbr of FULL_TO_ABBREV[lower]) {
      expansions.add(abbr);
      sources.push("abbrev");
    }
  }

  // 3. Domain lexicon: "login" → ["authenticate", "signin", ...]
  if (SYNONYM_MAP[lower]) {
    for (const syn of SYNONYM_MAP[lower]) {
      expansions.add(syn);
      sources.push("synonym");
    }
  }

  // 4. Stemmed-then-lookup (e.g., "authenticating" → stem "authenticate" → syns)
  if (stemmed !== lower && SYNONYM_MAP[stemmed]) {
    for (const syn of SYNONYM_MAP[stemmed]) {
      expansions.add(syn);
      sources.push("synonym(stemmed)");
    }
  }

  return {
    original: token,
    expansions: Array.from(expansions),
    sources: Array.from(new Set(sources)),
  };
}

// Expand an entire query string. Returns a flat set of all tokens to search.
export function expandQuery(query: string): {
  originalTokens: string[];
  expandedTokens: string[];
  expansionLog: SynonymExpansion[];
} {
  // Reuse the BM25 tokenizer: split camelCase + snake_case + spaces
  const tokens = query
    .split(/(?=[A-Z])|[_\s\-]+/)
    .filter((t) => t.length > 0)
    .map((t) => t.toLowerCase());

  const expanded = new Set<string>(tokens);
  const log: SynonymExpansion[] = [];

  for (const token of tokens) {
    const expansion = expandToken(token);
    if (expansion.expansions.length > 0) {
      log.push(expansion);
      for (const e of expansion.expansions) expanded.add(e);
      // Also stem the original (so "authenticating" matches "authenticate")
      const stemmed = stem(token);
      if (stemmed !== token) expanded.add(stemmed);
    }
  }

  return {
    originalTokens: tokens,
    expandedTokens: Array.from(expanded),
    expansionLog: log,
  };
}

// Stats for the UI
export function synonymStats() {
  return {
    abbreviationPairs: Object.keys(ABBREV).length,
    synonymGroups: SYNONYM_GROUPS.length,
    totalSynonymEntries: Object.keys(SYNONYM_MAP).length,
    morphologicalRulesActive: true,
    backend: "algorithmic",
    deterministic: true,
    mlUsed: false,
  };
}
