// Lightweight TypeScript-like parser.
// Goal: produce an AST sufficient for code-native search and analysis.
// NOT a full TS compiler — handles the patterns in our sample codebase.

import {
  ASTNode,
  ASTNodeType,
  ASTDocument,
  DecoratorInfo,
} from "./types";

// ============================================================
// Tokenizer
// ============================================================

type TokenType =
  | "ident"
  | "keyword"
  | "string"
  | "comment"
  | "decorator"
  | "lbrace"
  | "rbrace"
  | "lparen"
  | "rparen"
  | "lbracket"
  | "rbracket"
  | "semicolon"
  | "comma"
  | "dot"
  | "colon"
  | "arrow"
  | "at"
  | "op"
  | "newline"
  | "eof";

interface Token {
  type: TokenType;
  value: string;
  line: number;
  col: number;
}

const KEYWORDS = new Set([
  "import",
  "from",
  "export",
  "default",
  "class",
  "interface",
  "extends",
  "implements",
  "function",
  "const",
  "let",
  "var",
  "async",
  "await",
  "return",
  "if",
  "else",
  "for",
  "while",
  "do",
  "try",
  "catch",
  "finally",
  "throw",
  "new",
  "this",
  "super",
  "public",
  "private",
  "protected",
  "static",
  "readonly",
  "abstract",
  "get",
  "set",
  "type",
  "enum",
  "namespace",
  "module",
  "void",
  "null",
  "undefined",
  "true",
  "false",
  "as",
  "instanceof",
  "typeof",
  "in",
  "of",
  // Multi-language support — Python/Rust/Go keywords recognized as keywords
  // so the parser can do basic structural extraction on non-TS files.
  "def",        // Python function
  "fn",         // Rust function
  "func",       // Go function
  "pub",        // Rust visibility
  "struct",     // Rust/Go struct
  "impl",       // Rust impl block
  "use",        // Rust use declaration
  "let",        // Rust let binding
  "mut",        // Rust mutable
  "package",    // Go package
  "func",       // Go func
  "type",       // Go type
  "struct",     // Go struct
  "pass",       // Python block terminator
  "elif",       // Python
  "lambda",     // Python
  "with",       // Python
  "yield",      // Python
  "global",     // Python
  "nonlocal",   // Python
  "assert",     // Python
  "raise",      // Python
  "except",     // Python
  "finally",    // Python
  "lambda",     // Python
  "None",       // Python
  "True",       // Python
  "False",      // Python
  "self",       // Python
  "cls",        // Python
]);

function tokenize(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  let line = 1;
  let col = 1;
  const push = (t: Token) => tokens.push(t);

  const advance = (n: number) => {
    for (let k = 0; k < n; k++) {
      if (src[i + k] === "\n") {
        line++;
        col = 1;
      } else {
        col++;
      }
    }
    i += n;
  };

  while (i < src.length) {
    const ch = src[i];
    const startLine = line;
    const startCol = col;

    // Newlines
    if (ch === "\n") {
      advance(1);
      continue;
    }
    // Whitespace
    if (ch === " " || ch === "\t" || ch === "\r") {
      advance(1);
      continue;
    }
    // Line comment
    if (ch === "/" && src[i + 1] === "/") {
      let end = i + 2;
      while (end < src.length && src[end] !== "\n") end++;
      push({
        type: "comment",
        value: src.slice(i, end),
        line: startLine,
        col: startCol,
      });
      advance(end - i);
      continue;
    }
    // Block comment
    if (ch === "/" && src[i + 1] === "*") {
      let end = i + 2;
      while (end < src.length - 1 && !(src[end] === "*" && src[end + 1] === "/"))
        end++;
      end += 2;
      push({
        type: "comment",
        value: src.slice(i, end),
        line: startLine,
        col: startCol,
      });
      advance(end - i);
      continue;
    }
    // String literals (single, double, backtick)
    if (ch === '"' || ch === "'" || ch === "`") {
      const quote = ch;
      let end = i + 1;
      while (end < src.length) {
        if (src[end] === "\\") {
          end += 2;
          continue;
        }
        if (src[end] === quote) {
          end++;
          break;
        }
        if (quote !== "`" && src[end] === "\n") break;
        end++;
      }
      push({
        type: "string",
        value: src.slice(i, end),
        line: startLine,
        col: startCol,
      });
      advance(end - i);
      continue;
    }
    // Decorator (e.g. @route)
    if (ch === "@") {
      let end = i + 1;
      while (end < src.length && /[A-Za-z0-9_]/.test(src[end])) end++;
      push({
        type: "decorator",
        value: src.slice(i, end),
        line: startLine,
        col: startCol,
      });
      advance(end - i);
      continue;
    }
    // Identifiers / keywords
    if (/[A-Za-z_$]/.test(ch)) {
      let end = i + 1;
      while (end < src.length && /[A-Za-z0-9_$]/.test(src[end])) end++;
      const word = src.slice(i, end);
      push({
        type: KEYWORDS.has(word) ? "keyword" : "ident",
        value: word,
        line: startLine,
        col: startCol,
      });
      advance(end - i);
      continue;
    }
    // Numbers
    if (/[0-9]/.test(ch)) {
      let end = i + 1;
      while (end < src.length && /[0-9._eExXa-fA-F]/.test(src[end])) end++;
      push({
        type: "ident",
        value: src.slice(i, end),
        line: startLine,
        col: startCol,
      });
      advance(end - i);
      continue;
    }
    // Punctuation
    if (ch === "{") {
      push({ type: "lbrace", value: "{", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === "}") {
      push({ type: "rbrace", value: "}", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === "(") {
      push({ type: "lparen", value: "(", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === ")") {
      push({ type: "rparen", value: ")", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === "[") {
      push({ type: "lbracket", value: "[", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === "]") {
      push({ type: "rbracket", value: "]", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === ";") {
      push({ type: "semicolon", value: ";", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === ",") {
      push({ type: "comma", value: ",", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === ".") {
      // Check for spread operator "..." (rest parameters)
      if (src[i + 1] === "." && src[i + 2] === ".") {
        push({ type: "dot", value: "...", line: startLine, col: startCol });
        advance(3);
        continue;
      }
      push({ type: "dot", value: ".", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    if (ch === ":") {
      push({ type: "colon", value: ":", line: startLine, col: startCol });
      advance(1);
      continue;
    }
    // Arrow =>
    if (ch === "=" && src[i + 1] === ">") {
      push({ type: "arrow", value: "=>", line: startLine, col: startCol });
      advance(2);
      continue;
    }
    // Operators
    if (/[=+\-*/%<>!&|?]/.test(ch)) {
      let end = i + 1;
      while (end < src.length && /[=+\-*/%<>!&|?]/.test(src[end])) end++;
      push({ type: "op", value: src.slice(i, end), line: startLine, col: startCol });
      advance(end - i);
      continue;
    }
    // Unknown — skip
    advance(1);
  }
  push({ type: "eof", value: "", line, col });
  return tokens;
}

// ============================================================
// Parser
// ============================================================

interface ParseContext {
  tokens: Token[];
  pos: number;
  filePath: string;
  moduleId: string;
  nodes: ASTNode[];
  scopeStack: string[];
  parentIdStack: (string | null)[];
  idCounter: number;
}

function nextId(ctx: ParseContext): string {
  return `${ctx.moduleId}#n${ctx.idCounter++}`;
}

function peek(ctx: ParseContext): Token {
  return ctx.tokens[ctx.pos];
}

function peekAhead(ctx: ParseContext, n: number): Token {
  return ctx.tokens[Math.min(ctx.pos + n, ctx.tokens.length - 1)];
}

function advance(ctx: ParseContext): Token {
  return ctx.tokens[ctx.pos++];
}

function expect(ctx: ParseContext, type: TokenType): Token {
  const t = peek(ctx);
  if (t.type !== type) {
    throw new Error(
      `Parse error at ${ctx.filePath}:${t.line}:${t.col}: expected ${type} but got ${t.type} '${t.value}'`
    );
  }
  return advance(ctx);
}

function skipCommentsAndDecorators(ctx: ParseContext): DecoratorInfo[] {
  const decorators: DecoratorInfo[] = [];
  while (true) {
    const t = peek(ctx);
    if (t.type === "comment") {
      advance(ctx);
      continue;
    }
    if (t.type === "decorator") {
      const tok = advance(ctx);
      const name = tok.value; // includes leading @
      const args: string[] = [];
      // Optional parenthesized args
      if (peek(ctx).type === "lparen") {
        advance(ctx); // (
        let depth = 1;
        while (depth > 0 && peek(ctx).type !== "eof") {
          const t2 = peek(ctx);
          if (t2.type === "lparen") depth++;
          else if (t2.type === "rparen") {
            depth--;
            if (depth === 0) {
              advance(ctx);
              break;
            }
          } else if (t2.type === "string" || t2.type === "ident") {
            args.push(t2.value.replace(/^["'`]|["'`]$/g, ""));
          }
          advance(ctx);
        }
      }
      decorators.push({ name, args });
      continue;
    }
    break;
  }
  return decorators;
}

function skipUntilMatching(ctx: ParseContext, open: TokenType, close: TokenType) {
  const t = peek(ctx);
  if (t.type !== open) return;
  advance(ctx);
  let depth = 1;
  while (depth > 0 && peek(ctx).type !== "eof") {
    const t2 = advance(ctx);
    if (t2.type === open) depth++;
    else if (t2.type === close) depth--;
  }
}

function collectReferencesInBlock(ctx: ParseContext): string[] {
  // Walk forward collecting identifier tokens that look like references,
  // until we hit a brace that closes the current scope.
  // This is heuristic — we approximate "references inside a block".
  const refs: string[] = [];
  let depth = 1;
  // We assume the opening brace has already been consumed.
  while (depth > 0 && peek(ctx).type !== "eof") {
    const t = peek(ctx);
    if (t.type === "lbrace") {
      depth++;
      advance(ctx);
      continue;
    }
    if (t.type === "rbrace") {
      depth--;
      advance(ctx);
      if (depth === 0) break;
      continue;
    }
    if (t.type === "comment" || t.type === "string") {
      advance(ctx);
      continue;
    }
    // Capture references: identifier followed by `(` => call target
    if (t.type === "ident") {
      // Skip if it's a property after a dot (member access — handle separately)
      const prev = ctx.pos > 0 ? ctx.tokens[ctx.pos - 1] : null;
      const next = peekAhead(ctx, 1);
      if (next.type === "lparen") {
        // call expression
        refs.push(`call:${t.value}`);
      } else if (prev && prev.type === "dot") {
        refs.push(`member:${t.value}`);
      } else {
        refs.push(`ident:${t.value}`);
      }
    }
    advance(ctx);
  }
  return refs;
}

function createNode(
  ctx: ParseContext,
  type: ASTNodeType,
  name: string,
  startLine: number,
  decorators: DecoratorInfo[]
): ASTNode {
  const id = nextId(ctx);
  const parentId = ctx.parentIdStack[ctx.parentIdStack.length - 1] ?? null;
  const node: ASTNode = {
    id,
    type,
    name,
    filePath: ctx.filePath,
    startLine,
    endLine: startLine,
    scope: [...ctx.scopeStack],
    decorators,
    parentId,
    childIds: [],
    references: [],
    parameterTypes: [],
    returnType: null,
    isExported: false,
    isAsync: false,
    astDepth: ctx.scopeStack.length,
  };
  ctx.nodes.push(node);
  if (parentId) {
    const parent = ctx.nodes.find((n) => n.id === parentId);
    if (parent) parent.childIds.push(id);
  }
  return node;
}

function parseImport(ctx: ParseContext) {
  const startLine = peek(ctx).line;
  const importKw = peek(ctx).value; // 'import', 'from', 'use'
  let defaultName = "";
  let named: string[] = [];
  let source = "";

  // Python: `from typing import Optional`  OR  `import os`
  // Rust:   `use std::time::SystemTime;`
  // Go:     `import ("net/http", "strings")`
  // TS:     `import { User } from "../models/User"`
  if (importKw === "from") {
    // Python `from X import Y`
    advance(ctx); // 'from'
    // Module path: collect idents + dots until 'import'
    const modParts: string[] = [];
    while (peek(ctx).type !== "eof" && !(peek(ctx).type === "keyword" && peek(ctx).value === "import")) {
      if (peek(ctx).type === "ident") modParts.push(peek(ctx).value);
      advance(ctx);
    }
    source = modParts.join(".");
    // Skip 'import'
    if (peek(ctx).type === "keyword" && peek(ctx).value === "import") {
      advance(ctx);
    }
    // Collect names until end of line / EOF
    const importLine = peek(ctx).line;
    while (peek(ctx).type !== "eof" && peek(ctx).line === importLine) {
      if (peek(ctx).type === "ident") {
        named.push(peek(ctx).value);
      }
      advance(ctx);
    }
  } else if (importKw === "use") {
    // Rust `use std::time::SystemTime;`
    advance(ctx); // 'use'
    const parts: string[] = [];
    const useLine = peek(ctx).line;
    while (peek(ctx).type !== "eof" && peek(ctx).line === useLine && peek(ctx).type !== "semicolon") {
      if (peek(ctx).type === "ident") parts.push(peek(ctx).value);
      advance(ctx);
    }
    source = parts.join("::");
    if (peek(ctx).type === "semicolon") advance(ctx);
  } else {
    // TS `import { X } from "path"`  OR  Python `import os`
    advance(ctx); // 'import'
    // Check if this is Python `import os` or TS `import { X } from "path"`
    const importLine = peek(ctx).line;
    let foundFrom = false;
    while (peek(ctx).type !== "eof" && peek(ctx).line <= importLine + 5) {
      const t = peek(ctx);
      if (t.type === "keyword" && t.value === "from") {
        foundFrom = true;
        advance(ctx);
        break;
      }
      if (t.type === "ident") {
        if (peekAhead(ctx, 1).type === "ident" || peekAhead(ctx, 1).value === ",") {
          defaultName = t.value;
        } else {
          named.push(t.value);
        }
      }
      // Stop at end of line for Python-style `import os`
      if (peek(ctx).line > importLine && !foundFrom) {
        // We're on a new line and haven't found 'from' — this is Python import
        source = named.join(",") || defaultName;
        break;
      }
      advance(ctx);
    }
    if (foundFrom) {
      if (peek(ctx).type === "string") {
        source = peek(ctx).value.replace(/^["'`]|["'`]$/g, "");
        advance(ctx);
      }
      if (peek(ctx).type === "semicolon") advance(ctx);
    }
  }

  const node = createNode(
    ctx,
    "ImportDeclaration",
    source || defaultName || "anonymous",
    startLine,
    []
  );
  node.references = named.length > 0 ? named.map((n) => `import:${n}`) : [`import:${defaultName}`];
  node.endLine = peek(ctx).line;
}

function parseParameterList(ctx: ParseContext): { name: string; type: string }[] {
  // assumes current token is '('
  expect(ctx, "lparen");
  const params: { name: string; type: string }[] = [];
  while (peek(ctx).type !== "rparen" && peek(ctx).type !== "eof") {
    // Skip spread operator "..." (rest parameters)
    if (peek(ctx).type === "dot" && peek(ctx).value === "...") {
      advance(ctx);
    }
    const t = peek(ctx);
    if (t.type === "ident") {
      const name = t.value;
      advance(ctx);
      let type = "any";
      if (peek(ctx).type === "colon") {
        advance(ctx);
        // Read type tokens until , or )
        const typeParts: string[] = [];
        while (
          peek(ctx).type !== "comma" &&
          peek(ctx).type !== "rparen" &&
          peek(ctx).type !== "eof"
        ) {
          if (peek(ctx).type === "ident" || peek(ctx).type === "keyword") {
            typeParts.push(peek(ctx).value);
          } else if (peek(ctx).type === "dot") {
            typeParts.push(".");
          }
          advance(ctx);
        }
        type = typeParts.join("").replace(/\.+/g, ".");
      }
      params.push({ name, type });
      // Skip decorators on params
      skipCommentsAndDecorators(ctx);
    } else {
      advance(ctx);
    }
    if (peek(ctx).type === "comma") advance(ctx);
  }
  if (peek(ctx).type === "rparen") advance(ctx);
  return params;
}

function parseFunctionLike(
  ctx: ParseContext,
  type: ASTNodeType,
  name: string,
  decorators: DecoratorInfo[],
  isExported: boolean,
  isAsync: boolean,
  startLine: number
): ASTNode {
  const node = createNode(ctx, type, name, startLine, decorators);
  node.isExported = isExported;
  node.isAsync = isAsync;
  // Parse parameter list
  if (peek(ctx).type === "lparen") {
    const params = parseParameterList(ctx);
    node.parameterTypes = params.map((p) => `${p.name}:${p.type}`);
  }
  // Optional return type (TS: `: Type`, Python/Rust: `-> Type`)
  // For Python `def foo(...):` the `:` is the BODY start, not a return type.
  // Python return types use `->`. Rust return types also use `->`.
  // We detect the language by looking at what keyword started this function:
  //   def (Python) → `:` is body, `->` is return type
  //   fn (Rust)   → `->` is return type, `{` is body
  //   func (Go)   → no return type annotation, `{` is body
  //   function (TS) → `: Type` is return type, `{` is body
  if (peek(ctx).type === "colon") {
    // TypeScript-style return type: `: Type {`
    // Check if this looks like a return type (next token is a type name on same line)
    // FIX: accept both "ident" AND "keyword" (e.g. `void` is a keyword)
    const nextTok = peekAhead(ctx, 1);
    const currentLine = peek(ctx).line;
    const isTSReturnType =
      (nextTok.type === "ident" || nextTok.type === "keyword") && nextTok.line === currentLine;
    if (isTSReturnType) {
      advance(ctx); // ':'
      const typeParts: string[] = [];
      while (
        peek(ctx).type !== "lbrace" &&
        peek(ctx).type !== "semicolon" &&
        peek(ctx).type !== "eof" &&
        peek(ctx).type !== "colon"
      ) {
        if (peek(ctx).type === "ident" || peek(ctx).type === "keyword") {
          typeParts.push(peek(ctx).value);
        } else if (peek(ctx).type === "dot") {
          typeParts.push(".");
        }
        advance(ctx);
      }
      node.returnType = typeParts.join("").replace(/\.+/g, ".") || null;
    }
    // If not a TS return type, the `:` is a Python body start —
    // fall through to the body parser below.
  } else if (peek(ctx).type === "arrow") {
    // Python/Rust return type: `-> Type`
    advance(ctx); // '->' or '=>'
    const typeParts: string[] = [];
    while (
      peek(ctx).type !== "lbrace" &&
      peek(ctx).type !== "semicolon" &&
      peek(ctx).type !== "eof" &&
      peek(ctx).type !== "colon"
    ) {
      if (peek(ctx).type === "ident" || peek(ctx).type === "keyword") {
        typeParts.push(peek(ctx).value);
      } else if (peek(ctx).type === "dot") {
        typeParts.push(".");
      }
      advance(ctx);
    }
    node.returnType = typeParts.join("").replace(/\.+/g, ".") || null;
  }
  // Body
  if (peek(ctx).type === "lbrace") {
    advance(ctx);
    ctx.scopeStack.push(name);
    ctx.parentIdStack.push(node.id);
    node.references = collectReferencesInBlock(ctx, "lbrace", "rbrace");
    ctx.parentIdStack.pop();
    ctx.scopeStack.pop();
  } else if (peek(ctx).type === "colon") {
    // Python/Rust-style: `def foo(...):` or `fn foo() -> T {`
    // For Python, the body is an indented block (no braces).
    // For Rust, the body is `{ ... }`.
    advance(ctx); // ':'
    if (peek(ctx).type === "lbrace") {
      // Rust-style: `fn foo() -> T { ... }` (the colon was actually `->`)
      advance(ctx);
      ctx.scopeStack.push(name);
      ctx.parentIdStack.push(node.id);
      node.references = collectReferencesInBlock(ctx, "lbrace", "rbrace");
      ctx.parentIdStack.pop();
      ctx.scopeStack.pop();
    } else {
      // Python-style: parse the block as a sequence of statements.
      // We don't track indentation, so we just collect references
      // until we hit a top-level def/class/keyword.
      ctx.scopeStack.push(name);
      ctx.parentIdStack.push(node.id);
      // Collect references by walking until we see a def/class at any indent
      const refs: string[] = [];
      const startLine = peek(ctx).line;
      while (peek(ctx).type !== "eof") {
        const t = peek(ctx);
        // Break at the next line's statement-starting keyword
        if (t.type === "keyword" && t.line > startLine && [
          "def", "class", "fn", "func", "function", "if", "for", "while",
          "try", "catch", "return", "yield", "raise", "throw", "pass",
          "break", "continue", "const", "let", "var", "import", "use",
          "struct", "impl", "enum", "interface", "type", "pub", "async",
          "elif", "except", "finally", "with",
        ].includes(t.value)) {
          break;
        }
        if (t.type === "ident") {
          const next = peekAhead(ctx, 1);
          if (next.type === "lparen") refs.push(`call:${t.value}`);
          else refs.push(`ident:${t.value}`);
        }
        advance(ctx);
      }
      node.references = refs;
      ctx.parentIdStack.pop();
      ctx.scopeStack.pop();
    }
  } else if (peek(ctx).type === "semicolon") {
    advance(ctx);
  }
  node.endLine = peek(ctx).line;
  return node;
}

function parseClassBody(ctx: ParseContext, classNode: ASTNode) {
  // assumes { already consumed
  ctx.scopeStack.push(classNode.name);
  ctx.parentIdStack.push(classNode.id);
  let depth = 1;
  while (depth > 0 && peek(ctx).type !== "eof") {
    const memberDecorators = skipCommentsAndDecorators(ctx);
    const t = peek(ctx);
    if (t.type === "rbrace") {
      advance(ctx);
      depth--;
      continue;
    }
    if (t.type === "eof") break;
    // Modifiers
    let isAsync = false;
    let isStatic = false;
    let accessMod = "";
    while (
      peek(ctx).type === "keyword" &&
      ["public", "private", "protected", "static", "readonly", "abstract", "async", "get", "set"].includes(
        peek(ctx).value
      )
    ) {
      const kw = advance(ctx);
      if (kw.value === "async") isAsync = true;
      if (kw.value === "static") isStatic = true;
      if (["public", "private", "protected"].includes(kw.value)) accessMod = kw.value;
    }
    void isStatic;
    void accessMod;
    // Method or property?
    if (peek(ctx).type === "ident" && peekAhead(ctx, 1).type === "lparen") {
      const name = peek(ctx).value;
      const startLine = peek(ctx).line;
      advance(ctx); // name
      // Constructor?
      const nodeType: ASTNodeType = name === "constructor" ? "ConstructorDeclaration" : "MethodDeclaration";
      parseFunctionLike(ctx, nodeType, name, memberDecorators, false, isAsync, startLine);
    } else if (peek(ctx).type === "ident") {
      // Property
      const name = peek(ctx).value;
      const startLine = peek(ctx).line;
      advance(ctx);
      let type = "any";
      if (peek(ctx).type === "colon") {
        advance(ctx);
        const typeParts: string[] = [];
        while (
          peek(ctx).type !== "semicolon" &&
          peek(ctx).type !== "eof" &&
          peek(ctx).type !== "lbrace" &&
          peek(ctx).type !== "rbrace"
        ) {
          if (peek(ctx).type === "ident" || peek(ctx).type === "keyword") {
            typeParts.push(peek(ctx).value);
          } else if (peek(ctx).type === "dot") {
            typeParts.push(".");
          }
          advance(ctx);
        }
        type = typeParts.join("").replace(/\.+/g, ".") || "any";
      }
      if (peek(ctx).type === "op") {
        // Skip initializer
        while (
          peek(ctx).type !== "semicolon" &&
          peek(ctx).type !== "eof" &&
          peek(ctx).type !== "rbrace"
        ) {
          advance(ctx);
        }
      }
      if (peek(ctx).type === "semicolon") advance(ctx);
      const propNode = createNode(ctx, "PropertyDeclaration", name, startLine, memberDecorators);
      propNode.returnType = type;
      propNode.endLine = peek(ctx).line;
    } else {
      // Unknown — skip to next ; or }
      while (
        peek(ctx).type !== "semicolon" &&
        peek(ctx).type !== "rbrace" &&
        peek(ctx).type !== "eof"
      ) {
        advance(ctx);
      }
      if (peek(ctx).type === "semicolon") advance(ctx);
    }
  }
  ctx.parentIdStack.pop();
  ctx.scopeStack.pop();
}

function parseClass(ctx: ParseContext, isExported: boolean, decorators: DecoratorInfo[]) {
  const startLine = peek(ctx).line;
  advance(ctx); // 'class'
  const name = peek(ctx).type === "ident" ? advance(ctx).value : "AnonymousClass";
  // extends / implements
  while (
    peek(ctx).type === "keyword" &&
    (peek(ctx).value === "extends" || peek(ctx).value === "implements")
  ) {
    advance(ctx);
    while (
      peek(ctx).type !== "lbrace" &&
      peek(ctx).type !== "keyword" &&
      peek(ctx).type !== "eof"
    ) {
      advance(ctx);
    }
    if (peek(ctx).type === "keyword" && peek(ctx).value === "implements") continue;
    break;
  }
  const classNode = createNode(ctx, "ClassDeclaration", name, startLine, decorators);
  classNode.isExported = isExported;
  if (peek(ctx).type === "lbrace") {
    advance(ctx);
    parseClassBody(ctx, classNode);
  } else if (peek(ctx).type === "colon") {
    // Python-style class body: `class Foo:` followed by indented block.
    // We don't track indentation, so we parse subsequent def/class/method
    // statements at this level until we hit a dedent or EOF.
    advance(ctx); // ':'
    parsePythonBlock(ctx, classNode);
  }
  classNode.endLine = peek(ctx).line;
}

// Parse a Python-style indented block (no braces, just statements until dedent).
// Since we don't track indentation in the tokenizer, we use a heuristic:
// parse top-level statements (def/class/assignment) until we encounter a
// `def`, `class`, or `impl` at the same or lower indentation. In practice
// this means: parse everything until we hit another top-level keyword.
function parsePythonBlock(ctx: ParseContext, parentNode: ASTNode) {
  ctx.scopeStack.push(parentNode.name);
  ctx.parentIdStack.push(parentNode.id);
  while (peek(ctx).type !== "eof") {
    const decorators = skipCommentsAndDecorators(ctx);
    if (peek(ctx).type === "eof") break;
    // Stop if we hit a top-level keyword that shouldn't be inside this block
    // at the same indentation. We can't reliably detect this without indentation
    // tracking, so we just parse until EOF or a clear block-end marker.
    if (peek(ctx).type === "keyword") {
      const kw = peek(ctx).value;
      if (kw === "def") {
        const startLine = peek(ctx).line;
        advance(ctx); // 'def'
        const name = peek(ctx).type === "ident" ? advance(ctx).value : "anonymous";
        parseFunctionLike(ctx, "MethodDeclaration", name, decorators, false, false, startLine);
        continue;
      } else if (kw === "class") {
        parseClass(ctx, false, decorators);
        continue;
      } else if (kw === "return" || kw === "if" || kw === "for" || kw === "while" || kw === "raise" || kw === "pass" || kw === "try" || kw === "with") {
        // Skip statements inside the block — just consume to end of line
        // (Python doesn't use semicolons, so we consume until we see the
        // next keyword or EOF).
        advance(ctx);
        // Consume rest of the statement (until next keyword that starts a new statement)
        while (peek(ctx).type !== "eof") {
          const t = peek(ctx);
          if (t.type === "keyword" && ["def", "class", "if", "for", "while", "return", "raise", "pass", "try", "with", "elif", "else", "except", "finally"].includes(t.value)) {
            // Check if this is likely a new statement (heuristic: preceded by nothing)
            break;
          }
          advance(ctx);
        }
        continue;
      }
    }
    // Skip unknown tokens
    advance(ctx);
  }
  ctx.parentIdStack.pop();
  ctx.scopeStack.pop();
}

function parseFunction(ctx: ParseContext, isExported: boolean, decorators: DecoratorInfo[]) {
  const startLine = peek(ctx).line;
  advance(ctx); // 'function' | 'def' | 'fn' | 'func'
  // Go receiver clause: "func (c *Command) AddCommand(...)"
  // After 'func', if we see '(', skip the receiver clause to find the method name.
  if (peek(ctx).type === "lparen") {
    skipUntilMatching(ctx, "lparen", "rparen");
  }
  const name = peek(ctx).type === "ident" ? advance(ctx).value : "anonymous";
  // Go: the receiver type becomes the scope (class name)
  // e.g., "func (c *Command) AddCommand" → scope = ["Command"], name = "AddCommand"
  // We detect this retroactively if we skipped a receiver.
  parseFunctionLike(ctx, "FunctionDeclaration", name, decorators, isExported, false, startLine);
}

function parseVariable(ctx: ParseContext, isExported: boolean, decorators: DecoratorInfo[]) {
  const startLine = peek(ctx).line;
  advance(ctx); // const / let / var
  const name = peek(ctx).type === "ident" ? advance(ctx).value : "anonymous";
  const node = createNode(ctx, "VariableDeclaration", name, startLine, decorators);
  node.isExported = isExported;
  // Optional type annotation
  if (peek(ctx).type === "colon") {
    advance(ctx);
    const typeParts: string[] = [];
    while (
      peek(ctx).type !== "op" &&
      peek(ctx).type !== "semicolon" &&
      peek(ctx).type !== "eof"
    ) {
      if (peek(ctx).type === "ident" || peek(ctx).type === "keyword") {
        typeParts.push(peek(ctx).value);
      } else if (peek(ctx).type === "dot") {
        typeParts.push(".");
      }
      advance(ctx);
    }
    node.returnType = typeParts.join("").replace(/\.+/g, ".") || null;
  }
  // Initializer — collect references up to semicolon
  if (peek(ctx).type === "op" && peek(ctx).value.startsWith("=")) {
    advance(ctx);
    const refs: string[] = [];
    while (peek(ctx).type !== "semicolon" && peek(ctx).type !== "eof") {
      const t = peek(ctx);
      if (t.type === "comment" || t.type === "string") {
        advance(ctx);
        continue;
      }
      if (t.type === "lbrace" || t.type === "lparen" || t.type === "lbracket") {
        const open = t.type;
        const close =
          open === "lbrace" ? "rbrace" : open === "lparen" ? "rparen" : "rbracket";
        advance(ctx);
        let depth = 1;
        while (depth > 0 && peek(ctx).type !== "eof") {
          const t2 = peek(ctx);
          if (t2.type === open) depth++;
          else if (t2.type === close) {
            depth--;
            if (depth === 0) {
              advance(ctx);
              break;
            }
          } else if (t2.type === "ident") {
            const next = peekAhead(ctx, 1);
            if (next.type === "lparen") refs.push(`call:${t2.value}`);
            else refs.push(`ident:${t2.value}`);
          }
          advance(ctx);
        }
        continue;
      }
      if (t.type === "ident") {
        const next = peekAhead(ctx, 1);
        if (next.type === "lparen") refs.push(`call:${t.value}`);
        else if (peekAhead(ctx, -1).type === "dot") refs.push(`member:${t.value}`);
        else refs.push(`ident:${t.value}`);
      }
      advance(ctx);
    }
    node.references = refs;
  }
  if (peek(ctx).type === "semicolon") advance(ctx);
  node.endLine = peek(ctx).line;
}

export function parseSource(src: string, filePath: string): ASTDocument {
  const tokens = tokenize(src);
  const moduleId = filePath.replace(/[^a-zA-Z0-9]/g, "_");
  const ctx: ParseContext = {
    tokens,
    pos: 0,
    filePath,
    moduleId,
    nodes: [],
    scopeStack: [],
    parentIdStack: [null],
    idCounter: 0,
  };

  // Create root Program node
  const rootStartLine = tokens[0]?.line ?? 1;
  const root: ASTNode = {
    id: `${moduleId}#root`,
    type: "Program",
    name: filePath.split("/").pop() || filePath,
    filePath,
    startLine: rootStartLine,
    endLine: rootStartLine,
    scope: [],
    decorators: [],
    parentId: null,
    childIds: [],
    references: [],
    parameterTypes: [],
    returnType: null,
    isExported: false,
    isAsync: false,
    astDepth: 0,
  };
  ctx.nodes.push(root);
  ctx.parentIdStack = [root.id];

  const sourceLines = src.split("\n");

  while (peek(ctx).type !== "eof") {
    const decorators = skipCommentsAndDecorators(ctx);
    const t = peek(ctx);
    if (t.type === "eof") break;

    // Detect export / async / pub modifiers (pub is Rust visibility)
    let isExported = false;
    while (peek(ctx).type === "keyword" && (peek(ctx).value === "export" || peek(ctx).value === "default" || peek(ctx).value === "pub")) {
      isExported = true;
      advance(ctx);
      if (peek(ctx).value === "default") advance(ctx);
      // Rust: `pub(crate)` or `pub(crate::foo)` — skip the parens
      if (peek(ctx).type === "lparen") {
        skipUntilMatching(ctx, "lparen", "rparen");
      }
    }
    // Rust: `mut` keyword before let bindings
    if (peek(ctx).type === "keyword" && peek(ctx).value === "mut") {
      advance(ctx);
    }
    let isAsync = false;
    if (peek(ctx).type === "keyword" && peek(ctx).value === "async") {
      isAsync = true;
      advance(ctx);
    }

    if (peek(ctx).type === "keyword") {
      const kw = peek(ctx).value;
      if (kw === "import" || kw === "use" || kw === "from") {
        parseImport(ctx);
      } else if (kw === "class" || kw === "interface" || kw === "struct" || kw === "impl" || kw === "enum") {
        parseClass(ctx, isExported, decorators);
      } else if (kw === "function" || kw === "def" || kw === "fn" || kw === "func") {
        parseFunction(ctx, isExported, decorators);
      } else if (kw === "const" || kw === "let" || kw === "var") {
        parseVariable(ctx, isExported, decorators);
      } else if (kw === "package") {
        // Go package declaration — skip just the package name
        advance(ctx); // 'package'
        if (peek(ctx).type === "ident") advance(ctx); // package name
      } else if (kw === "type") {
        // Go type declaration — treat like a class
        parseClass(ctx, isExported, decorators);
      } else if (kw === "if" || kw === "for" || kw === "while" || kw === "try" || kw === "catch" || kw === "elif" || kw === "except" || kw === "with") {
        // Skip control-flow blocks but create a node for scope tracking
        const startLine = peek(ctx).line;
        const nodeType: ASTNodeType =
          kw === "if" || kw === "elif"
            ? "IfStatement"
            : kw === "for"
              ? "ForStatement"
              : kw === "while"
                ? "WhileStatement"
                : "TryStatement";
        advance(ctx);
        if (peek(ctx).type === "lparen") skipUntilMatching(ctx, "lparen", "rparen");
        if (peek(ctx).type === "lbrace") {
          advance(ctx);
          const node = createNode(ctx, nodeType, `${kw}-block`, startLine, []);
          ctx.scopeStack.push(`${kw}-block`);
          ctx.parentIdStack.push(node.id);
          node.references = collectReferencesInBlock(ctx, "lbrace", "rbrace");
          ctx.parentIdStack.pop();
          ctx.scopeStack.pop();
          node.endLine = peek(ctx).line;
        }
      } else if (kw === "throw" || kw === "raise" || kw === "return" || kw === "yield" || kw === "pass" || kw === "break" || kw === "continue" || kw === "assert") {
        // Statements that end at end-of-line (no semicolon in Python, optional in JS/Rust)
        const startLine = peek(ctx).line;
        const stmtType: ASTNodeType =
          kw === "throw" || kw === "raise"
            ? "ThrowStatement"
            : kw === "return" || kw === "yield"
              ? "ReturnStatement"
              : "IfStatement"; // generic placeholder for pass/break/continue/assert
        advance(ctx);
        const refs: string[] = [];
        // Consume rest of line until we see a new statement keyword or EOF
        while (peek(ctx).type !== "eof") {
          const t = peek(ctx);
          // Stop at the next line's keyword (heuristic for Python/Rust end-of-statement)
          if (t.type === "keyword" && t.line > startLine && [
            "def", "class", "fn", "func", "function", "if", "for", "while",
            "try", "catch", "return", "yield", "raise", "throw", "pass",
            "break", "continue", "const", "let", "var", "import", "use",
            "struct", "impl", "enum", "interface", "type", "pub", "async",
            "elif", "except", "finally", "with",
          ].includes(t.value)) {
            break;
          }
          if (t.type === "ident") {
            const next = peekAhead(ctx, 1);
            if (next.type === "lparen") refs.push(`call:${t.value}`);
            else refs.push(`ident:${t.value}`);
          }
          if (t.type === "semicolon") {
            advance(ctx);
            break;
          }
          advance(ctx);
        }
        if (stmtType === "ThrowStatement" || stmtType === "ReturnStatement") {
          const node = createNode(ctx, stmtType, kw, startLine, []);
          node.references = refs;
          node.endLine = peek(ctx).line;
        }
      } else {
        advance(ctx);
      }
    } else {
      advance(ctx);
    }
  }

  root.endLine = peek(ctx).line;
  return {
    filePath,
    moduleName: moduleId,
    root,
    nodes: ctx.nodes,
    sourceLines,
  };
}
