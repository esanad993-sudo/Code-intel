// AST Node Type Definitions
// These represent the structural elements of code we index and analyze.

export type ASTNodeType =
  | "Program"
  | "ImportDeclaration"
  | "ClassDeclaration"
  | "FunctionDeclaration"
  | "MethodDeclaration"
  | "ConstructorDeclaration"
  | "VariableDeclaration"
  | "ParameterDeclaration"
  | "PropertyDeclaration"
  | "ReturnStatement"
  | "CallExpression"
  | "AssignmentExpression"
  | "IfStatement"
  | "ForStatement"
  | "WhileStatement"
  | "TryStatement"
  | "ThrowStatement"
  | "Decorator"
  | "TypeReference"
  | "MemberExpression";

export interface DecoratorInfo {
  name: string; // e.g. "@route"
  args: string[]; // e.g. ["/login", "POST"]
}

export interface ASTNode {
  id: string; // unique node id within the project
  type: ASTNodeType;
  name: string; // identifier or call target
  filePath: string;
  startLine: number;
  endLine: number;
  scope: string[]; // chain of enclosing scopes, e.g. ["AuthService", "validateUser"]
  decorators: DecoratorInfo[];
  parentId: string | null;
  childIds: string[];
  // Semantic context used by downstream algorithms
  references: string[]; // identifiers / call-targets this node touches
  parameterTypes: string[]; // for functions/methods
  returnType: string | null;
  isExported: boolean;
  isAsync: boolean;
  // For RRF / scope validation
  astDepth: number;
}

export interface ASTDocument {
  filePath: string;
  moduleName: string;
  root: ASTNode;
  nodes: ASTNode[]; // flattened, includes root
  sourceLines: string[];
}

export interface ASTProject {
  documents: ASTDocument[];
  allNodes: ASTNode[];
  // Cross-file lookup maps
  nodesById: Map<string, ASTNode>;
  callGraph: Map<string, string[]>; // callerId -> calleeId[]
  dataFlowGraph: Map<string, string[]>; // sourceId -> sinkId[]
  // Decorator index for fast lookup
  decoratorIndex: Map<string, string[]>;
}

export interface SearchQuery {
  text: string;
  nodeType?: ASTNodeType;
  scope?: string;
  decorator?: string;
  filePath?: string;
}

export interface SearchResult {
  node: ASTNode;
  score: number;
  matchedFields: string[];
  snippet: string;
}
