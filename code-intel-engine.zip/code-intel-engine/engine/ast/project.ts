// Loads sample codebase, parses each file, builds cross-file indexes.
// Uses the TS-native parser for TypeScript/JavaScript files (fast, in-process).
// Falls back to the Python tree-sitter sidecar for Python/Rust/Go/Java files
// (runs as a subprocess at index time — never on the query hot path).
import { parseSource } from "./parser";
import { ASTDocument, ASTProject, ASTNode } from "./types";
import { SAMPLE_CODEBASE } from "../sample/codebase";
import { parseFiles, checkHealth, SidecarParseFile } from "../sidecar";

// Detect language from file extension
function detectLanguage(path: string): string | null {
  const parts = path.split(".");
  const ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase() : null;
  if (!ext) return null;
  const map: Record<string, string> = {
    py: "python",
    rs: "rust",
    go: "go",
    java: "java",
    ts: "typescript",
    tsx: "typescript",
    js: "javascript",
    jsx: "javascript",
  };
  return map[ext] || null;
}

// Convert sidecar response (which uses the same shape as our ASTDocument)
// into our internal ASTDocument type. The sidecar adds a few extra fields
// (language, docstring) that we attach as non-enumerable metadata.
function sidecarDocToASTDoc(sd: any): ASTDocument {
  const nodes: ASTNode[] = (sd.nodes || []).map((n: any) => ({
    id: n.id,
    type: n.type,
    name: n.name,
    filePath: n.filePath,
    startLine: n.startLine,
    endLine: n.endLine,
    scope: n.scope || [],
    decorators: n.decorators || [],
    parentId: n.parentId,
    childIds: n.childIds || [],
    references: n.references || [],
    parameterTypes: n.parameterTypes || [],
    returnType: n.returnType,
    isExported: !!n.isExported,
    isAsync: !!n.isAsync,
    astDepth: n.astDepth || 0,
  }));
  // Find root
  const root = nodes.find((n) => n.type === "Program") || nodes[0];
  return {
    filePath: sd.filePath,
    moduleName: sd.moduleName || sd.filePath.replace(/[^a-zA-Z0-9]/g, "_"),
    root,
    nodes,
    sourceLines: sd.sourceLines || [],
  };
}

// Check if the Python sidecar is available (cached after first check)
let sidecarAvailable: boolean | null = null;
async function isSidecarAvailable(): Promise<boolean> {
  if (sidecarAvailable !== null) return sidecarAvailable;
  try {
    await checkHealth();
    sidecarAvailable = true;
  } catch {
    sidecarAvailable = false;
  }
  return sidecarAvailable;
}

export async function buildProjectAsync(): Promise<ASTProject> {
  const documents: ASTDocument[] = [];
  const allNodes: ASTNode[] = [];
  const nodesById = new Map<string, ASTNode>();
  const callGraph = new Map<string, string[]>();
  const dataFlowGraph = new Map<string, string[]>();
  const decoratorIndex = new Map<string, string[]>();

  // Split files by language — TS/JS uses the in-process parser,
  // other languages use the Python sidecar if available.
  const tsFiles: typeof SAMPLE_CODEBASE = [];
  const otherFiles: typeof SAMPLE_CODEBASE = [];
  for (const file of SAMPLE_CODEBASE) {
    const lang = file.language || detectLanguage(file.path);
    if (lang === "typescript" || lang === "javascript") {
      tsFiles.push(file);
    } else {
      otherFiles.push(file);
    }
  }

  // Parse TS/JS files in-process (fast)
  for (const file of tsFiles) {
    const doc = parseSource(file.content, file.path);
    documents.push(doc);
    for (const node of doc.nodes) {
      allNodes.push(node);
      nodesById.set(node.id, node);
      for (const dec of node.decorators) {
        const arr = decoratorIndex.get(dec.name) || [];
        arr.push(node.id);
        decoratorIndex.set(dec.name, arr);
      }
    }
  }

  // Parse other-language files via Python sidecar (if available)
  if (otherFiles.length > 0) {
    const sidecarUp = await isSidecarAvailable();
    if (sidecarUp) {
      try {
        const filesPayload: SidecarParseFile[] = otherFiles.map((f) => ({
          path: f.path,
          content: f.content,
          language: f.language || detectLanguage(f.path) || undefined,
        }));
        const resp = await parseFiles(filesPayload);
        for (const sd of resp.documents) {
          if (sd.error) {
            console.warn(`[sidecar] failed to parse ${sd.filePath}: ${sd.error}`);
            continue;
          }
          const doc = sidecarDocToASTDoc(sd);
          documents.push(doc);
          for (const node of doc.nodes) {
            allNodes.push(node);
            nodesById.set(node.id, node);
            for (const dec of node.decorators) {
              const arr = decoratorIndex.get(dec.name) || [];
              arr.push(node.id);
              decoratorIndex.set(dec.name, arr);
            }
          }
        }
      } catch (e: any) {
        console.warn(`[sidecar] parse failed, falling back to TS parser: ${e.message}`);
        // Fall through to fallback below
        for (const file of otherFiles) {
          const doc = parseSource(file.content, file.path);
          documents.push(doc);
          for (const node of doc.nodes) {
            allNodes.push(node);
            nodesById.set(node.id, node);
          }
        }
      }
    } else {
      // Sidecar not available — use TS parser as degraded fallback
      for (const file of otherFiles) {
        const doc = parseSource(file.content, file.path);
        documents.push(doc);
        for (const node of doc.nodes) {
          allNodes.push(node);
          nodesById.set(node.id, node);
        }
      }
    }
  }

  // Build call graph & data-flow graph by resolving references.
  for (const node of allNodes) {
    if (
      node.type !== "FunctionDeclaration" &&
      node.type !== "MethodDeclaration" &&
      node.type !== "ConstructorDeclaration"
    ) {
      continue;
    }
    const callers: string[] = [];
    const dataFlowTargets: string[] = [];
    for (const ref of node.references) {
      if (ref.startsWith("call:")) {
        const calleeName = ref.slice(5);
        const candidates = allNodes.filter(
          (n) =>
            (n.type === "FunctionDeclaration" ||
              n.type === "MethodDeclaration" ||
              n.type === "ConstructorDeclaration") &&
            n.name === calleeName
        );
        const sameScope = candidates.find((c) => {
          if (c.scope.length === 0 || node.scope.length === 0) return false;
          return c.scope[c.scope.length - 1] === node.scope[node.scope.length - 1];
        });
        const target = sameScope || candidates[0];
        if (target) {
          callers.push(target.id);
          dataFlowTargets.push(target.id);
        }
      } else if (ref.startsWith("ident:")) {
        const identName = ref.slice(6);
        const candidates = allNodes.filter(
          (n) =>
            (n.type === "VariableDeclaration" ||
              n.type === "ParameterDeclaration" ||
              n.type === "PropertyDeclaration") &&
            n.name === identName
        );
        if (candidates.length > 0) {
          dataFlowTargets.push(candidates[0].id);
        }
      }
    }
    if (callers.length > 0) callGraph.set(node.id, callers);
    if (dataFlowTargets.length > 0) dataFlowGraph.set(node.id, dataFlowTargets);
  }

  return {
    documents,
    allNodes,
    nodesById,
    callGraph,
    dataFlowGraph,
    decoratorIndex,
  };
}

// Synchronous build using only the TS parser (for backward compatibility /
// when the sidecar is unavailable). The async version above is preferred.
export function buildProject(): ASTProject {
  const documents: ASTDocument[] = [];
  const allNodes: ASTNode[] = [];
  const nodesById = new Map<string, ASTNode>();
  const callGraph = new Map<string, string[]>();
  const dataFlowGraph = new Map<string, string[]>();
  const decoratorIndex = new Map<string, string[]>();

  for (const file of SAMPLE_CODEBASE) {
    const doc = parseSource(file.content, file.path);
    documents.push(doc);
    for (const node of doc.nodes) {
      allNodes.push(node);
      nodesById.set(node.id, node);
      for (const dec of node.decorators) {
        const arr = decoratorIndex.get(dec.name) || [];
        arr.push(node.id);
        decoratorIndex.set(dec.name, arr);
      }
    }
  }

  for (const node of allNodes) {
    if (
      node.type !== "FunctionDeclaration" &&
      node.type !== "MethodDeclaration" &&
      node.type !== "ConstructorDeclaration"
    ) {
      continue;
    }
    const callers: string[] = [];
    const dataFlowTargets: string[] = [];
    for (const ref of node.references) {
      if (ref.startsWith("call:")) {
        const calleeName = ref.slice(5);
        const candidates = allNodes.filter(
          (n) =>
            (n.type === "FunctionDeclaration" ||
              n.type === "MethodDeclaration" ||
              n.type === "ConstructorDeclaration") &&
            n.name === calleeName
        );
        const sameScope = candidates.find((c) => {
          if (c.scope.length === 0 || node.scope.length === 0) return false;
          return c.scope[c.scope.length - 1] === node.scope[node.scope.length - 1];
        });
        const target = sameScope || candidates[0];
        if (target) {
          callers.push(target.id);
          dataFlowTargets.push(target.id);
        }
      } else if (ref.startsWith("ident:")) {
        const identName = ref.slice(6);
        const candidates = allNodes.filter(
          (n) =>
            (n.type === "VariableDeclaration" ||
              n.type === "ParameterDeclaration" ||
              n.type === "PropertyDeclaration") &&
            n.name === identName
        );
        if (candidates.length > 0) {
          dataFlowTargets.push(candidates[0].id);
        }
      }
    }
    if (callers.length > 0) callGraph.set(node.id, callers);
    if (dataFlowTargets.length > 0) dataFlowGraph.set(node.id, dataFlowTargets);
  }

  return {
    documents,
    allNodes,
    nodesById,
    callGraph,
    dataFlowGraph,
    decoratorIndex,
  };
}

// Convenience: singleton project instance.
let cachedProject: ASTProject | null = null;
export function getProject(): ASTProject {
  if (!cachedProject) cachedProject = buildProject();
  return cachedProject;
}

// Force a fresh rebuild of the project (clears the in-memory cache).
export function rebuildProject(): ASTProject {
  cachedProject = buildProject();
  return cachedProject;
}

// Async singleton — uses the Python sidecar for non-TS files.
let cachedProjectAsync: Promise<ASTProject> | null = null;
export function getProjectAsync(): Promise<ASTProject> {
  if (!cachedProjectAsync) {
    cachedProjectAsync = buildProjectAsync();
  }
  return cachedProjectAsync;
}
