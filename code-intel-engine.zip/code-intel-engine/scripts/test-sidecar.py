"""Test the code-intel sidecar end-to-end."""
import json
import urllib.request

BASE = "http://127.0.0.1:3030"

print("=== /health ===")
r = urllib.request.urlopen(f"{BASE}/health", timeout=5)
print(json.dumps(json.loads(r.read()), indent=2))

print("\n=== /parse (3 languages) ===")
payload = {
    "files": [
        {
            "path": "auth.py",
            "language": "python",
            "content": '@app.route("/login")\ndef login(username: str, password: str) -> str:\n    """Authenticate a user."""\n    user = db.find_user(username)\n    return hash_password(password)\n'
        },
        {
            "path": "main.rs",
            "language": "rust",
            "content": "pub fn authenticate(token: &str) -> Result<User, AuthError> {\n    verify_token(token)\n}\n\nstruct AuthError {}\n"
        },
        {
            "path": "handler.go",
            "language": "go",
            "content": 'func HandleLogin(w http.ResponseWriter, r *http.Request) {\n    user := Authenticate(r)\n    json.NewEncoder(w).Encode(user)\n}\n'
        },
    ]
}
req = urllib.request.Request(
    f"{BASE}/parse",
    data=json.dumps(payload).encode("utf-8"),
    headers={"Content-Type": "application/json"},
)
r = urllib.request.urlopen(req, timeout=10)
d = json.loads(r.read())
print(f"language_count={d['language_count']}")
for doc in d["documents"]:
    print(f"  {doc['filePath']:20s} lang={doc.get('language'):10s} nodes={len(doc['nodes']) - 1}")
    for n in doc["nodes"][1:5]:
        if n.get("type") != "Program":
            refs = n.get("references", [])[:3]
            decs = [d["name"] for d in n.get("decorators", [])]
            print(f"    - {n['type']:25s} {n['name']:20s} decorators={decs} refs={refs}")

print("\n=== /embed ===")
payload = {"texts": ["authenticateUser", "verifyCredential", "loginUser"]}
req = urllib.request.Request(
    f"{BASE}/embed",
    data=json.dumps(payload).encode("utf-8"),
    headers={"Content-Type": "application/json"},
)
r = urllib.request.urlopen(req, timeout=10)
d = json.loads(r.read())
print(f"dim={d['dim']} backend={d['backend']}")
v1, v2, v3 = d["vectors"]
print(f"  cos(authenticateUser,  verifyCredential) = {sum(x*y for x,y in zip(v1, v2)):.4f}")
print(f"  cos(authenticateUser,  loginUser)         = {sum(x*y for x,y in zip(v1, v3)):.4f}")
print(f"  cos(verifyCredential,  loginUser)         = {sum(x*y for x,y in zip(v2, v3)):.4f}")
