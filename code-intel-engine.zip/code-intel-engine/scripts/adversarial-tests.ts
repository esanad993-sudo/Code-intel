// Adversarial test suite for the Rust parser.
// Tests the 5 failure modes identified by critical review:
// 1. Strings containing braces
// 2. Comments containing braces
// 3. Raw strings (Go backticks, Rust r#"..."#)
// 4. Python indentation (separate path from brace-depth)
// 5. Go nested-paren return types

const CODEPARSE = "/home/z/my-project/mini-services/codeparse/target/release/codeparse";
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

function parse(filePath: string, content: string): any {
  const tmpFile = `/tmp/adversarial_${path.basename(filePath)}`;
  fs.writeFileSync(tmpFile, content);
  try {
    const output = execSync(`${CODEPARSE} "${tmpFile}"`, {
      encoding: "utf-8",
      timeout: 5000,
      maxBuffer: 10 * 1024 * 1024,
    });
    return JSON.parse(output);
  } catch (e: any) {
    return { error: e.message, nodes: [] };
  }
}

function getFunctions(doc: any): any[] {
  return (doc.nodes || []).filter((n: any) => n.type === "FunctionDeclaration");
}

let pass = 0;
let fail = 0;
let results: Array<{ name: string; passed: boolean; detail: string }> = [];

function test(name: string, condition: boolean, detail: string) {
  const status = condition ? "PASS" : "FAIL";
  if (condition) pass++; else fail++;
  results.push({ name, passed: condition, detail });
  console.log(`  ${status} ${name}`);
  if (!condition) console.log(`         ${detail}`);
}

console.log("=".repeat(80));
console.log("ADVERSARIAL TEST SUITE: Rust Parser vs Known Failure Modes");
console.log("=".repeat(80));

// === 1. Strings containing braces ===
console.log("\n--- 1. Strings containing braces ---");

// Go: fmt.Println("}")
const goStringBrace = `package main
import "fmt"
func main() {
    fmt.Println("}")
    fmt.Println("{")
}
func helper() {
    fmt.Println("normal")
}`;
const goResult = parse("test.go", goStringBrace);
const goFns = getFunctions(goResult);
test("Go: string with } doesn't desync brace counter",
  goFns.length === 2 && goFns.some((f: any) => f.name === "main") && goFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions (main, helper), got ${goFns.length}: ${goFns.map((f: any) => f.name).join(", ")}`);

// Rust: println!("}")
const rustStringBrace = `fn main() {
    println!("}");
    println!("{");
}
fn helper() {
    println!("normal");
}`;
const rustResult = parse("test.rs", rustStringBrace);
const rustFns = getFunctions(rustResult);
test("Rust: string with } doesn't desync brace counter",
  rustFns.length === 2 && rustFns.some((f: any) => f.name === "main") && rustFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions (main, helper), got ${rustFns.length}: ${rustFns.map((f: any) => f.name).join(", ")}`);

// TypeScript: console.log("}")
const tsStringBrace = `function main() {
    console.log("}");
    console.log("{");
}
function helper() {
    console.log("normal");
}`;
const tsResult = parse("test.ts", tsStringBrace);
const tsFns = getFunctions(tsResult);
test("TypeScript: string with } doesn't desync brace counter",
  tsFns.length === 2 && tsFns.some((f: any) => f.name === "main") && tsFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions (main, helper), got ${tsFns.length}: ${tsFns.map((f: any) => f.name).join(", ")}`);

// === 2. Comments containing braces ===
console.log("\n--- 2. Comments containing braces ---");

const goCommentBrace = `package main
// This function has a } in its comment
// And a { too
func main() {
    // } inside a line comment
    /* } inside a block comment { */
    return
}
func helper() {
    return
}`;
const goCommentResult = parse("test2.go", goCommentBrace);
const goCommentFns = getFunctions(goCommentResult);
test("Go: comment with } doesn't desync brace counter",
  goCommentFns.length === 2 && goCommentFns.some((f: any) => f.name === "main") && goCommentFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions, got ${goCommentFns.length}: ${goCommentFns.map((f: any) => f.name).join(", ")}`);

const rustCommentBrace = `fn main() {
    // } inside a line comment
    /* } inside a block comment { */
    return
}
fn helper() {
    return
}`;
const rustCommentResult = parse("test2.rs", rustCommentBrace);
const rustCommentFns = getFunctions(rustCommentResult);
test("Rust: comment with } doesn't desync brace counter",
  rustCommentFns.length === 2 && rustCommentFns.some((f: any) => f.name === "main") && rustCommentFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions, got ${rustCommentFns.length}: ${rustCommentFns.map((f: any) => f.name).join(", ")}`);

// === 3. Raw strings ===
console.log("\n--- 3. Raw strings ---");

// Go: backtick raw strings
const goRawString = `package main
func main() {
    s := \`hello } { world\`
    return
}
func helper() {
    return
}`;
const goRawResult = parse("test3.go", goRawString);
const goRawFns = getFunctions(goRawResult);
test("Go: backtick raw string with } doesn't desync",
  goRawFns.length === 2 && goRawFns.some((f: any) => f.name === "main") && goRawFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions, got ${goRawFns.length}: ${goRawFns.map((f: any) => f.name).join(", ")}`);

// Rust: r#"..."# raw strings
const rustRawString = `fn main() {
    let s = r#"} { {"#;
    return
}
fn helper() {
    return
}`;
const rustRawResult = parse("test3.rs", rustRawString);
const rustRawFns = getFunctions(rustRawResult);
test("Rust: r#\"...\"# raw string with } doesn't desync",
  rustRawFns.length === 2 && rustRawFns.some((f: any) => f.name === "main") && rustRawFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions, got ${rustRawFns.length}: ${rustRawFns.map((f: any) => f.name).join(", ")}`);

// Python: f-strings with braces
const pyFString = `def main():
    x = f"hello } {{ world"
    return x

def helper():
    return 42`;
const pyFStringResult = parse("test3.py", pyFString);
const pyFStringFns = getFunctions(pyFStringResult);
test("Python: f-string with } doesn't desync",
  pyFStringFns.length === 2 && pyFStringFns.some((f: any) => f.name === "main") && pyFStringFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions, got ${pyFStringFns.length}: ${pyFStringFns.map((f: any) => f.name).join(", ")}`);

// === 4. Python indentation (separate path) ===
console.log("\n--- 4. Python indentation handling ---");

// Nested functions in Python
const pyNested = `class App:
    def __init__(self):
        self.x = 1
    
    def run(self):
        def inner():
            return 42
        return inner()

def standalone():
    return "hello"`;
const pyNestedResult = parse("test4.py", pyNested);
const pyNestedFns = getFunctions(pyNestedResult);
test("Python: class methods properly scoped",
  pyNestedFns.some((f: any) => f.name === "__init__" && f.scope.includes("App")) &&
  pyNestedFns.some((f: any) => f.name === "run" && f.scope.includes("App")),
  `Expected __init__ and run in scope [App], got: ${pyNestedFns.map((f: any) => `${f.name}[${f.scope}]`).join(", ")}`);

test("Python: standalone function outside class",
  pyNestedFns.some((f: any) => f.name === "standalone" && !f.scope.includes("App")),
  `Expected standalone outside App scope`);

// === 5. Go nested-paren return types ===
console.log("\n--- 5. Go nested-paren return types ---");

const goNestedReturn = `package main
func (c *Command) FlagErrorFunc() (f func(*Command, error) error) {
    if c.flagErrorFunc != nil {
        return c.flagErrorFunc
    }
    return func(c *Command, err error) error {
        return err
    }
}
func (c *Command) AddCommand(cmds ...*Command) {
    for _, x := range cmds {
        c.commands = append(c.commands, x)
    }
}
func main() {
    return
}`;
const goNestedResult = parse("test5.go", goNestedReturn);
const goNestedFns = getFunctions(goNestedResult);
test("Go: FlagErrorFunc with nested-paren return type parsed",
  goNestedFns.some((f: any) => f.name === "FlagErrorFunc"),
  `Expected FlagErrorFunc in results: ${goNestedFns.map((f: any) => f.name).join(", ")}`);

test("Go: AddCommand after nested-paren function still parsed",
  goNestedFns.some((f: any) => f.name === "AddCommand"),
  `Expected AddCommand in results: ${goNestedFns.map((f: any) => f.name).join(", ")}`);

test("Go: main() at end of file still parsed",
  goNestedFns.some((f: any) => f.name === "main"),
  `Expected main in results: ${goNestedFns.map((f: any) => f.name).join(", ")}`);

// === 6. Multi-line strings (Go backtick) ===
console.log("\n--- 6. Multi-line raw strings ---");

const goMultiLine = `package main
func main() {
    s := \`line 1
line 2 }
line 3 {
line 4\`
    return
}
func helper() {
    return
}`;
const goMultiResult = parse("test6.go", goMultiLine);
const goMultiFns = getFunctions(goMultiResult);
test("Go: multi-line backtick string with } doesn't desync",
  goMultiFns.length === 2 && goMultiFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions including helper, got ${goMultiFns.length}: ${goMultiFns.map((f: any) => f.name).join(", ")}`);

// === 7. Edge case: empty function bodies ===
console.log("\n--- 7. Edge cases ---");

const goEmptyBody = `package main
func empty() {}
func also_empty() { }
func with_body() {
    x := 1
}`;
const goEmptyResult = parse("test7.go", goEmptyBody);
const goEmptyFns = getFunctions(goEmptyResult);
test("Go: empty function body {}",
  goEmptyFns.length === 3 && goEmptyFns.some((f: any) => f.name === "empty"),
  `Expected 3 functions, got ${goEmptyFns.length}`);

// Python with docstrings containing braces
const pyDocstring = `def main():
    """This docstring has a } and a { in it."""
    return 42

def helper():
    """Normal docstring."""
    return "hello"`;
const pyDocResult = parse("test7.py", pyDocstring);
const pyDocFns = getFunctions(pyDocResult);
test("Python: docstring with } doesn't desync",
  pyDocFns.length === 2 && pyDocFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions including helper, got ${pyDocFns.length}`);

// === 8. Nested braces in expressions ===
console.log("\n--- 8. Nested braces in expressions ---");

const tsNestedExpr = `function main() {
    const x = { a: { b: { c: 1 } } };
    const y = [1, [2, [3]]];
    return x;
}
function helper() {
    return 42;
}`;
const tsNestedResult = parse("test8.ts", tsNestedExpr);
const tsNestedFns = getFunctions(tsNestedResult);
test("TypeScript: deeply nested object/array literals don't desync",
  tsNestedFns.length === 2 && tsNestedFns.some((f: any) => f.name === "helper"),
  `Expected 2 functions including helper, got ${tsNestedFns.length}`);

// === Summary ===
console.log(`\n${"=".repeat(80)}`);
console.log("ADVERSARIAL TEST SUMMARY");
console.log(`${"=".repeat(80)}`);
console.log(`  Passed: ${pass}/${pass + fail}`);
console.log(`  Failed: ${fail}/${pass + fail}`);
if (fail > 0) {
  console.log(`\n  FAILURES:`);
  results.filter(r => !r.passed).forEach(r => {
    console.log(`    ${r.name}: ${r.detail}`);
  });
}

// === Honest assessment ===
console.log(`\n${"=".repeat(80)}`);
console.log("HONEST ASSESSMENT");
console.log(`${"=".repeat(80)}`);
console.log("  Claim: 'tree-sitter over-extracts'");
console.log("  Correction: tree-sitter's cost is in building a full CST before");
console.log("  you can query it. We skip that cost entirely. The query layer");
console.log("  is selective in both approaches.");
console.log("");
console.log("  Claim: 'brace-depth state machine'");
console.log("  Reality: For Python, we use a separate indentation-aware path.");
console.log("  For Go/Rust/TS/Java, we use brace-depth + paren-depth tracking.");
console.log("  Strings, comments, and raw strings are skipped by the tokenizer.");
console.log("");
console.log("  Remaining risks NOT tested here:");
console.log("  - Unicode identifiers (non-ASCII function names)");
console.log("  - C++ template metaprogramming");
console.log("  - Macro-generated code (Rust macro_rules!, C macros)");
console.log("  - JSX/TSX with embedded expressions");
console.log("  - 100+ query benchmark on unfamiliar repos");
