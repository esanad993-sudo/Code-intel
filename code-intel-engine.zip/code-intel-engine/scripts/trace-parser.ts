// Debug script: trace the token stream and collectReferencesInBlock behavior
// for a minimal class with two methods.

// Simple tokenizer (replicates the parser's tokenizer)
function tokenize(src) {
  let i = 0, line = 1;
  const tokens = [];
  const KEYWORDS = new Set(["class", "void", "this", "if", "for", "while", "return", "new", "export", "const", "let", "var"]);
  while (i < src.length) {
    const ch = src[i];
    if (ch === "\n") { line++; i++; continue; }
    if (ch === " " || ch === "\t") { i++; continue; }
    if (ch === "/" && src[i+1] === "/") { while (i < src.length && src[i] !== "\n") i++; continue; }
    if (ch === '"' || ch === "'" || ch === "`") {
      const q = ch; let end = i+1;
      while (end < src.length && src[end] !== q) { if (src[end] === "\n") line++; end++; }
      end++;
      tokens.push({ type: "string", value: src.slice(i, end), line });
      i = end; continue;
    }
    if (/[A-Za-z_$]/.test(ch)) {
      let end = i + 1;
      while (end < src.length && /[A-Za-z0-9_$]/.test(src[end])) end++;
      const w = src.slice(i, end);
      tokens.push({ type: KEYWORDS.has(w) ? "keyword" : "ident", value: w, line });
      i = end; continue;
    }
    if (ch === "{") { tokens.push({ type: "lbrace", value: "{", line }); i++; continue; }
    if (ch === "}") { tokens.push({ type: "rbrace", value: "}", line }); i++; continue; }
    if (ch === "(") { tokens.push({ type: "lparen", value: "(", line }); i++; continue; }
    if (ch === ")") { tokens.push({ type: "rparen", value: ")", line }); i++; continue; }
    if (ch === ";") { tokens.push({ type: "semicolon", value: ";", line }); i++; continue; }
    if (ch === ":") { tokens.push({ type: "colon", value: ":", line }); i++; continue; }
    if (ch === ".") { tokens.push({ type: "dot", value: ".", line }); i++; continue; }
    if (ch === ",") { tokens.push({ type: "comma", value: ",", line }); i++; continue; }
    i++;
  }
  tokens.push({ type: "eof", value: "", line });
  return tokens;
}

const test = "class C {\n  a(): void { x; }\n  b(): void { y; }\n}";
console.log("Source:\n", test, "\n");

const tokens = tokenize(test);
console.log("Tokens:");
tokens.forEach((t, j) => console.log(`  [${j}] L${t.line} ${t.type}: ${t.value}`));

// Now simulate collectReferencesInBlock
// Find the method body { (the first lbrace after "a")
console.log("\n=== Simulating collectReferencesInBlock ===");
// After "a" (ident) we have ( ) : void {
// a is at index 2, ( is 3, ) is 4, : is 5, void is 6, { is 7
const bodyStart = 7; // index of the method body {
console.log(`Method body { at token [${bodyStart}], next token is [${bodyStart+1}]`);

// collectReferencesInBlock assumes { was already consumed
// So we start at bodyStart + 1
let depth = 1;
let p = bodyStart + 1;
console.log(`Starting at token [${p}], depth=${depth}`);
while (depth > 0 && p < tokens.length) {
  const t = tokens[p];
  console.log(`  [${p}] depth=${depth} ${t.type}: ${t.value}`);
  if (t.type === "lbrace") { depth++; }
  if (t.type === "rbrace") {
    depth--;
    if (depth === 0) {
      console.log(`  → depth=0, CONSUMING this } and breaking`);
      p++; // advance past the }
      break;
    }
  }
  p++;
}
console.log(`\nAfter collectReferencesInBlock, position is [${p}]`);
console.log(`Next token: [${p}] ${tokens[p]?.type}: ${tokens[p]?.value}`);
console.log(`Token after that: [${p+1}] ${tokens[p+1]?.type}: ${tokens[p+1]?.value}`);

// Now simulate parseClassBody
console.log("\n=== Simulating parseClassBody loop ===");
console.log(`Class body started with depth=1`);
console.log(`After method a, next token is [${p}]: ${tokens[p]?.type}: ${tokens[p]?.value}`);
if (tokens[p]?.type === "rbrace") {
  console.log("→ This is the CLASS closing brace! parseClassBody would decrement depth to 0 and EXIT!");
  console.log("→ BUG FOUND: collectReferencesInBlock consumed the method body },");
  console.log("  but the class body parser sees the class closing } and exits early!");
}
