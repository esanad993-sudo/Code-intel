"""Test the sidecar via subprocess (CLI) mode."""
import json
import subprocess
import sys

SIDECAR = "/home/z/my-project/mini-services/code-intel/index.py"

def call(payload):
    p = subprocess.run(
        ["python3", SIDECAR, "--json-stdin"],
        input=json.dumps(payload),
        capture_output=True,
        text=True,
        env={"PYTHONWARNINGS": "ignore", "PATH": "/home/z/.venv/bin:/usr/bin:/bin"},
    )
    if p.returncode != 0:
        print("STDERR:", p.stderr[:1000])
        sys.exit(1)
    return json.loads(p.stdout)

# Test 1: health
print("=== health ===")
print(call({"op": "health"}))

# Test 2: parse multi-language
print("\n=== parse (3 languages) ===")
d = call({
    "op": "parse",
    "files": [
        {
            "path": "auth.py",
            "language": "python",
            "content": '@app.route("/login")\ndef login(username: str, password: str) -> str:\n    """Authenticate a user."""\n    user = db.find_user(username)\n    return hash_password(password)\n',
        },
        {
            "path": "main.rs",
            "language": "rust",
            "content": "pub fn authenticate(token: &str) -> Result<User, AuthError> {\n    verify_token(token)\n}\nstruct AuthError {}\n",
        },
        {
            "path": "handler.go",
            "language": "go",
            "content": 'func HandleLogin(w http.ResponseWriter, r *http.Request) {\n    user := Authenticate(r)\n    json.NewEncoder(w).Encode(user)\n}\n',
        },
    ],
})
print(f"language_count={d['language_count']}")
for doc in d["documents"]:
    print(f"  {doc['filePath']:20s} lang={doc.get('language'):10s} nodes={len(doc['nodes']) - 1}")
    for n in doc["nodes"][1:6]:
        if n.get("type") != "Program":
            refs = n.get("references", [])[:4]
            decs = [d["name"] for d in n.get("decorators", [])]
            doc_str = n.get("docstring", "")[:60]
            print(f"    - {n['type']:25s} {n['name']:20s} decorators={decs} refs={refs}")
            if doc_str:
                print(f"        doc: {doc_str}")

# Test 3: embed (synonym test)
print("\n=== embed (synonym similarity) ===")
d = call({"op": "embed", "texts": ["authenticateUser", "verifyCredential", "loginUser", "hashPassword", "unrelated"]})
print(f"dim={d['dim']} backend={d['backend']}")
v1, v2, v3, v4, v5 = d["vectors"]
def cos(a, b): return sum(x*y for x,y in zip(a, b))
print(f"  cos(authenticateUser,  verifyCredential) = {cos(v1, v2):.4f}")
print(f"  cos(authenticateUser,  loginUser)         = {cos(v1, v3):.4f}")
print(f"  cos(verifyCredential,  loginUser)         = {cos(v2, v3):.4f}")
print(f"  cos(authenticateUser,  hashPassword)      = {cos(v1, v4):.4f}")
print(f"  cos(authenticateUser,  unrelated)         = {cos(v1, v5):.4f}")
